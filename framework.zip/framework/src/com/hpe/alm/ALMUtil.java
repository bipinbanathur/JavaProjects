package com.hpe.alm;

import java.net.URISyntaxException;

import com.hpe.api.APIEngine;


public class ALMUtil
{
	

		APIEngine 		api				= 	new APIEngine();
		String			apiType			=	"";
		String 			urlString 		= 	"";
		String			userName		=	"";
		String			passwordString	=	"";
		String			mediaType		=	"";
		String			requestMethod	=	"";
		String			requestContent	=	"";
		String			responseContent	=	"";	
		String 			baseURI			=	"https://qc2f.austin.hpecorp.net:8443/qcbin/";
		String			namedCookie		=	"";
		String 			xrefToken		=	"";
		String 			logPath			=	"";
		String			payloadPath		=	"";
		String			functionName	=	"";
		
		public ALMUtil()
		{
				api				= 	new APIEngine();
				apiType			=	"REST";			
				userName		=	"narasingarao.dadi";
				passwordString	=	"Otsi$123";
				mediaType		=	"application/xml";
		}
		
		public void installCertificate()
		{
			try
			{
				//InstallCert.autherizeCertificate(new String[]{"qc2f.austin.hpecorp.net:8443"});
			}
			catch (Exception e)
			{
				System.out.println(e);
			}			
		}

		public void checkAuthentication() throws URISyntaxException
		{
			urlString 		= 	baseURI +"rest/is-authenticated/";	
			requestContent	=	"";
			requestMethod	=	"GET";	
			functionName	=	new Object(){}.getClass().getEnclosingMethod().getName();					
			//logPath			=	"B:\\Eclipse\\Data\\logs\\";
			//payloadPath		=	"B:\\Eclipse\\Data\\json\\";
			logPath			=	"C:\\test\\Data\\logs\\";
			payloadPath		=	"C:\\test\\Data\\json\\";
			
			api.setLogPath(logPath);
			api.enableLog();
			
			api.setApiType(apiType);		
			api.setCallingFNName(functionName);
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType(mediaType);
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);			
			api.showCertificates();	
			
			if( (namedCookie!= null && namedCookie != "") && (xrefToken!= null && xrefToken != ""))
			{
				api.setCookie(namedCookie+";"+xrefToken);
				
			}
			
			api.executeRequest();				
			api.showProperties();		
			api.showCookies();	

			
		}
	
		public void authenticateALM()
		{
			
			functionName	=	new Object(){}.getClass().getEnclosingMethod().getName();
			urlString 		= 	baseURI + "authentication-point/alm-authenticate"; 	
			requestContent	=	"<alm-authentication><user>"+userName+"</user><password>"+passwordString+"</password></alm-authentication>";
			requestMethod	=	"POST";						
			
			api.setApiType(apiType);
			
			api.setCallingFNName(functionName);		
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType(mediaType);
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);			
			api.showCertificates();			
			api.executeRequest();	
			api.showCookies();				
			api.showProperties();
			
			namedCookie = api.getCookie("LWSSO_COOKIE_KEY");
			System.out.println("Named Cookie :: "+namedCookie);
			
		}
		
		public void startALMSession()
		{
			urlString 		= 	baseURI +"rest/site-session/";	
			requestContent	=	"";
			requestMethod	=	"POST";	
			functionName	=	new Object(){}.getClass().getEnclosingMethod().getName();
			api.setCallingFNName(functionName);
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType("text/html");
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);	
						
			if(namedCookie!= null && namedCookie != "")
			{
				api.setCookie(namedCookie);
				
			}				
			api.showCertificates();						
			api.executeRequest();	
			api.showProperties();	
			api.showCookies();	
			
			xrefToken = api.getCookie("XSRF-TOKEN") ;
			
		}
		
		
		public void endALMSession()
		{
			urlString 		= 	baseURI +"rest/site-session/";	
			requestContent	=	"";
			requestMethod	=	"DELETE";
			
			functionName	=	new Object(){}.getClass().getEnclosingMethod().getName();
			api.setCallingFNName(functionName);
			api.setApiType(apiType);			
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType(mediaType);
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);	
			
			if( (namedCookie!= null && namedCookie != "") && (xrefToken!= null && xrefToken != ""))
			{
				api.setCookie(namedCookie+";"+xrefToken);
				
			}
			api.showCertificates();				
			api.executeRequest();				
			api.showProperties();	
			api.showCookies();
			responseContent = api.getResponseContent();
			api.retireEngine();
			
		}
		
		
		//needs to add get, put, post and delete functions here - finally this is class file which has all the common methods for ALM - 4 functions only
		//below is sample main which actually appear once after integrated with framework
		public static void main(String[] args) throws Exception {
			
			//add new 
			 ALMTest_AddNew.almPost("tests", "?query={owner['narasingarao.dadi']}", "create_test.xml");
			  
			//get'
			ALMTest_Read.almGet("tests","?fields=id,name,subtype-id,exec-status,status&query={owner['narasingarao.dadi']}");

			//udpate
			ALMTest_Update.almPut("tests", "/1425", "update_test.xml");
				
			//delete
			ALMTest_Delete.almDelete("tests", "/1443");
				
		} 
	
}

package com.hpe.alm;

import com.hpe.api.APIEngine;


public class ALMTest_Delete
{
	

		APIEngine 		api				= 	new APIEngine();
		String			apiType			=	"";
		String 			urlString 		= 	"";
		String			userName		=	"";
		String			passwordString	=	"";
		String			mediaType		=	"";
		String			requestMethod	=	"";
		String			requestContent	=	"";
		String			responseContent	=	"";	
		String 			baseURI			=	"https://qc2f.austin.hpecorp.net:8443/qcbin/";
		String			namedCookie		=	"";
		String 			xrefToken		=	"";
		String 			logPath			=	"";
		String			payloadPath		=	"";
		String			functionName	=	"";
		
		public ALMTest_Delete()
		{
			api				= 	new APIEngine();
			apiType			=	"REST";			
			userName		=	"narasingarao.dadi";
			passwordString	=	"Otsi$123";
			mediaType		=	"application/xml";
		}
		
			
		public void defects()
		{	
			urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/defects/";	
			requestContent	=	"";
			requestMethod	=	"GET";		
			functionName	=	new Object(){}.getClass().getEnclosingMethod().getName();
			api.setCallingFNName(functionName);
			api.setApiType(apiType);
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType("application/json");
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);	
			
			if( (namedCookie!= null && namedCookie != "") && (xrefToken!= null && xrefToken != ""))
			{
				api.setCookie(namedCookie+";"+xrefToken);
				
			}
			
			api.showCertificates();	
			api.executeRequest();	
			api.showCookies();
			api.showProperties();	
			
			String  out = api.getResponseContent();
			
			String retVal = out.replaceAll("<html([\\s\\S]+?)</html>", "Unsupported Text");
			
			System.out.println("\n\n\n\n\n\n\n"+retVal);
			
			//formatText(out)  ;
		}
				
		public void test_sets()
		{	
			//urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/tests?fields=contains-test-folder.name,id,name,status";
			//urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/tests?fields=id,name,subtype-id,exec-status,owner,status,test-folder.name&order-by={test-folder.name[ASC]}"; //,test-folder.name&order-by={test-folder.name[ASC]}"; //&query={owner['rajashekar.dasari_hp.com']}"; // ?fields=id,name,status"; & &order-by={test-folder.name[ASC]} //.contains-test-folder.name
			//urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/defects?fields=project,subject,name,detection-version,status,creation-time,detected-by"; //defects
			urlString 			= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/test-sets?fields=id,name,user-01&query={user-02['narasingarao.dadi']}";  //?fields=id,name,user-01&query={user-02['naveen.kumar2']}//design-steps?query={used-by-test.name[D*]}
			functionName		=	new Object(){}.getClass().getEnclosingMethod().getName();
			requestContent		=	"";
			requestMethod		=	"GET";
			
			api.setCallingFNName(functionName);
			api.setApiType(apiType);
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType("application/json");
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);	
			
			if( (namedCookie!= null && namedCookie != "") && (xrefToken!= null && xrefToken != ""))
			{
				api.setCookie(namedCookie+";"+xrefToken);
				
			}
				
			api.showCertificates();	
			api.executeRequest();	
			api.showCookies();
			api.showProperties();	
		}
		
		public void test_instances()
		{	


			urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/test-instances?fields=id,user-05,test-id,test-instance,exec-date,exec-time&query={cycle-id['820']}"; //

			requestContent	=	"";
			requestMethod	=	"GET";		
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType("application/json");
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);	
			
			if( (namedCookie!= null && namedCookie != "") && (xrefToken!= null && xrefToken != ""))
			{
				api.setCookie(namedCookie+";"+xrefToken);
				
			}
				
			api.showCertificates();	
	
			api.executeRequest();	
			
			
			api.showCookies();
			api.showProperties();	
			
			String  out = api.getResponseContent();
			
			String retVal = out.replaceAll("<html([\\s\\S]+?)</html>", "Unsupported Text");
			
			System.out.println("\n\n\n\n\n\n\n"+retVal);
			
			//formatText(out)  ;
		}
		
		public void tests_filtered()
		{	

			urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/tests/?fields=id,name,subtype-id,exec-status,status"; //&query={query={id[>=11 And  <= 14]}}"; // //../tests/135?fields=contains-test-folder.name
			requestContent	=	"";
			requestMethod	=	"GET";		
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType("application/json");
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);	
			
			if( (namedCookie!= null && namedCookie != "") && (xrefToken!= null && xrefToken != ""))
			{
				api.setCookie(namedCookie+";"+xrefToken);				
			}
			
			api.showCertificates();		
			api.executeRequest();						
			api.showCookies();
			api.showProperties();	
		}
				
		
		public void tests(String urlsubString)
		{	
			//urlString 	= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/tests?fields=contains-test-folder.name,id,name,status";
			//urlString 	= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/tests?fields=id,name,subtype-id,exec-status,owner,status"; //,test-folder.name&order-by={test-folder.name[ASC]}"; //&query={owner['rajashekar.dasari_hp.com']}"; // ?fields=id,name,status"; & &order-by={test-folder.name[ASC]} //.contains-test-folder.name			
			//urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/defects?fields=project,subject,name,detection-version,status,creation-time,detected-by"; //defects
			//urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/tests//?fields=id,name,subtype-id,exec-status,status&query={owner['narasingarao.dadi']}";  //?fields=id,name,subtype-id,exec-status,status&query={owner['naveen.kumar2']}
			urlString 		= 	baseURI + "rest/domains/BTO/projects/ITOM_Solutions/tests" + urlsubString;
			requestContent	=	""; 
			requestMethod	=	"DELETE";	
			functionName	=	new Object(){}.getClass().getEnclosingMethod().getName();
			api.setCallingFNName(functionName);
			api.setApiType(apiType);			
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType("application/xml");
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);	
			
			if( (namedCookie!= null && namedCookie != "") && (xrefToken!= null && xrefToken != ""))
			{
				api.setCookie(namedCookie+";"+xrefToken);
				
			}				
			api.showCertificates();	
			api.executeRequest();	
			
			
			
			api.showCookies();
			api.showProperties();	
		}
		
		
		
		public void runs()
		{	
			
			urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/runs?fields=owner,test-id,test-instance,cycle,cycle-id,name,state,id&query={id['6']}";
			requestContent	=	"";
			requestMethod	=	"GET";		
			
			functionName	=	new Object(){}.getClass().getEnclosingMethod().getName();
			api.setCallingFNName(functionName);
			api.setApiType(apiType);
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType("application/json");
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);				
			if( (namedCookie!= null && namedCookie != "") && (xrefToken!= null && xrefToken != ""))
			{
				api.setCookie(namedCookie+";"+xrefToken);
				
			}				
			api.showCertificates();	
			api.executeRequest();					
			api.showCookies();
			api.showProperties();	
		}

		public void reports()
		{	
			
			urlString 		= 	baseURI +"rest/domains/BTO/projects/ITOM_Solutions/reports/1?alt=text/html";
			requestContent	=	"";
			requestMethod	=	"GET";		
			
			functionName	=	new Object(){}.getClass().getEnclosingMethod().getName();
			api.setCallingFNName(functionName);
			api.setApiType(apiType);
			api.setUrlString(urlString);
			api.setUserName(userName);
			api.setPasswordString(passwordString);
			api.setRequestType("text/html");
			api.setRequestMethod(requestMethod);
			api.setRequestContent(requestContent);				
			if( (namedCookie!= null && namedCookie != "") && (xrefToken!= null && xrefToken != ""))
			{
				api.setCookie(namedCookie+";"+xrefToken);
				
			}				
			api.showCertificates();	
			api.executeRequest();					
			api.showCookies();
			api.showProperties();	
		}

		
		
		
		
		public static void almDelete(String str, String strFl) throws Exception
		{
			ALMUtil almutil = new ALMUtil();
			ALMTest_Delete almTest = new ALMTest_Delete();
			almutil.checkAuthentication();
			almutil.authenticateALM();
			almutil.startALMSession();
			String key = str;
			switch (key) {
			case "tests":
				almTest.tests(strFl);
				break;
			case "defects":
				almTest.defects();
				break;
			case "test_sets":
				almTest.test_sets();
				break;
			case "tests_filtered":
				almTest.tests_filtered();
				break;
			case "runs":
				almTest.runs();
				break;
			case "reports":
				almTest.reports();
				break;
			default:
				break;
			}		
			almutil.endALMSession();


		}
		

}

package com.hpe.api.test;

import com.hpe.alm.ALMTest_AddNew;
import com.hpe.alm.ALMTest_Delete;
import com.hpe.alm.ALMTest_Read;
import com.hpe.alm.ALMTest_Update;

public class ALMTest
{
//Committing ALM Changes , Narasing can continue Updating the project for ALM feature
	public static void main(String[] args) throws Exception {
		
		//add new 
		 ALMTest_AddNew.almPost("tests", "?query={owner['narasingarao.dadi']}", "create_test.xml");
		  
		//get'
		ALMTest_Read.almGet("tests","?fields=id,name,subtype-id,exec-status,status&query={owner['narasingarao.dadi']}");

		//udpate
		ALMTest_Update.almPut("tests", "/1425", "update_test.xml");
			
		//delete
		ALMTest_Delete.almDelete("tests", "/1443");
			
	} 
}

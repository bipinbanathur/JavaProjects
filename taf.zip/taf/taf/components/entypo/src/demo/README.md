Font demo page templates. Generated code is e bit dirty, but it's done
intentionally, for easy maintenance & single file buldling

Bootstrap CSS generated from original customizer
http://twitter.github.com/bootstrap/customize.html
Build options are:

- __Scraffolfing__ - ALL
- __Base CSS__ - `Headings, body, etc`


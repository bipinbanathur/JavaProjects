Experimental scripts to automate Entypo font building.

Please, don't use until this work finished. Look now original at entypo
site: http://www.entypo.com

License
-------

### Icons, font

Artwork by Daniel Bruce:

- http://www.entypo.com
- me@danielbruce.se
- [twitter](http://twitter.com/danielbruce_)
- [dribble](http://dribbble.com/danielbruce)

All icons are distributed under
[CC BY-SA](http://creativecommons.org/licenses/by-sa/3.0/) licence.

Font is distributed under
[SIL](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL) licence.


### Scripting

This project uses [font-builder](https://github.com/fontello/font-builder)
scripts to generate data.


'use strict';
var myModule = angular.module('myApp.services', []).value('version', '0.1');

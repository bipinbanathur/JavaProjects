package codgen;

import java.io.Serializable;

@SuppressWarnings("serial")
public class GlobalVariables implements Serializable
{
    String VariableName     =   "";
    String DataType         =   "";
    String DefaultValue     =   "";
    String Size             =   "";
    String IDParamQuery     =   "";
    String ValueParamQuery   =   "";
    
    public GlobalVariables() 
    {
        
    }
    
    public GlobalVariables(String VariableName,String DataType,String Size,String DefaultValue,String IDParamQuery,String ValueParamQuery) 
    {
        this.VariableName     =   VariableName;
        this.DataType         =   DataType;
        this.Size             =   Size;
        this.DefaultValue     =   DefaultValue;
        this.IDParamQuery     =   IDParamQuery;
        this.ValueParamQuery  =   ValueParamQuery;    
    }
    
    public String getVariableName()   	{ return VariableName ;  	}
    public String getDataType()       	{ return DataType ;      	}    
    public String getSize()           	{ return Size ;      	 	}    
    public String getDefaultValue()   	{ return DefaultValue ;  	}
    public String getIDParamQuery()   	{ return IDParamQuery ;  	}
    public String getValueParamQuery() 	{ return ValueParamQuery ;	}
    
    public void setVariableName(String VariableName)        { this.VariableName    =   VariableName ;   }
    public void setDataType(String DataType)                { this.DataType        =   DataType ;       }            
    public void setSize(String Size)                        { this.Size            =   Size ;           }  
    public void setDefault_Value(String DefaultValue)       { this.DefaultValue    =   DefaultValue ;   }
    public void setIDParamQuery(String IDParamQuery)        { this.IDParamQuery    =   IDParamQuery;    }
    public void setValueParamQuery(String ValueParamQuery)  { this.ValueParamQuery =   ValueParamQuery; }
}

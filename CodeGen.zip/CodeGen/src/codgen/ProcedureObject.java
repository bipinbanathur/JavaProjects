package codgen;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Properties;

@SuppressWarnings("serial")
public class ProcedureObject implements Serializable 
{
    ArrayList<SDTVariableAssginment> standard_variables     = null;
    ArrayList<UDTVariableAssignment> udt_variables          = null;
    ArrayList<VariableDeclaration>   declared_variables     = null;
    ArrayList<VariableDeclaration>   procedure_parameters   = null;     
    Properties                       authentication         = null;
    String                           message_string         = null;
    String                           catalog_name           = null;
    String                           procedure_name         = null;
    
    public ProcedureObject()
    {
        
    }
    
    public ArrayList<SDTVariableAssginment>  	getStandardVariables()         { return standard_variables;    }
    public ArrayList<UDTVariableAssignment>  	getUDTVariables()              { return udt_variables;         }
    public ArrayList<VariableDeclaration>   	getDeclaredVariables()         { return declared_variables;    }
    public ArrayList<VariableDeclaration>  		getProceduredParameters()      { return procedure_parameters;  }
    
    public Properties getAuthentication()            { return authentication;        }
    public String     getMessageString()             { return message_string;        }
    public String     getCatalogName()               { return catalog_name;          }
    public String     getProcedureName()             { return procedure_name;        }
    
    public void setStandardVariables(ArrayList<SDTVariableAssginment>  	standard_variables)       { this.standard_variables       = standard_variables;    }
    public void setUDTVariables(ArrayList<UDTVariableAssignment> 		udt_variables)            { this.udt_variables            = udt_variables;         }
    public void setDeclaredVariables(ArrayList<VariableDeclaration> 	declared_variables)       { this.declared_variables       = declared_variables;    }
    public void setProceduredParameters(ArrayList<VariableDeclaration> 	procedure_parameters ) 	  { this.procedure_parameters     = procedure_parameters;  }
    
    public void setAuthentication(Properties authentication)             { this.authentication 	= 	authentication ;     }
    public void setMessageString(String message_string)                  { this.message_string 	= 	message_string;      }
    public void setCatalogName(String catalog_name)                      { this.catalog_name 	=  	catalog_name ;       }
    public void setProcedureName(String procedure_name )                 { this.procedure_name 	=  	procedure_name;      }
   
}

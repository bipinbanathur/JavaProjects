package codgen;

import java.io.Serializable;

@SuppressWarnings("serial")
public class VariableDeclaration implements Serializable 
{
    String Variable_Name    =   "";
    String Data_Type        =   "";
    String Size             =   "";
    String Default_Value    =   "";
    String IO_Type          =   "";
    
    public VariableDeclaration(String Variable_Name,String Data_Type, String Size,String Default_Value,String IO_Type ) 
    {        
        this.Variable_Name    =   Variable_Name;
        this.Data_Type        =   Data_Type;
        this.Size             =   Size;
        this.Default_Value    =   Default_Value;
        this.IO_Type          =   IO_Type;
            
    }
    
    public String getVariable_Name()   { return Variable_Name ;  }
    public String getData_Type()       { return Data_Type ;      }
    public String getSize()            { return Size ;           }
    public String getDefault_Value()   { return Default_Value ;  }
    public String getIO_Type()         { return IO_Type ;        }
    
    public void setVariable_Name(String Variable_Name)      { this.Variable_Name    =   Variable_Name ; }
    public void setData_Type(String Data_Type)              { this.Data_Type        =   Data_Type ;     }
    public void setSize(String Size)                        { this.Size             =   Size ;          }
    public void setDefault_Value(String Default_Value)      { this.Default_Value    =   Default_Value ; }
    public void setIO_Type(String IO_Type)                  { this.IO_Type          =   IO_Type;        }
    
    }

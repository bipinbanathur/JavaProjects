package codgen;

import org.eclipse.swt.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.browser.*;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.text.html.*;
//import javax.swing.text.html.HTML.Attribute;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
//import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.ElementIterator;
//import javax.swing.text.Style;

//import org.apache.poi.hssf.usermodel.HSSFSheet;

//import javax.swing.text.StyleConstants;


//import javax.swing.text.StyleConstants;










//import java.net.URL;
import java.util.Arrays;
import java.util.Enumeration;
//import java.util.Enumeration;
//import java.util.Hashtable;
import java.io.ByteArrayInputStream;
//import java.io.IOException;
//import java.util.Properties;
//import java.util.Enumeration;
//import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

public class BrowserExample 
{
		final 	static java.util.List<String>   htmlElements =  Arrays.asList(new String []{"img","input","select","a","button","label","table","th","ul","ol","dl","dt","li"});
		static boolean generateActive = false;
		static String staticPart = "http://rws3260202.us.oracle.com:8000";
		
		
		public static void main(String [] args) 
		{
			
				final Display display = new Display();
				final Shell shell = new Shell(display);
				
				GridLayout gridLayout = new GridLayout();
				gridLayout.numColumns = 3;
				
				shell.setLayout(gridLayout);
				
				ToolBar 		toolbar 				= 	new ToolBar(shell, SWT.NONE);
				ToolItem 	itemBack 			= 	new ToolItem(toolbar, SWT.PUSH);
				ToolItem 	itemForward 	= 	new ToolItem(toolbar, SWT.PUSH);
				ToolItem 	itemStop 			= 	new ToolItem(toolbar, SWT.PUSH);
				ToolItem 	itemRefresh 		= 	new ToolItem(toolbar, SWT.PUSH);
				ToolItem 	itemGo 				= 	new ToolItem(toolbar, SWT.PUSH);
				ToolItem 	itemGen 			= 	new ToolItem(toolbar, SWT.PUSH);
				
				itemForward.setText("Forward");
				itemStop.setText("Stop");
				itemRefresh.setText("Refresh");
				itemBack.setText("Back");
				itemGo.setText("Go");
				itemGen.setText("Generate");
				
				GridData data 				= 		new GridData();
				data.horizontalSpan 	= 		3;
				toolbar.setLayoutData(data);
		
				Label labelAddress 		= 		new Label(shell, SWT.NONE);
				labelAddress.setText("Address");
				
				final Text location 		= 		new Text(shell, SWT.BORDER);
				data = new GridData();
				data.horizontalAlignment 				= GridData.FILL;
				data.horizontalSpan 						= 	2;
				data.grabExcessHorizontalSpace 	=	 true;
				location.setLayoutData(data);
		
				final Browser browser;
				try 
				{
						browser = new Browser(shell, SWT.NONE);
				} 
				catch (SWTError e)
				{
						System.out.println("Could not instantiate Browser: " + e.getMessage());
						display.dispose();
						return;
				}
				data = new GridData();
				data.horizontalAlignment 				= 	GridData.FILL;
				data.verticalAlignment 					= 	GridData.FILL;
				data.horizontalSpan 						= 	3;
				data.grabExcessHorizontalSpace 	= 	true;
				data.grabExcessVerticalSpace 		= 	true;
				browser.setLayoutData(data);

				final Label status = new Label(shell, SWT.NONE);
				data = new GridData(GridData.FILL_HORIZONTAL);
				data.horizontalSpan = 2;
				status.setLayoutData(data);
		
				final ProgressBar progressBar = new ProgressBar(shell, SWT.NONE);
				data = new GridData();
				data.horizontalAlignment = GridData.END;
				progressBar.setLayoutData(data);

		
				/* event handling */
				Listener listener = new Listener() 
				{
						   @Override
							public void handleEvent(Event event) 
							{
										ToolItem item 	= (ToolItem)event.widget;
										String string 		= item.getText();
								
										if (string.equals("Back")) 					browser.back(); 
										else if (string.equals("Forward")) 	browser.forward();
										else if (string.equals("Stop")) 			browser.stop();
										else if (string.equals("Refresh")) 		browser.refresh();
										else if (string.equals("Go")) 				browser.setUrl(location.getText());
										else if (string.equals("Generate")) 	displayElements(browser.getText(),shell,display);
							}
				};
				browser.addProgressListener(new ProgressListener() 
				{
							@Override
							public void changed(ProgressEvent event) 
							{
								if (event.total == 0) return;                            
								int ratio = event.current * 100 / event.total;
								progressBar.setSelection(ratio);
							}
							@Override
							public void completed(ProgressEvent event)
							{
								progressBar.setSelection(0);
							}
				});
				browser.addStatusTextListener(new StatusTextListener()
				{
							@Override
							public void changed(StatusTextEvent event) 
							{
								status.setText(event.text);	
							}
				});
				browser.addLocationListener(new LocationListener() 
				{
							@Override
							public void changed(LocationEvent event)
							{
								if (event.top) location.setText(event.location);
							}
							@Override
							public void changing(LocationEvent event) 
							{
							}
				});
				
				itemBack.addListener(SWT.Selection, listener);
				itemForward.addListener(SWT.Selection, listener);
				itemStop.addListener(SWT.Selection, listener);
				itemRefresh.addListener(SWT.Selection, listener);
				itemGo.addListener(SWT.Selection, listener);
				itemGen.addListener(SWT.Selection, listener);
				
				location.addListener(SWT.DefaultSelection, new Listener() 
				{
							@Override
							public void handleEvent(Event e) 
							{
								browser.setUrl(location.getText());
							}
				});
				
				shell.open();
				//browser.setUrl("");
				
				while (!shell.isDisposed()) 
				{
							if (!display.readAndDispatch())
							display.sleep();
				}
				display.dispose();
	}
		
	public static void displayElements(String htmlSource,Shell shell,Display display)
	{			
				try
				{					
						generateActive = true;
				        Shell htmElements = new Shell(shell, SWT.TITLE|SWT.CLOSE|SWT.RESIZE);
				        htmElements.setSize(600, 300);
				        htmElements.setLocation(350, 200);
				        htmElements.setText("HTML Elements");
				        
				            
				        GridLayout gridlayout = new GridLayout();
				        htmElements.setLayout(gridlayout);
				        
				        GridData tool_bar_grid_data                     				   = 	new GridData();
				        tool_bar_grid_data.horizontalAlignment          	   = 	SWT.FILL;
				        tool_bar_grid_data.grabExcessHorizontalSpace    = 	true;
				       				        
				        GridData table_grid_data                        					= 	new GridData();
				        table_grid_data.horizontalAlignment             			= 	SWT.FILL;
				        table_grid_data.grabExcessHorizontalSpace      	 	= 	true;
				        table_grid_data.verticalAlignment               				= 	SWT.FILL;
				        table_grid_data.grabExcessVerticalSpace         		= 	true;
				        								        	      
				        ToolBar toolbar 					= new ToolBar(htmElements, SWT.FLAT | SWT.WRAP | SWT.RIGHT);
				        toolbar.setLayoutData(tool_bar_grid_data);
				        
				        final Table table 					=  new Table(htmElements, SWT.BORDER|SWT.MULTI|SWT.V_SCROLL|SWT.H_SCROLL|SWT.CHECK);
				        table.setLayoutData(table_grid_data);
				        table.setHeaderVisible(true);
				        table.setLinesVisible(true);
			
			
						ToolItem 	itemBack 			= 	new ToolItem(toolbar, SWT.PUSH);
						itemBack.setText("View");
						
						Listener listener = new Listener() 
						{
								@Override
								public void handleEvent(Event event) 
								{
										ToolItem item 	= (ToolItem)event.widget;
										String string 		= item.getText();
									
										if (string.equals("View")) viewHTML(table);			
								}
						};
						itemBack.addListener(SWT.Selection, listener);
						
			
				        
			
				        TableColumn column_0 		= 		new TableColumn(table, SWT.LEFT);                
				        TableColumn column_1 		= 		new TableColumn(table, SWT.LEFT);
				        TableColumn column_2 		= 		new TableColumn(table, SWT.LEFT);
				        TableColumn column_3 		= 		new TableColumn(table, SWT.LEFT);
				        TableColumn column_4 		= 		new TableColumn(table, SWT.LEFT);
				        TableColumn column_5 		=	 	new TableColumn(table, SWT.LEFT);
				        TableColumn column_6 		= 		new TableColumn(table, SWT.LEFT);
				        TableColumn column_7 		= 		new TableColumn(table, SWT.LEFT);                
				        TableColumn column_8 		= 		new TableColumn(table, SWT.LEFT);
				        TableColumn column_9 		= 		new TableColumn(table, SWT.LEFT);
				        TableColumn column_10 	= 		new TableColumn(table, SWT.LEFT);
			
				        String idAttribute				= 		"";
				        String nameAttribute			= 		"";
				        String typeAttribute			= 		"";
				        String sourceAttribute		= 		"";
				        String linkAttribute				= 		"";
				        String textAttribute				=		"";
				        String valueAttribute			= 		"";
				        String altAttribute				=	 	"";
				        String htmSource					= 		"";
				        
				        column_0.setText("Element Name");
				        column_1.setText("Parent Element");
				        column_2.setText("ID");
				        column_3.setText("Name");
				        column_4.setText("Type");
				        column_5.setText("Source");
				        column_6.setText("Link");
				        column_7.setText("Text");
				        column_8.setText("Value");
				        column_9.setText("Alternate Text");
				        column_10.setText("HTML Source");
			
				        column_0.pack();
				        column_1.pack();
				        column_2.pack();
				        column_3.pack();
				        column_4.pack();
				        column_5.pack();
				        column_6.pack();
				        column_7.pack();
				        column_8.pack();
				        column_9.pack();
				        column_10.pack();
				        
						
						HTMLEditorKit 		kit 				= new HTMLEditorKit(); 
						HTMLDocument 		doc 				= (HTMLDocument) kit.createDefaultDocument(); 
				  
			
						doc.putProperty("IgnoreCharsetDirective", Boolean.TRUE);
						Reader HTMLReader = new InputStreamReader(new ByteArrayInputStream(htmlSource.getBytes())); 						
						kit.read(HTMLReader, doc, 0); 
			
						ElementIterator elementIterator = 	new ElementIterator(doc); 
						Element 	htmlElement					= 	null; 
						Element 	parentElement				= 	null;
						String 		 	elementName 				= 	null ;
						String 		 	parentElementName	= 	null;
														
						while( (htmlElement = elementIterator.next()) != null  ) 
						{ 
							
								elementName 	= htmlElement.getName();
								parentElement = htmlElement.getParentElement();		
								if(htmlElements.contains(elementName))
								{													
										htmSource	= getSource(doc,htmlElement);												
										if (parentElement == null) parentElementName = ""; else parentElementName = parentElement.getName();
								
							    		 AttributeSet attributeSet = htmlElement.getAttributes();	
							    		 if(attributeSet.isDefined(HTML.Attribute.ID)) 				idAttribute			= (String) attributeSet.getAttribute(	HTML.Attribute.ID);			else idAttribute 			=	"";
							    		 if(attributeSet.isDefined(HTML.Attribute.NAME)) 		nameAttribute		= (String) attributeSet.getAttribute(	HTML.Attribute.NAME);		else nameAttribute	 	=	"";	
							    		 if(attributeSet.isDefined(HTML.Attribute.TYPE)) 		typeAttribute		= (String) attributeSet.getAttribute(	HTML.Attribute.TYPE);		else typeAttribute		 =	"";	
							    		 if(attributeSet.isDefined(HTML.Attribute.SRC)) 			sourceAttribute	= (String) attributeSet.getAttribute(	HTML.Attribute.SRC);			else sourceAttribute 	=	"";	
							    		 if(attributeSet.isDefined(HTML.Attribute.LINK)) 		linkAttribute			= (String) attributeSet.getAttribute(	HTML.Attribute.LINK);		else linkAttribute 		=	"";	
							    		 if(attributeSet.isDefined(HTML.Attribute.TEXT)) 		textAttribute			= (String) attributeSet.getAttribute(	HTML.Attribute.TEXT);		else textAttribute 		=	"";	
							    		 if(attributeSet.isDefined(HTML.Attribute.VALUE)) 		valueAttribute		= (String) attributeSet.getAttribute(	HTML.Attribute.VALUE);	else valueAttribute 	=	"";		
							    		 if(attributeSet.isDefined(HTML.Attribute.ALT)) 			altAttribute			= (String) attributeSet.getAttribute(	HTML.Attribute.ALT);			else altAttribute 			=	"";		
							    					
							    		 if(! typeAttribute.equalsIgnoreCase("hidden"))
							    		 {
							    			 	TableItem item          			=   new TableItem(table,SWT.NONE);
							    			 	item.setText(new String[] {elementName, parentElementName,idAttribute,nameAttribute,typeAttribute,sourceAttribute,linkAttribute,textAttribute,valueAttribute,altAttribute,htmSource});  
							    		}
								}
							}
						
			
				        	EnableTableEditing(display,table);                
				        	htmElements.open();
							generateActive = true;
		}
		catch(Exception e)
		{
				System.out.println(e);
				e.printStackTrace();
		}
		
	
	}
		
	private static String  getSource(HTMLDocument htmlDoc, Element element)    throws BadLocationException
	{
					String elementSource 	= 		 "<html> <";
			        AttributeSet attrSet 	= 		 element.getAttributes();		       
			       	elementSource 				+=	 element.getName()+ "  "; 
			        
			        Enumeration<?> attrNames = attrSet.getAttributeNames();
			        while (attrNames.hasMoreElements()) 
			        {
				            	Object attr 						= attrNames.nextElement();		            		           
				            	String attributeName 		= (String)attr.toString();
				            	attributeName 					= attributeName.trim();
				            	
				            	if(attributeName.equals("src") )
				            	{	
					            	   //System.out.println("Inside Source Attribute  Condition "+attr);
				            			elementSource += " "+attr+ " =  '"+staticPart+attrSet.getAttribute(attr) +"' ,";
				            	}		            	
				            	else elementSource += " "+attr+ " =  '"+attrSet.getAttribute(attr) +"' ,";  
			        }
			        
			        if(elementSource.endsWith(",")) elementSource = elementSource.substring(0, elementSource.length()-1).trim()+" />  </html>";
			        return elementSource;		
			       	            
	            	//System.out.println(""+ "Element: '" + element.toString().trim()  + "', name: '" + element.getName() + "', children: " + element.getElementCount() + ", attributes: " + attrSet.getAttributeCount()  + ", leaf: " + element.isLeaf());
	            	//System.out.println("  Attribute: '" + attr + "', Value: '"+ attrSet.getAttribute(attr) + "'");
	            	//Object tag = attrSet.getAttribute(StyleConstants.NameAttribute);  if (attr == StyleConstants.NameAttribute     && tag == HTML.Tag.CONTENT) 
	            	//{
	            		//int startOffset 	= element.getStartOffset();
	                	//int endOffset 	= element.getEndOffset();
	                	//int length 			= endOffset - startOffset;
	                	//System.out.printf("    Content (%d-%d): '%s'\n", startOffset,  endOffset, htmlDoc.getText(startOffset, length).trim());
	            	//}
	 }
			    
	 static void EnableTableEditing(final Display display,Table table1) 
	 {
		        final Table tab = table1;
		        final TableEditor editor    		= new TableEditor(tab);
		        editor.horizontalAlignment  	= SWT.LEFT;
		        editor.grabHorizontal       		= true;
		            
		        tab.addListener(SWT.MouseDown, new Listener()
		        {
		                    public void handleEvent(Event event)
		                    {		                    	
				                        Rectangle clientArea = tab.getClientArea();
				                        Point 			pt = new Point(event.x, event.y);
				                        int index = tab.getTopIndex();
				                        while (index < tab.getItemCount())
				                        {
					                            boolean visible = false;
					                            final TableItem item = tab.getItem(index);
					                            for (int i = 0; i < tab.getColumnCount(); i++) 
					                            {
						                                Rectangle rect = item.getBounds(i);
						                                if (rect.contains(pt))
						                                {
							                                    final int column = i;
							                                    item.setBackground(i, display.getSystemColor (SWT.COLOR_WHITE));
							                                    final Text text = new Text(tab, SWT.NONE);
							                                    Listener textListener = new Listener() 
							                                    {
								                                         public void handleEvent(final Event e) 
								                                         {								                                             
									                                            switch (e.type) 
									                                            {
											                                                case SWT.FocusOut:	                                              	                                                    
											                                                    	item.setText(column, text.getText());
											                                                    	text.dispose();
											                                                    	break;
											                                            
											                                                case SWT.Traverse:	                                                
											                                                    	switch (e.detail)
											                                                    	{
												                                                        	case SWT.TRAVERSE_RETURN:	                                                       	                                                               
												                                                                item.setText(column, text.getText());
												                                                                 // FALL THROUGH
												                                                        	case SWT.TRAVERSE_ESCAPE: 	                                                      	                                                               
												                                                                text.dispose();
												                                                                e.doit = false;
											                                                    	}
											                                                    	break;
									                                                }
								                                            }
						                                        };
						                                        text.addListener(SWT.FocusOut, textListener);
						                                        text.addListener(SWT.Traverse, textListener);
						                                        editor.setEditor(text, item, i);
						                                        text.setText(item.getText(i));
						                                        text.selectAll();
						                                        text.setFocus();
						                                        return;
						                        }
						                        if (!visible && rect.intersects(clientArea)) { visible = true; }
						              }
						              if (!visible)return;
						              index++;
				            }
		            }
		    });
	        
	    }

		static void viewHTML(Table table)
		{
				try
				{
		            			TableItem [] items = table.getItems ();
		            			for (int i = 0; i < items.length; i++) 
		            			{		            					
			            					if(items[i].getChecked())
			            					{
				            						String text    = items[i].getText(10);
				            						
				            						System.out.println(text);
				                            	
				            						JFrame f = new JFrame("HTMLDocument Structure");
				            						final JEditorPane ep = new JEditorPane();
				            						ep.setContentType("text/html");
				                                
				            						ep.setEditable(false);
				                                
				            						ep.setText(text);
				                                
				            						f.getContentPane().add(new JScrollPane(ep));
				            						f.setSize(400, 300);
				            						f.setVisible(true);		            					
			            					}		            				
		            			}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}


            
		}
}

package codgen;
import java.io.*;

import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class ConnectionXML
{
    

    
    public ConnectionXML() 
    {
        
    }
        
    public static String getConnectionXML()
    {
        String connection_xml = "";
        try 
        {
            String path = new File(".").getCanonicalPath();            
            //if(path.indexOf("\\")!= -1) path = path.substring(0,path.lastIndexOf("\\"));
            connection_xml = path+"\\config\\connections.xml";
            return connection_xml;
        }
        catch(Exception e) 
        {
            System.out.println("Exception While Loading Tree "+e);  
        }
        return connection_xml;
        
    }
    
    public static String getImagePath()
    {
        String connection_xml = "";
        try 
        {
            String path = new File(".").getCanonicalPath();
            //if(path.indexOf("\\")!= -1) path = path.substring(0,path.lastIndexOf("\\"));
            connection_xml = path+"\\images";
            return connection_xml;
        }
        catch(Exception e) 
        {
            System.out.println("Exception While Loading Tree "+e);  
        }
        return connection_xml;
        
    }
    
    public static String getTemplatesPath()
    {
        String connection_xml = "";
        try 
        {
            String path = new File(".").getCanonicalPath();
            //if(path.indexOf("\\")!= -1) path = path.substring(0,path.lastIndexOf("\\"));
            connection_xml = path+"\\templates";
            return connection_xml;
        }
        catch(Exception e) 
        {
            System.out.println("Exception While Loading Tree "+e);  
        }
        return connection_xml;
        
    }
    
    
    public static String GetConnectionDetails(String connection_name)
    {                
        String host         =   "";
        String sid          =   "";
        String user         =   "";
        String  port        =   "";
        String password     =   "";
        String conn_string  =   null;
        
        try
        {
            File                    xml_file             = new File(getConnectionXML());
            DocumentBuilderFactory  document_factory     = DocumentBuilderFactory.newInstance();
            DocumentBuilder         document_builder     = document_factory.newDocumentBuilder();
            Document                document             = document_builder.parse(xml_file);            
            NodeList                nodes                = document.getElementsByTagName("connection");

            
            for( int i= 0;  i < nodes.getLength();i++)
            {
                
                    Node node = nodes.item(i);                 
                    if(  node.getNodeName().equals("connection")  )   
                    {                  
                        NamedNodeMap attributes = node.getAttributes();                        
                        for(int j = 0 ; j < attributes.getLength() ; j ++ )
                        {   String attribute = attributes.item(j).toString();
                            if(attribute.indexOf("name=") != -1) attribute = attribute.substring(attribute.indexOf("name=")+6,attribute.length()-1 ); 
                            
                            if(attribute.equals(connection_name)) 
                            {       
                                
                                    NodeList nl = node.getChildNodes();
                                    for(int k = 0; k < nl.getLength(); k++)
                                    {
                                        if(nl.item(k).getNodeName().equals("host"))     host        = nl.item(k).getTextContent();
                                        if(nl.item(k).getNodeName().equals("port"))     port        = nl.item(k).getTextContent();
                                        if(nl.item(k).getNodeName().equals("sid"))      sid         = nl.item(k).getTextContent();
                                        if(nl.item(k).getNodeName().equals("user"))     user        = nl.item(k).getTextContent();
                                        if(nl.item(k).getNodeName().equals("password")) password    = nl.item(k).getTextContent();
                                        
                                    }
                                    
                                    conn_string = "jdbc:oracle:thin:@"+host+":"+port+":"+sid+"<111>"+user+"<222>"+password+"<333>";
                                    return conn_string;
                            }
                        
                        }

                }
            }
            
            
        }
        catch(Exception e)        
        {
            System.out.println("Exception While Loading Tree "+e);  
        }
        return conn_string;
        
    }

    private static boolean CheckConnectionExists(String connection_name) 
    {
        boolean flag = false;
        try
        {
            File                    xml_file             = new File(getConnectionXML());
            DocumentBuilderFactory  document_factory     = DocumentBuilderFactory.newInstance();
            DocumentBuilder         document_builder     = document_factory.newDocumentBuilder();
            Document                document             = document_builder.parse(xml_file);            
            NodeList                nodes                = document.getElementsByTagName("*");
            
            for( int i= 0;  i < nodes.getLength();i++)
            {
                    Node node = nodes.item(i); 
                
                    if(  node.getNodeName().equals("connection")  )   
                    {
                        NamedNodeMap attributes = node.getAttributes();
                        
                        for(int j = 0 ; j < attributes.getLength() ; j ++ )
                        {
                            String attribute = attributes.item(j).toString();
                            if(attribute.indexOf("name=") != -1)
                            attribute = attribute.substring(attribute.indexOf("name=")+6,attribute.length()-1 );                                
                            if(attribute.equals(connection_name)) return true;
                        }
                        
                    }

            }
            
        }
        catch(Exception e)        
        {
            System.out.println("Exception While Loading Tree "+e);  
        }
        return flag;
        
    }
    
    
    public static String CreateNewConnection(String host_name,String service_id,String port_number,String user_name, String password ) 
    {    
        String Create_Status = null;
        try        
        {
            File xml_file = new File(getConnectionXML());
            
            DocumentBuilderFactory  document_factory     = DocumentBuilderFactory.newInstance();
            DocumentBuilder         document_builder     = document_factory.newDocumentBuilder();
            Document                document             = null;
            Element                 root                 = null;
            Element                 connection           = null;
            
            if(xml_file.exists())
            {
                document    = document_builder.parse(xml_file);
                root        = document.getDocumentElement(); 
                if(CheckConnectionExists(service_id)) return "Already Exists";
            }
            else 
            {
                // Root element
                document    = document_builder.newDocument();
                root        = document.createElement("connections");
                document.appendChild(root);
                    
            }
                

                connection  = document.createElement("connection");
                root.appendChild(connection);
                connection.setAttribute("name",service_id);
                

                //Host
                Element host = document.createElement("host");
                host.appendChild(document.createTextNode(host_name));
                connection.appendChild(host);
                
                //Port
                Element port = document.createElement("port");
                port.appendChild(document.createTextNode(port_number));
                connection.appendChild(port);
                
                //SID
                Element sid = document.createElement("sid");
                sid.appendChild(document.createTextNode(service_id));
                connection.appendChild(sid);
                
                //User
                Element user = document.createElement("user");
                user.appendChild(document.createTextNode(user_name));
                connection.appendChild(user);
                
                //Password
                Element pwd = document.createElement("password");
                pwd.appendChild(document.createTextNode(password));
                connection.appendChild(pwd);
                
                // write the content into xml file
                TransformerFactory  transformerFactory  = TransformerFactory.newInstance();
                Transformer         transformer         = transformerFactory.newTransformer();
                                    
                DOMSource           source              = new DOMSource(document);
                StreamResult        result              = new StreamResult(xml_file); 
                
                transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                transformer.transform(source, result);
                Create_Status = "Created";                            

            
            
        }
        catch(Exception e) 
        {
            System.out.println("Exception While Loading Tree "+e);
            
        }
        return Create_Status;
        
    }
        
    public static ArrayList<String> GetConnectionNames() 
    {
        ArrayList<String> conn_names =null;
        
        try
        {
                                    conn_names           = new ArrayList<String>();
            File                    xml_file             = new File(getConnectionXML());
            if(xml_file.exists())
            {
                DocumentBuilderFactory  document_factory     = DocumentBuilderFactory.newInstance();
                DocumentBuilder         document_builder     = document_factory.newDocumentBuilder();
                Document                document             = document_builder.parse(xml_file);            
                NodeList                nodes                = document.getElementsByTagName("*");
                
                for( int i= 0;  i < nodes.getLength();i++)
                {
                        Node node = nodes.item(i); 
                    
                        if(  node.getNodeName().equals("connection")  )   
                        {
                            NamedNodeMap attributes = node.getAttributes();
                            
                            for(int j = 0 ; j < attributes.getLength() ; j ++ )
                            {
                                String attribute = attributes.item(j).toString();
                                if(attribute.indexOf("name=") != -1)
                                attribute = attribute.substring(attribute.indexOf("name=")+6,attribute.length()-1 );                                
                                conn_names.add(attribute);
                            }
                            
                        }

                }
                
            }
           
            
        }
        catch(Exception e)
        {
            System.out.println("Exception While Loading Tree "+e);
        }
        
        return conn_names;
        
        
    }

    public static String UpdateConnectionDetails(String connection_details)
    {
        String return_message = "";
        return return_message;
        
    }
    
    public static String DeleteConnection(String connection_name)
    {
        String return_message = "";
        return return_message;
    
    }

}

package codgen;

import java.io.Serializable;

@SuppressWarnings("serial")
public class SDTVariableAssginment  implements Serializable 
{
    String Variable_Name    = "";
    String Data_Type        ="";
    String AssginedValue    ="";
    
    SDTVariableAssginment(String Variable_Name, String Data_Type , String AssginedValue )
    {
            this.Variable_Name = Variable_Name;
            this.Data_Type     = Data_Type;
            this.AssginedValue = AssginedValue;
    
    }
    
    public String getVariableName()
    {
            return Variable_Name;
    }
    
     public String getData_Type()
    {
            return Data_Type;
    }
    
    public String getAssginedValue()
    {
            return AssginedValue;    
    }
    
    public void setVariableName(String VariableName)
    {
            this.Variable_Name = VariableName; 
    }
    
     public void  setData_Type(String DataType)
    {
            this.Data_Type = DataType;
    }
    
    public void setAssginedValue(String AssginedValue)
    {
            this.AssginedValue = AssginedValue;
    
    }
}

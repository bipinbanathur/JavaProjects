package codgen;

import java.io.Serializable;

import java.util.Hashtable;


@SuppressWarnings("serial")
public class UDTVariableAssignment   implements Serializable 
{
    int                         record          =   0;
    String                      variable_name   =   "";
    String                      data_type       =   "";
    Hashtable<String,String>    rec_data        =   null; 
    
    
    public UDTVariableAssignment() 
    {
        
    }
    
    
	public UDTVariableAssignment(int record,String variable_name,String data_type,Hashtable<String,String> rec_data) 
    {
         this.record            =   record;
         this.variable_name     =   variable_name;
         this.data_type         =   data_type;
         this.rec_data          =   rec_data;         
    }
    
    public void setRecord(int record)                   			   { this.record 		= record;         }
    public void setVariableName(String  variable_name)  			   { this.variable_name = variable_name;  }
    public void setDataType(String  data_type)          			   { this.data_type 	= data_type;      }
    public void setRecordData(Hashtable<String,String>  rec_data)      { this.rec_data 		= rec_data;       }
    
    public int       				getRecord()                        { return record;           }
    public String    				getVariableName()                  { return variable_name;    }
    public String    				getDataType()                      { return data_type;        }
    public Hashtable<String,String> getRecordData()                    { return rec_data;         }
}

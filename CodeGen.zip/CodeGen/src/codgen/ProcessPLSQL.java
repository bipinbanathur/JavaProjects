package codgen;

import java.sql.*;
import java.util.*;
import java.util.regex.*;
import java.util.Hashtable;
import org.apache.poi.hssf.usermodel.*;
import java.io.FileOutputStream;

public class ProcessPLSQL 
{
	
    String                              								Variable_Name           		=   	"";
    String                              								Data_Type               			=   	"";
    String                              								Size                    					=   	"";
    String                              								Default_Value           			=   	"";
    String                              								IO_Type                 				=   	"";
    Connection 													con     									=   	null;
    DatabaseMetaData										meta    								=   	null;          
    String 																procedure_name    			=   	null;
    String 																catalog_name    				=   	null;
    Hashtable<String,String>            				proc_parameters         		=   	null;
    ArrayList<VariableDeclaration>      		 	procedure_parameters    =   	null;
    ArrayList<String>      								 	udt_parameters				=   	null;	
    ArrayList<UDTVariableAssignment>   	udt_params						=	 	null; 
    StringBuffer                       	 						buffer                 				 	=   	null;
    boolean                             							comment                 			=   	false;  
    int                                 									procedure_count         		=   	0;    
    final java.util.List<String>        					standard_types          		=   	Arrays.asList(new String []{"VARCHAR","VARCHAR2","NUMBER","DATE","TIMESTAMP","BOOLEAN"});
    
    
	
    public ProcessPLSQL(String conn_name)
    {Connect(conn_name); }
    
    public ProcessPLSQL(String procedure , String catalog, String connection_name)
    {
            try
            {                    
                    procedure_name          		=       procedure;
                    catalog_name           		 	=       catalog;                                    
                    proc_parameters         		=       new Hashtable<String, String>();
                    procedure_parameters   	=       new ArrayList<VariableDeclaration>();
                    udt_parameters         		=       new ArrayList<String>();                                    
                    udt_params              			=       new ArrayList<UDTVariableAssignment>();               
                    
                    Connect(connection_name);      
                    ReadCatalogData();
                    //CreateDataTemplte();
                
            }
            catch(Exception e)
            {
                    System.out.println("Exception Occured : "+e);
                    e.printStackTrace();
                    
            }    
    }
            
    private void Connect(String connection_name )
    {
    	try
    	{   
                    
    		String connection_string    =   ConnectionXML.GetConnectionDetails(connection_name);
    		String conn_part           	 	=   "";
    		String user                 			=   "";
    		String password             		=   "";
                
    		if ( (connection_string.indexOf("<111>")!= -1) && (connection_string.indexOf("<222>")!= -1)) 
    		{
                	conn_part   	= connection_string.substring(0, connection_string.indexOf("<111>"));   
                	user        			= connection_string.substring( connection_string.indexOf("<111>")+5, connection_string.indexOf("<222>") );                
                	password    	= connection_string.substring(connection_string.indexOf("<222>")+5, connection_string.length()-5);
    		}                                              
    		Class.forName("oracle.jdbc.driver.OracleDriver");  
    		con          	= DriverManager.getConnection(conn_part,user,password);                                      
    		meta          =  con.getMetaData(); 
    		con.setAutoCommit(true);                                      
    	}
    	catch(Exception e)
    	{
    		System.out.println("Exception Occured : "+e);
    		e.printStackTrace();                    
    	}
            
    }
		
    public boolean CompileProcedure(String procedure_code) 
    {
        boolean status = true;
        try 
        {
            con.setAutoCommit(true);
            Statement st 	= con.createStatement();
            status 				= st.execute(procedure_code);
            return status;
  
        }
        catch(Exception e) 
        {
           System.out.println("Exection while Compiling Procedure in the Database : "+e) ;
        }
        return status;                
    }

    public ArrayList<String> ViewResults() 
    {
        ArrayList<String> array  = null;
        ResultSet rs = null;
        String str ="";
        try
        {
            Statement st  = con.createStatement();
            rs 					= st.executeQuery("SELECT * FROM API_DEBUG_TABLE");
            array 				= new ArrayList<String>();
            str 					= String.format("%-5s %-80s %-10s \n" ,"No." ,   "Message" , "Time" );
            
            array.add(str);
            while(rs.next()) 
            {
                str = String.format("%-5s %-80s %-10s \n" , new Integer(rs.getInt(1)).toString() ,  rs.getString(2) , rs.getDate(3 ));
                array.add(str);
                            
            }
            return array;
   
        }
        catch(Exception e) 
        {
           System.out.println("Exection while Fetching Data from Debug Table : "+e) ;
        }
        return array;
    }

    public void ReadCatalogData()
    {    	
		String 		text 					= 	"";
		int         	row_count 		= 	0;
		int 	    	counter   			= 	0;                            
		try
		{
			Statement 	st1 		=   con.createStatement();
			Statement 	st2 		=   con.createStatement();
			ResultSet 	cnt 		=   st1.executeQuery("SELECT COUNT(TEXT)  FROM ALL_SOURCE WHERE NAME = '"+catalog_name+"' AND TYPE = 'PACKAGE'");			
			ResultSet 	rs 		=   st2.executeQuery("SELECT TEXT  FROM ALL_SOURCE WHERE NAME = '"+catalog_name +"' AND TYPE = 'PACKAGE'");				 	    
			buffer		            	=   new StringBuffer();
			                                            
			if(cnt.next()) row_count = cnt.getInt(1);	 	                                    
			
			while( (rs.next()) && (counter < row_count))
			{
				text            		= rs.getString(1);
				text            		= text.toUpperCase();			
				String data     = removeComments(text);
				
				if(data.indexOf("\t")!= -1 ) 	data = data.replaceAll("\t", " ");
				
				data = data.replaceAll("( )+", " ");
				
				if(!data.equals(""))					
				buffer.append(data);
			}   
			
			StringTokenizer st	 	= new StringTokenizer(buffer.toString(), ";");    
			
			while (st.hasMoreElements()) 
			{
				String token 	= (String) st.nextElement();				
				token  	        = token.trim();

				System.out.println(token);
				
				if(token.indexOf("PROCEDURE")!= -1 && token.indexOf(procedure_name)!= -1 && token.indexOf("(")!= -1)
				{			            
					String proc_name = token.substring(token.indexOf("PROCEDURE")+10,token.indexOf("(")).trim();			            
					if ( ( proc_name.equals(procedure_name) && procedure_count == 0))
					{
						procedure_count++;
						ReadProcedureParameters(token); 
					}        						
				}
             }
			                                                                         
		}
		catch(Exception e)
		{
			System.out.println("Exception Occured : "+e);
			e.printStackTrace();			
		}		
    }
	
    public Hashtable<String,String> GetTypeData (String udt_name)
    {
        StringBuffer        					buff        			=   new StringBuffer();
        Hashtable<String,String>    rec_params  	=   null;
		String 										pkg_name		=	"";
		String 										typ_name		=	"";
		String 										rec_name		=	"";	
        String              						text        			=   "";
		boolean									flag					= 	false;
                		
		try
		{
            rec_params = new Hashtable<String,String>();						
			if(udt_name.indexOf(".")!= -1 )
			{
				pkg_name 					= udt_name.substring(0,udt_name.indexOf(".")).trim();
				typ_name 					= udt_name.substring(udt_name.indexOf(".")+1,udt_name.length()).trim();
                Statement      			statement    = con.createStatement();                            
                ResultSet      				resultset    = statement.executeQuery("SELECT TEXT  FROM ALL_SOURCE WHERE NAME LIKE '"+pkg_name+"' AND TYPE = 'PACKAGE'");
                                
                while( resultset.next())
                {
			         text        = resultset.getString(1);
			         text        = text.toUpperCase();     			         
			         String data = removeComments(text);			         
			         if(data.indexOf("\t")!= -1 ) 	data = data.replaceAll("\t", " ");						
			         data = data.replaceAll("( )+", " ");						
			         if(!data.equals("")) buff.append(data);			                    
                }                            
			}
			else
			{
				pkg_name = catalog_name;
				typ_name = udt_name.trim();
                buff     = buffer;
			}
                    
			/*---------------------------------------------------------------------------------------------------------*/
			/*---------------------------------------------------------------------------------------------------------*/
			
			StringTokenizer st	 	= new StringTokenizer(buff.toString(), ";");

			while (st.hasMoreElements()) 
			{
				String token = (String) st.nextElement();                                
				token		 = ";"+token.trim()+";";

				Pattern pattern = Pattern.compile(";TYPE.*"+typ_name+".*IS.*TABLE.*OF.*");	
				Matcher matcher = pattern.matcher(token);
				if(matcher.matches())
				{

					if(token.indexOf(" OF ")!= -1   )		token = token.replaceAll(" OF ",   "****").trim();
					if(token.indexOf(" BY ")!= -1   )       token = token.replaceAll(" BY ",   "!!!!").trim();
                                        
																				
					if(token.indexOf(" "+typ_name+" ")!= -1 && token.indexOf("****") != -1 &&  token.indexOf("!!!!") != -1 )
					{
						rec_name = token.substring(token.indexOf("****")+4,token.indexOf("!!!!")).trim();
						
						if(rec_name.endsWith("INDEX")) rec_name = rec_name.substring(0,rec_name.lastIndexOf("INDEX")).trim();
						flag = true;												
						return GetRecordParameters(buff,rec_name);							
					}
				}
			}
			if(!flag) return GetRecordParameters(buff,typ_name);	                                                                                                            
		}
		catch(Exception e)
		{
			System.out.println("Exception Occured : "+e);
			e.printStackTrace();			
		}
		return rec_params;		
    }
	
    private Hashtable<String,String> GetRecordParameters(StringBuffer buff , String rec_type_name)
    {
        Hashtable<String,String>    ht          =   null;
		String						parameters	=   "";
		String						param_name	=   "";
		String						param_type	=   "";
		
		try
		{
            ht                          = new Hashtable<String,String>();
			StringTokenizer tokens	 	= new StringTokenizer(buff.toString(), ";");
			
			while (tokens.hasMoreElements()) 
			{
				String token 	= (String) tokens.nextElement();				
				token  			= token.trim()+";";
				
				Pattern pattern = Pattern.compile(".*TYPE.*"+rec_type_name+".*IS.*RECORD.*");	
				Matcher matcher = pattern.matcher(token);
				
				if(	matcher.matches())
				{
					if(	token.indexOf("(")!= -1 && token.indexOf(rec_type_name)!= -1 && token.indexOf(");") != -1 )
					{
						parameters = token.substring(token.indexOf("(")+1,token.indexOf(");"));
						parameters = parameters.trim();
						StringTokenizer st = new StringTokenizer(parameters, ",");		
							
						while (st.hasMoreElements()) 
						{
							String param_token  = (String) st.nextElement();
							param_token         = param_token.trim();
                            if(param_token.indexOf("\t")!= -1) param_token.replaceAll("/t", " ");
                                                    
							if(param_token.indexOf(" ")!= -1)
							{
								param_name 	= param_token.substring(0,param_token.indexOf(" ")).trim();
								param_type 	= param_token.substring(param_token.indexOf(" "),param_token.length()).trim();                                                                
                                if(param_type.indexOf(":=")!=-1) param_type = param_type.substring(0,param_type.indexOf(":=")).trim();                                                                                                                                                                   
							}																					
                            ht.put(param_name,param_type);
						}						
					}				
				}
			}
			
		}
		catch(Exception e)
		{
			System.out.println("Exception Occured : "+e);
			e.printStackTrace();
			
		}
		 return ht;
    }

    public void ReadProcedureParameters(String text)
    {                
		String params 			    =	"";		
		String param 			    = 	"";
		String io_type 			    = 	"";
		String data_type 		    = 	"";
		text 			            = 	text+";";    
		
		try
		{			                                                    
			if(text.indexOf("(")!= -1 && text.indexOf(");")!= -1    )
			{
				params              = text.substring(text.indexOf("(")+1,text.indexOf(");"));
				StringTokenizer st  = new StringTokenizer(params, ",");
                                            
				while (st.hasMoreElements()) 
				{
					String token    =       (String) st.nextElement();                                    
					token           =       token.trim();
                                                    
                                                
					if(token.indexOf(" NOCOPY ")!= -1 )     token   = token.replaceAll(" NOCOPY "," ");                                            
					if(token.indexOf(" DEFAULT ")!= -1 )    token   = token.replaceAll( token.substring(token.indexOf(" DEFAULT "),token.length()) ," ");

					if( token.indexOf(" IN ")!= -1  && token.indexOf(" OUT ") != -1)
					{
						io_type = "INOUT";
						token   = token.replaceAll(" IN "," ");
						token   = token.replaceAll(" OUT "," ");
					}
                                                
					if( token.indexOf(" IN ")!= -1  && token.indexOf(" OUT ") == -1)
					{
						io_type = "IN";
						token   = token.replaceAll(" IN "," ");
					}
                                                
					if( token.indexOf(" IN ")== -1  && token.indexOf(" OUT ") != -1)
					{
						io_type = "OUT";
						token   = token.replaceAll(" OUT "," ");
					}

					token = token.trim();
                                                
					if(token.indexOf(" ")!= -1)
					param = token.substring(0,token.indexOf(" "));
                                                
					if(token.indexOf(" ")!= -1)
					data_type = token.substring(token.indexOf(" "),token.length()).trim();
                                                                                                          
					Variable_Name       = param;
					Data_Type           = data_type;
					IO_Type             = io_type;
					Size                = "";
					Data_Type           = Data_Type.trim();
                                    
					if( Data_Type.indexOf(":=")!= -1 )
					{
						Default_Value   =  Data_Type.substring(Data_Type.indexOf(":=")+2,Data_Type.length());
						Data_Type       =  Data_Type.substring(0,Data_Type.indexOf(":="));
					}
					Data_Type           = Data_Type.trim();   
                                    
					if(!standard_types.contains(Data_Type) )
					{
						if(Data_Type.indexOf(".") == -1) Data_Type = catalog_name+"."+Data_Type;
						if( Default_Value.length()> 0 && Default_Value.indexOf(".") == -1 )  Default_Value = catalog_name+"."+Default_Value;
					}   
                                        
					VariableDeclaration vd = new VariableDeclaration(Variable_Name,Data_Type,Size,Default_Value,IO_Type);                                            
					procedure_parameters.add(vd);
					proc_parameters.put(param,data_type+"  "+io_type);
                                    
					Variable_Name       = "";
					Data_Type           = "";
					Size                = "";
					Default_Value       = "";
					IO_Type             = "";
                  
				}                                                                                   
			}            
		}
		catch(Exception e)
		{
			System.out.println("Exception Occured : "+e);
			e.printStackTrace();
			
		}
    }
                  
    public String removeComments(String text)
    {
		String					non_comment1 	=	"";
		String					non_comment2	=	"";
                
				
		try
		{			
			/*---------------------------------------------------------------------*/			
			if( (text.indexOf("/*") != -1) && (text.indexOf("*/") != -1) )
			{
					if(	text.indexOf("/*") > 0)
					non_comment1 = text.substring(0,text.indexOf("/*"));		
					
					if(	text.indexOf("*/") < text.length())
					non_comment2 = text.substring(text.indexOf("*/")+2,text.length());						
										
					text = non_comment1 + non_comment2;										
					non_comment1 = ""; non_comment2 = "";												
			}		
			/*---------------------------------------------------------------------*/
			if ( (text.indexOf("/*") != -1) && (text.indexOf("*/") == -1))
			{	
				text 	= "";
				comment = true;
			}
			/*---------------------------------------------------------------------*/
			if( (text.indexOf("/*") == -1) && (text.indexOf("*/") != -1))
			{
		
				
				if(text.indexOf("*/") < text.length() && comment)
				text = text.substring(text.indexOf("*/")+2, text.length());											
				else
				text = "";				
				comment = false;					
			}
			
			/*---------------------------------------------------------------------*/
			if(comment) text = "";								
			/*---------------------------------------------------------------------*/
			
			if(text.indexOf("--") != -1)
			text = text.substring(0,text.indexOf("--"));
			/*---------------------------------------------------------------------*/
			text = text.trim();
	
		}
		catch(Exception e)
		{
			System.out.println("Exception Occured : "+e);
			e.printStackTrace();
			
		}
		return text;
		
    }
	
    public ArrayList<String>  GetUDTParameters() 
    {
        return udt_parameters;        
    }
    
    public Hashtable<String,String>   GetProcParameters() 
    {
        return proc_parameters;        
    }
    
    public ArrayList<VariableDeclaration> GetProcedureParameters() 
    {
        return procedure_parameters;        
    }
    
    public  int GetIEntityID(String query) 
    {
        ResultSet rs = null; 
        Statement st = null;
        int       id = 0;
        try 
        {
            st   = con.createStatement();
            rs   = st.executeQuery(query);
            if(rs.next())
            {
                id = rs.getInt(1);
                return id;
            }            
        }
        catch(Exception e) 
        {
            System.out.println("Exception While retrieving data"+e);
        }
        return id;
        
    }
        
    public  String GetIEntityName(String query) 
    {
        ResultSet rs    = null; 
        Statement st    = null;
        String    name  = "";
        try 
        {
            st   = con.createStatement();
            rs   = st.executeQuery(query);
            if(rs.next())
            {
                name = rs.getString(1);
                return name;
            }            
        }
        catch(Exception e) 
        {
            System.out.println("Exception While retrieving data"+e);
        }
        return name;
        
    }
    
    public Hashtable<String,String> GetTableDetails(String table_name) 
    {
        Hashtable<String,String> table_details = new Hashtable<String,String>();
        try
        {
            Statement st                    = con.createStatement();
            ResultSet rs                    = st.executeQuery("SELECT * FROM "+table_name);
            ResultSetMetaData rsmd          = rs.getMetaData();
            int count                       = rsmd.getColumnCount();
            
            for (int i=1; i <= count; i++) 
            {                                           
                    String colName = rsmd.getColumnName(i);
                    String colType = rsmd.getColumnTypeName(i);     
                    table_details.put(colName, colType);                
            } 
            st.close();
            rs.close();
            
        }
        catch(Exception e)
        {
                    System.out.println(e);  
        }
        
        return table_details;
  
    }
    
    public String CreateDataTemplte() 
    {
        FileOutputStream    fout;
        HSSFWorkbook        wb;
        HSSFSheet           sheet;
        HSSFRow             row;
        HSSFCell            cell;
        HSSFPatriarch       patr;
        HSSFComment         comment;
                
        String 						Variable_Name    =   "";
        String 						Data_Type        =   "";
        String 					 	IO_Type          =   "";
        Hashtable<String,String> 	Rec_Data      	 =   null;
        
        try 
        {
             fout    = new FileOutputStream(ConnectionXML.getTemplatesPath()+"\\"+procedure_name+".xls");
             wb      = new HSSFWorkbook();
             sheet   = wb.createSheet("Main");            
             row     = sheet.createRow((short) 0);
             patr    = sheet.createDrawingPatriarch();
             comment = patr.createComment(new HSSFClientAnchor(0, 0, 0, 0, (short)4, 2, (short) 6, 5));
            
            /* ------------------------------------------------------------------------------------------------ */
            /* ------------------------------------------------------------------------------------------------ */
            int                    j=2;
            for(int index =0; index < procedure_parameters.size(); index++)
            {
                
                VariableDeclaration vd = procedure_parameters.get(index);
                Variable_Name          = vd.getVariable_Name();
                Data_Type              	= vd.getData_Type();                        
                Size                  		 = vd.getSize();
                Default_Value          = vd.getDefault_Value();
                IO_Type                = vd.getIO_Type();    
                
                if(index==0 ) 
                {
                    cell    = row.createCell(index);   
                    cell.setCellValue("TC_KEY");
                    
                    cell    = row.createCell(index+1);   
                    cell.setCellValue("TEST_CASE");
                }
                
                if(standard_types.contains(Data_Type))                   
                {
                    if( IO_Type.equals("IN"))                       // || IO_Type.equals("INOUT") ) )
                    {
                        cell    = row.createCell(j); 
                        cell.setCellValue(Variable_Name);   
                        comment = patr.createComment(new HSSFClientAnchor(0, 0, 0, 0, (short)4, 2, (short) 6, 5));
                        comment.setString(new HSSFRichTextString(Data_Type));
                        cell.setCellComment(comment);
                        j++;
                    }
                }   
                else
                {
                    if ( IO_Type.equals("IN") )                     //|| IO_Type.equals("INOUT") ) )
                    {                            
                        Rec_Data                    =   GetTypeData(Data_Type);                        
                        UDTVariableAssignment ua    = new UDTVariableAssignment();
                        ua.setRecord(0);
                        ua.setVariableName(Variable_Name);
                        ua.setDataType(Data_Type);
                        ua.setRecordData(Rec_Data);
                        udt_params.add(ua);                        
                    }                    
                }
                
            } 
            
            
            /* ------------------------------------------------------------------------------------------------ */
            /* ------------------------------------------------------------------------------------------------ */
            
            for(int index =0; index < udt_params.size(); index++)
            {
                UDTVariableAssignment ua    = udt_params.get(index);
                Variable_Name               = ua.getVariableName();  
                Data_Type                   = ua.getDataType();
                Rec_Data                    = ua.getRecordData();                
                sheet                       = wb.createSheet(Variable_Name);            
                row                         = sheet.createRow((short) 0);  
                patr                        = sheet.createDrawingPatriarch();                
                int i                       = 0;
                
                if(i==0 ) 
                {
                    cell    = row.createCell(i);   
                    cell.setCellValue("TC_KEY");
                    comment  = patr.createComment(new HSSFClientAnchor(0, 0, 0, 0, (short)4, 2, (short) 6, 5));
                    
                    if(Data_Type.endsWith("_TBL_TYPE")) comment.setString(new HSSFRichTextString("Table Type"));
                    if(Data_Type.endsWith("_REC_TYPE")) comment.setString(new HSSFRichTextString("Record Type"));
                    
                    cell.setCellComment(comment);
                    
                    i++;
                }
                
                Enumeration<String>     parameters          = Rec_Data.keys();                                  
                Enumeration<String>     data_types          = Rec_Data.elements();   
                while ( parameters.hasMoreElements() ) 
                {
                        cell    = row.createCell(i); 
                        cell.setCellValue(parameters.nextElement()); 
                        comment                     = patr.createComment(new HSSFClientAnchor(0, 0, 0, 0, (short)4, 2, (short) 6, 5));
                        comment.setString(new HSSFRichTextString(data_types.nextElement()));
                        cell.setCellComment(comment);
                        i++;                    
                } 
 
            }        
            
            /* ------------------------------------------------------------------------------------------------ */
            /* ------------------------------------------------------------------------------------------------ */
            
                    
            wb.write(fout);
            fout.flush();
            fout.close();
            
        }
        catch(Exception e)
        {
            return e.toString();
        }

        return " Completed Data Tempate Creation";
        
    }
 
}

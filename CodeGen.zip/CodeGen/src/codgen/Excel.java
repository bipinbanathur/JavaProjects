package codgen;

import java.io.*;
import java.util.*;
import java.text.*;



import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.*;
import org.apache.poi.ss.usermodel.*;




public class Excel 
{
	

    POIFSFileSystem 								fs; 
	private   	    String         					filename     	        	= "";
	private   	    String 							sheet_name 	 			= "";
    //private        int             					rows                    		= 0;    
    private         	int             					cells                   			= 0;    
	protected 	HSSFWorkbook 		wb 								= null;
	private   	    HSSFSheet 				sheet 							= null;	
	private   	    HSSFCellStyle 			style                  		 	= null;
	private   	    HSSFDateUtil 			du                      			= null;
	private		    String[] 						sheet_names             = null;	    		
	//private 	    String[]           			header                  		= null;	
	//private 	    String[]            			data_header             	= null;		
	//private         String[] 	       		 	ColumnArr              	= null;		
	private         List<String>[] 			sheetcolumnsarr    	= null;	 
	private         List<String> 				sheets                  		= new ArrayList<String>();
    private         SimpleDateFormat    sdf                    	 		= new SimpleDateFormat("dd-mmm-yyyy");
	
	
    public Excel() 
    {    
    	filename = "";
    	process_sheet();
    }
	
    public Excel(String path) 
    {
    
    	filename = path;
        process_sheet();
    }
	
    /*
     * Opens the Sheet , 
     * Get Total Number of Sheets, 
     * Creates List sheetcolumnsarr Each element contains  list of columns 
     */
    @SuppressWarnings("unchecked")
	private void process_sheet()
    {
    	try
    	{    	

    	  FileInputStream fis   =  	new FileInputStream(filename); 
          POIFSFileSystem fs 	= 	new POIFSFileSystem(fis);
          wb 			= 	new HSSFWorkbook(fs);   
          style 	        = 	wb.createCellStyle();
          style.setFillBackgroundColor(HSSFColor.AQUA.index);
          style.setFillPattern(HSSFCellStyle.NO_FILL); 

          int num_of_sheets     =   wb.getNumberOfSheets();     				          
          sheetcolumnsarr       =   new List[num_of_sheets];
	      
	       for(int s=0;	s<num_of_sheets	;s++)
	       {
                            List<String> columnlist = new ArrayList<String>();
                            sheet 	    			= wb.getSheetAt(s);
                            sheet_name	    = wb.getSheetName(s); 
                            sheets.add(s,sheet_name.toUpperCase());	
	    	  
                            HSSFRow row   = 	sheet.getRow(0);	    
                            cells        			 = 	row.getPhysicalNumberOfCells();
	    	   
                            for(int c = 0;c<cells;c++)
                            {
                            		HSSFCell cell  			=   row.getCell(c);
                            		HSSFRichTextString   value 	=   cell.getRichStringCellValue(); 
                            		columnlist.add((value.getString()).toUpperCase());	               
                            }	           
                            sheetcolumnsarr[s] = columnlist;
	    	   
	       }
		   
	      // System.out.println("Sheet Processed Succesfully");

    	}
    	catch (Exception e)
    	{
    		 System.out.println("Exception Occurred While Constructing Workbook");
    		 System.out.println("Exception : "+e );
    		 e.printStackTrace();
    	}
    	
    }

    /*
     * Returns  name of sheets in the work book
     */
    public String[] getSheetNames()
    {

    	try
    	{
    		int sheet_count =  wb.getNumberOfSheets();
    		sheet_names 	=  new String[sheet_count];
    		for(int i=0;i< wb.getNumberOfSheets();i++)
    	    {
    	    	sheet_names[i]	= wb.getSheetAt(i).getSheetName();
    	    }
    		
    	}
    	catch (Exception e)
    	{
    		 System.out.println("Exception Occurred While Getting Sheet Names");
    		 System.out.println("Exception : "+e );
    		 e.printStackTrace();
    	}
		return sheet_names;
    	
    }
    
    /*
     * returns the number of column in a particular sheet
     */
    public int getColumns(String sheetname)
    { 
    	int column_count =0;
    	try
    	{
    		HSSFRow row  = 	wb.getSheet(sheetname).getRow(0);
    		column_count =  row.getPhysicalNumberOfCells();            	
    	}
    	catch (Exception e)
    	{
    		 System.out.println("Exception Occurred While Accessing Sheet");
    		 System.out.println("Exception : "+e );
    		 e.printStackTrace();
    	}
    	return column_count;
        
    }

    
    /*
     * returns the number of rows in a particular sheet
     */
    public int getRows(String sheetname) 
	{
    	int row_count =0;
    	try
    	{
    		return  	wb.getSheet(sheetname).getPhysicalNumberOfRows();
    	}
    	catch (Exception e)
    	{
    		 System.out.println("Exception Occurred While Accessing Sheet");
    		 System.out.println("Exception : "+e );
    		 e.printStackTrace();
    	}
    	return row_count;
    }
            
    /*
     * Returns the list of columns in a particular sheet
     */
    public List<String> getColumnlist(String sheetname)
    {
        return sheetcolumnsarr[sheets.indexOf(sheetname.toUpperCase())];
    }
    
    /*
     * Returns the Value of cell Pass Sheet Name , Row Index and Column Index
     */
    public String getvalue(String sheetname,int rw,int cl)
    {
    	
    	String vl = "";

	    try
	    {            
	    	sheet           =       wb.getSheet(sheetname);	    
	    	HSSFRow  row    = 	sheet.getRow(rw);
                HSSFCell cell   = 	row.getCell(cl);
                if( cell != null ) return getCellData(cell);

	    }
    	catch (Exception e)
    	{
    		 System.out.println("\nException Occurred While Accessing Cell Data");
    		 System.out.println("\nException : "+e );
    		 e.printStackTrace();
    	}
		return vl;
    }
   
   /*
    * Get Cell Comment /tool Tip
    */
    public String getcomment(String sheetname,int rw,int cl)
    {
        
        String vl = "";

            try
            {            
                sheet           =       wb.getSheet(sheetname);     
                HSSFRow  row    =       sheet.getRow(rw);
                HSSFCell cell   =       row.getCell(cl);
                if( cell != null ) return getCellComment(cell);

            }
        catch (Exception e)
        {
                 System.out.println("\nException Occurred While Accessing Cell Data");
                 System.out.println("\nException : "+e );
                 e.printStackTrace();
        }
                return vl;
    }
   
    /*
     *Used Internally to get the column index of a Column name in a sheet
     */
    private int getColumnindex(String sheetname,String Column)
    {
    	sheetname = sheetname.toUpperCase();
    	Column    = Column.toUpperCase();
        return sheetcolumnsarr[sheets.indexOf(sheetname)].indexOf(Column);
    }
    
    /*
     * Override of get value , Returns the cell data by specifying the row index and colum name of a particular sheet
     */
    public String getvalue(String sheetname,int row, String columnname)
    {    
        return getvalue(sheetname,row, getColumnindex(sheetname,columnname) );
    }
    
    /*
     * Get Cell Tool Tip / Comment 
     */
    public String getcomment(String sheetname,int row, String columnname)
    {    
        return getcomment(sheetname,row, getColumnindex(sheetname,columnname) );
    }
    
    /*
     * Overridden Function of : public void setvalue(String sheetname,int rw,int cl ,String data)
     * Write a new Value or Override the existing value of a  particular cell in a particular sheet
     * Specify Sheet Name ,Row Index and Column Name
     */
    
    public void setvalue(String sheetname,int row, String columnname,String data)
    {    
        setvalue(sheetname,row, getColumnindex(sheetname,columnname),data );
    }
    
    /*
     * Returns a List of Records, Implementing Parent Child Relationship here
     */
    public List<Hashtable<String,String>> get_child(String sheetname,String keycolumn,String keyvalue)
    {
    	List<Hashtable<String,String>> listht 	= new ArrayList<Hashtable<String,String>>();
    	
    	try
    	{    		    	    
    	    Sheet sheet 			= wb.getSheetAt(sheets.indexOf(sheetname.toUpperCase()));    	     	    
    	    int row_count			= sheet.getPhysicalNumberOfRows();    	        	    
    	    for(int r = 1;r<row_count;r++)
    	    {    	       
    	        String value = getvalue(sheetname,r,keycolumn);

    	        if(value.equals(keyvalue))
    	        {   	    
    	        	Hashtable<String,String> 	ht 		= 	new Hashtable<String,String>(); 
    				HSSFRow 					rw   	= 	(HSSFRow) sheet.getRow(0);	    
    			    int col_count 						= 	rw.getPhysicalNumberOfCells();
    			    
    	             for(int c = 0;	c<col_count;	c++)
    	             {
    	                             
    	                String key = (String)sheetcolumnsarr[sheets.indexOf(sheetname.toUpperCase())].get(c);
    	    	    	HSSFRow  row   = 	(HSSFRow) sheet.getRow(r);
    	    		    HSSFCell cell  = 	row.getCell(c);
    	    		    if( cell != null ) ht.put(key,getCellData(cell)); else  ht.put(key,"");
    	    		 }
    	             ht.put("PHYSICAL_ROW_NUM",new Integer(r).toString());
    	             listht.add(ht);
    	            
    	        }
    	        
    	       }
    		    		    		   
    	}
    	catch (Exception e)
    	{
    		 System.out.println("Exception Occurred While Getting Data from Sheet");
    		 System.out.println("Exception : "+e );
    		 e.printStackTrace();
    	}
		return listht;
    }
    
    
    /*
     * Returns a String array  of Physical Number of Rows, Implementing Parent Child Relationship here
     */
    public String[] get_child_row_numbers(String sheetname,String keycolumn,String keyvalue)
    {
    	List<String> 		al 		=  new ArrayList<String>();
    	String[]  	row_no 	= null;
    	
    	try
    	{    		    	    
    	    Sheet sheet 			= wb.getSheetAt(sheets.indexOf(sheetname.toUpperCase()));    	     	    
    	    int row_count			= sheet.getPhysicalNumberOfRows();  

    	    //int j=0;
    	    
    	    for(int r = 1;r<row_count;r++)
    	    {    	       
    	        String value = getvalue(sheetname,r,keycolumn);
    	        if(value.equals(keyvalue)) al.add(new Integer(r).toString());
    	    }
    	    
    	    //(String[]) al.toArray();
    	     
    	    row_no = new String[al.size()];
    	    for(int i =0; i < al.size(); i++)row_no[i] = (String) al.get(i);

    		    		    		   
    	}
    	catch (Exception e)
    	{
    		 System.out.println("Exception Occurred While Getting Data from Sheet");
    		 System.out.println("Exception : "+e );
    		 e.printStackTrace();
    	}
		return row_no;
    }
                 
    /*
     * Closing the Streams Here
     */
    public void  closeStream()
    {
    	try
    	{
			 //fos.close();   
    		// fis.close();
    		
    	}
    	catch(Exception e)
    	{
   		 	System.out.println("\nException While Closing File Stream");    		
    	}
    }
    
    /*
     * Implementation for getting Comment/Tool Tip from cell
     */
    
    private String getCellComment(HSSFCell cell)
    {
        String cell_comment ="";
        HSSFComment comment = cell.getCellComment();
        if ( comment.getString()!= null)
        {
            HSSFRichTextString rich_text =  comment.getString();
            cell_comment                 = rich_text.toString();
        }
         
        return cell_comment;   
    }
	    
    /*
     * Implementation for getting data from cell
     */
    @SuppressWarnings("static-access")
	private String getCellData(HSSFCell cell)
    {
    	String data ="";
    	cell.setCellType(Cell.CELL_TYPE_STRING); 
    	try
    	{

	    	switch (cell.getCellType()) 
	    	{
                        //Numeroc Cell.CELL_TYPE_NUMERIC 
	    		case 0 :    
	    			if(du.isCellDateFormatted(cell))  return sdf.format( cell.getDateCellValue()).toString();	                                
	    			else return   Double.valueOf(cell.getNumericCellValue()).toString();
                                
	    		//Cell.CELL_TYPE_STRING	
	    		case 1  :	    
	    	    
	    				return cell.getRichStringCellValue().getString();	
	    				
	    		case Cell.CELL_TYPE_BOOLEAN :	  
	    	    
	    			   return  Boolean.valueOf(cell.getBooleanCellValue()).toString();	

	    		case Cell.CELL_TYPE_BLANK   :	 
	    			
						System.out.print("Blank : "+	cell.getErrorCellValue());	
						return data;
	    		case Cell.CELL_TYPE_ERROR   :
						System.out.print("Error");	
    					return data;
	    		case Cell.CELL_TYPE_FORMULA :	 
						System.out.print("Formula");	
						return data;
	    		default:
	    				return data;

	    	}  
          
    		
    	}
    	catch(Exception e)
    	{
    		
    	}
    	return data;
    }

  
    /* Write a new Value or Override the existing value of a  particular cell in a particular sheet
     * Specify Sheet Name ,Row Index and Column Index
     */
    public void setvalue(String sheetname,int rw,int cl ,String data)
    {
    	

	    try
	    {            
	    	sheet = wb.getSheet(sheetname);	    
	    	HSSFRow  row   = 	sheet.getRow(rw);
		    HSSFCell cell  = 	row.createCell(cl);
		    cell.setCellValue(data);			
			FileOutputStream fos	= new FileOutputStream(filename);
			wb.write(fos);
			fos.close();
	    }
    	catch (Exception e)
    	{
    		 System.out.println("\nException Occurred While Writing Cell Data");
    		 System.out.println("\nException : "+e );
    		 e.printStackTrace();
    	}

    }
    
    
    public String[] get_child_row_numbers(String sheetname,String[] keycolumn,String[] keyvalue)
    {
    	List<String> 		al 		=  	new ArrayList<String>();
    	String[]  			row_no 	= 	null;
    	boolean     		flag 	= 	false;
    	
    	if(keycolumn.length != keyvalue.length) return row_no;
    		
    	try
    	{    		    	    
    	    Sheet sheet 			= wb.getSheetAt(sheets.indexOf(sheetname.toUpperCase()));    	     	    
    	    int row_count			= sheet.getPhysicalNumberOfRows();  

    	    //int j=0;
    	    
    	    for(int r = 1;r<row_count;r++)
    	    {    	
				
    	    	for(int key_col = 0 ; key_col < keycolumn.length ; key_col++ )
    	    	{
    	    		String value =  getvalue(sheetname,r,keycolumn[key_col]);    	    		
    	    		if(value.equals(keyvalue[key_col]))
    	    		{
    	    			flag = true;     	    			
    	    		}
    	    		else 
    	    		{
    	    				flag = false;
    	    				break;
    	    		}

    	    	}
    	    	
	    		if(flag) al.add(new Integer(r).toString());	    		
	    		flag = false; 
    	    	

    	    }

    	     
    	    row_no = new String[al.size()];
    	    for(int i =0; i < al.size(); i++)row_no[i] = (String) al.get(i);

    		    		    		   
    	}
    	catch (Exception e)
    	{
    		 System.out.println("Exception Occurred While Getting Data from Sheet");
    		 System.out.println("Exception : "+e );
    		 e.printStackTrace();
    	}
		return row_no;
    }

}

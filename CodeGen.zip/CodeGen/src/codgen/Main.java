package codgen;



import java.io.*;
import java.util.*;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.events.*;



public class Main 
{
    Display                          								display;
    Shell                            								shell;
    Tree                            	 							pro_tree;
    Tree                             								con_tree; 
    TreeColumn                      	 					con_name;
    TreeColumn                       						pro_name;      
    TabFolder                        							con_tab;
    TabFolder                        							pro_tab;    
    ToolBar                          							script_toolbar;
    Shell                            								gv_config                   			= null;    
    Shell                            								cp_config                   			= null;    
    Shell                            								conn                        			= null;        
    Shell                            								rec_type                    			= null;  
    Shell                            								var                        				= null;
    Shell                            								auth                        			= null;
    Shell                            								msg                         			= null;
    Shell                            								if_table                    			= null;
    Shell                            								table_details               		= null;
    Shell                           									d_temp                      			= null;
    Text                             								catalog ,procedure ;
    Text                             								variable,dttype ,assign;    
    StyledText                       							widget                         		= null;    
    Combo                            							method;
    Button                           								policy;
    Button[]                         							radios;
    Text                             								host ,sid , port , user ,pwd ;
    String                           								host_name , port_number, service_id , user_name, password;    
    Text                             								app,resp,org;
    Text                             								ml_var_name,md_var_name,mc_var_name, rs_var_name;
    
    String                           								connection_name             	=	"";    
    String                           								message_string                 	= "";
    String                           								catalog_name                   		= "";
    String                          	 							procedure_name              		= "";  
    String                           								test_entity                    			= "";
    String                           								excel_path                     			= "";    
    Hashtable<String,String>         				pro_params                     		= null;
    ProcessPLSQL                     						ppl                            				= null;  
    Properties                       							authentication                 		= null;
    Properties                       							intf_property                  		= null;
    ArrayList<GlobalVariables>       			global_variables               	= null;
    ArrayList<SDTVariableAssginment> 	standard_variables          		= null;
    ArrayList<UDTVariableAssignment> 	udt_variables                  		= null;
    ArrayList<UDTVariableAssignment> 	intf_tables                    			= null;
    ArrayList<VariableDeclaration>   		declared_variables           	= null;
    ArrayList<VariableDeclaration>   		procedure_parameters       = 	null;
    ArrayList<String>                					connections                   	 	= 	null;    
    boolean                          							file                           				= 	false;
    final java.util.List<String>    			 		standard_types                 	= 	Arrays.asList(new String []{"VARCHAR","VARCHAR2","NUMBER","DATE","TIMESTAMP","BOOLEAN"});
    
    public Main()
    {
     
		        String[] array = {"Application Name", "Responsibility" , "User Name", "Operating Unit", "Error Table","Request ID Param", "Process ID Param", "CP Name" ,"CP Description" , "Start Time","Sub Request","Global Init","Org Policy Context"};
		        
		        connections                 		= ConnectionXML.GetConnectionNames(); 
		        global_variables            	= new ArrayList<GlobalVariables>() ;
		        standard_variables          = new ArrayList<SDTVariableAssginment>();
		        declared_variables          	= new ArrayList<VariableDeclaration>();
		        procedure_parameters   	= new ArrayList<VariableDeclaration>();
		        intf_tables                 			= new ArrayList<UDTVariableAssignment>();
		        udt_variables               		= new ArrayList<UDTVariableAssignment>();
		        authentication              	= new Properties();
		        intf_property               		= new Properties();
		        
		        authentication.setProperty("Method","");
		        authentication.setProperty("Policy Context","false");
		        authentication.setProperty("Org Context","");
		        authentication.setProperty("Application","");
		        authentication.setProperty("Responsibility","");
		        authentication.setProperty("Organization","");
		        authentication.setProperty("User Name","");      
		        
		        for(int i = 0 ,j =1; i< array.length+10;i++) 
		        {
			            if(i<array.length)
			            {  
			                	intf_property.setProperty(array[i],"");
			            }  
			            else
			            {
			            		intf_property.setProperty("Argument "+j,"");
			            		j++;
			            }               
		        }
		                
		        DisplayShell();            
		        DisplayMenu();
		        DisplayConnectionTab();
		        
		        
		        while( !shell.isDisposed())
		        {
		            if(!display.readAndDispatch())   display.sleep();
		        }
		        display.dispose();
    }
    
    private void SetExcelPath(String path)
    { excel_path = path; }
    
    void DisplayShell() 
    {   
	        	display     	= new Display();
	        	shell       		= new Shell(display);        
	        	shell.setMaximized(true);
	        	shell.setText("API Tester");      
	        	System.out.println(ConnectionXML.getImagePath());
	        	shell.setImage(new Image(display, ConnectionXML.getImagePath()+"\\o.ico")); 
	        
	        	Font font = new Font(shell.getDisplay(), "Courier", 10, SWT.NORMAL); 

	        	GridLayout gl               = new GridLayout();
	        	gl.numColumns				= 3;   
	        	shell.setLayout(gl);
	        	
		        /*------------------------------------------------------------------------------*/
		        //Connection Tab  
		        /*------------------------------------------------------------------------------*/

			      	GridData grid_1      								= new GridData();
			      	grid_1.widthHint									= 200;
			        grid_1.heightHint									= 980;
			        //grid_1.horizontalAlignment 			= GridData.FILL;
			        
			       con_tab = new TabFolder  (shell, SWT.BORDER);
			       con_tab.setLayoutData(grid_1);
			        
			       TabItem  conx_tab = new TabItem (con_tab, SWT.NULL);
			       conx_tab.setText("Connections");
			        
			       TabItem  flow_tab = new TabItem (con_tab, SWT.NULL);
			       flow_tab.setText("Flows");
						        
			       GridLayout gll               		= new GridLayout();
			       gll.numColumns               	= 1;
			       GridData data = new GridData(GridData.FILL_BOTH);
			
			       Composite composite 	= new Composite(con_tab, SWT.NONE);       
			       composite.setLayout(gll);        
			       composite.setLayoutData(data);
			       conx_tab.setControl(composite);
			        
			       con_tree  	= new Tree(composite,SWT.V_SCROLL|SWT.SINGLE|SWT.BORDER);      
			       con_tree.setLayoutData(new GridData(GridData.FILL_BOTH));
       		
		       /*------------------------------------------------------------------------------*/
		       // Tool Bar and Style Text Widget
		       /*------------------------------------------------------------------------------*/

		        GridData grid_2      		= new GridData();
		        grid_2.widthHint			= 1450;
		        grid_2.heightHint			= 1000;
		        //grid_2.horizontalAlignment 	= GridData.FILL;
		        
		        Composite  tw_comp  	 	= new Composite(shell, SWT.NONE);              
		        GridLayout tw_grd 		 	= new GridLayout();
		        tw_grd.numColumns 	 	= 1;
		        tw_comp.setLayout(tw_grd);
		        
		        GridData 	gd_tool   		= new GridData(GridData.VERTICAL_ALIGN_BEGINNING);  
		        gd_tool.widthHint			= 1450;
		        gd_tool.heightHint			= 50;
		        //gd_tool.grabExcessVerticalSpace = true;
		
		        
		        script_toolbar = new ToolBar(tw_comp, SWT.BORDER);
		        script_toolbar.setLayoutData(gd_tool);
		        DisplayScriptToolbar(); 
		        
		        
		        GridData 	gd_widget 		= new GridData(GridData.VERTICAL_ALIGN_BEGINNING);   
		        gd_widget.widthHint		= 1450;
		        gd_widget.heightHint		=  950;
		        //gd_widget.grabExcessVerticalSpace = true;
		        
		        
		        widget = new StyledText(tw_comp, SWT.BORDER |SWT.H_SCROLL|SWT.V_SCROLL);
		        widget.setFont(font);
		        widget.setForeground(display.getSystemColor(SWT.COLOR_BLUE));        
		        widget.setLayoutData(gd_widget);
		        
		        tw_comp.setLayoutData(grid_2);
		        
		        /*------------------------------------------------------------------------------*/
		        //Procedures Tab 
		        /*------------------------------------------------------------------------------*/
		        
		        GridData grid_3      		= new GridData();
		        grid_3.widthHint			= 200;
		        grid_3.heightHint			= 980;
		        grid_3.horizontalAlignment = GridData.FILL;
		        
		        pro_tab = new TabFolder  (shell, SWT.BORDER);
		        pro_tab.setLayoutData(grid_3);
		        pro_tab.setVisible(false);
		
		        Composite comp = new Composite(pro_tab, SWT.NONE);
		        comp.setLayout(new FillLayout());
		        
		        TabItem  pro_param_tab = new TabItem (pro_tab, SWT.BORDER);
		        pro_param_tab.setText("Automatic Script Generation   ");
		        pro_param_tab.setControl(comp);
		                
		        pro_tree        = new Tree(comp,SWT.V_SCROLL|SWT.H_SCROLL|SWT.SINGLE|SWT.BORDER);
		        
		        //shell.pack();
		        shell.open();
  
    }     
    
    void DisplayMenu()
    {
            Menu menubar = new Menu(shell,SWT.BAR);      
            
            //File Menu            
            MenuItem  file_menu_header = new MenuItem(menubar, SWT.CASCADE);
            file_menu_header.setText("&File");            

            Menu file_menu = new Menu(shell,SWT.DROP_DOWN);
            file_menu_header.setMenu(file_menu);
                    
            
            // File - New
            MenuItem file_new_item = new MenuItem(file_menu,SWT.CASCADE);
            file_new_item.setText("New");

            Menu new_sub_menu= new Menu(shell,SWT.DROP_DOWN);            
            file_new_item.setMenu(new_sub_menu);
            
            // File -> New -> Connection
            MenuItem new_connection = new MenuItem(new_sub_menu,SWT.PUSH);
            new_connection.setText("Connection");
            
            // File -> New -> One Off
            MenuItem new_one_off = new MenuItem(new_sub_menu,SWT.PUSH);
            new_one_off.setText("One Off");
            
            // File -> New -> Flow
            MenuItem new_flow = new MenuItem(new_sub_menu,SWT.PUSH);
            new_flow.setText("E2E Flow");
            

            //File -> Open
            MenuItem  file_open_item = new MenuItem(file_menu,SWT.CASCADE);
            file_open_item.setText("Open");
            

            // File -> Save
            MenuItem  file_save_item = new MenuItem(file_menu,SWT.PUSH);
            file_save_item.setText("Save");
            
            // File -> Clear
            MenuItem  file_clear_item = new MenuItem(file_menu,SWT.PUSH);
            file_clear_item.setText("Clear");
            
            // File -> Create Data Template
            MenuItem  create_data_template = new MenuItem(file_menu,SWT.PUSH);
            create_data_template.setText("Data Template");
            
            // File -> Exit
            MenuItem  file_exit_item = new MenuItem(file_menu,SWT.PUSH);
            file_exit_item.setText("Exit");
            
            new_connection.addSelectionListener(new ConnectionListener());
            new_one_off.addSelectionListener(new NewOneOffListener());
            new_flow.addSelectionListener(new NewFlowListener());
            
            
            file_open_item.addSelectionListener(new FileOpenListener());
            file_save_item.addSelectionListener(new FileSaveListener()); 
            file_clear_item.addSelectionListener(new FileClearListener()); 
            file_exit_item.addSelectionListener(new FileExitListener());  
            create_data_template.addSelectionListener(new CreateTemplateListener());
        
            shell.setMenuBar(menubar);
    
    
    }
    
    private void DisplayConnectionTab()
    {
        try        
        {

            
            con_tree.removeAll();
            ArrayList<String> con = ConnectionXML.GetConnectionNames();
            for( int i =0;i<con.size();i++)
            {
                TreeItem item  = new TreeItem(con_tree, 0);                
                item.setText((String) con.get(i));
            }  
            //con_name.pack();
            //con_tree.pack();
            
            
            con_tree.addListener(SWT.Selection, new Listener() 
            {
                public void handleEvent(Event event)
                {
                    String conn_name  = (event.item).toString();//.getData();               
                    if(  (conn_name.indexOf("TreeItem {")!= -1 ) && (conn_name.indexOf("}") != -1 ))
                    conn_name = conn_name.substring(conn_name.indexOf("TreeItem {")+10,conn_name.length()-1);    
                    SelectIFType(conn_name) ;        
                }
            });                                                                                                            
        }
        catch(Exception e)
        {
            System.out.println("Exception While Loading Tree "+e);
                 
        }
        
    }
    
    void SelectIFType(String connection_name) 
    {
        

    	
        final String conn_name = connection_name;
        System.out.println(conn_name);
        
        String items[] = { "PLSQL Procedure", "SOAP Webservices", "Open Interface","OAF Java Method","REST Webservice" };
        
        final Shell types    = new Shell(shell, SWT.TITLE|SWT.CLOSE);            
       
        types.setText("Select Entity Type");            
        types.setLocation(500, 200);
        GridLayout gridLayout = new GridLayout(4, false);
        gridLayout.verticalSpacing = 10;
        
        GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        gridData.horizontalSpan     = 3;            
        gridData.heightHint         = 18;
        gridData.widthHint          = 150;

        types.setLayout(gridLayout);
        
        
        Label type_name = new Label(types, SWT.NULL);
        type_name.setText("Select Type  ");
        
        
        final Combo if_type  = new Combo(types, SWT.READ_ONLY);
        if_type.setLayoutData(gridData);
        if_type.setItems(items);
        if_type.select(0);
        
        Button ok = new Button(types, SWT.PUSH);
        ok.setText("  OK  ");     
        
        ok.addListener(SWT.Selection, new Listener()
        {   public void handleEvent(Event e) 
            {
                    switch (e.type) 
                    {
                        case SWT.Selection:   
                        String type_name = if_type.getText();
                        types.dispose();
                        if(type_name.equals("PLSQL Procedure"))   GenerateCode(conn_name);
                        if(type_name.equals("Webservices"))       GenerateCode(conn_name);
                        if(type_name.equals("Open Interface"))    GetInterfaceTableNames(conn_name);                    
                        break; 
                    }
            } 
        });
        
        Button cancel = new Button(types, SWT.PUSH);
        cancel.setText("Cancel");
        cancel.addListener(SWT.Selection, new Listener()
        {   public void handleEvent(Event e) 
            {
                    switch (e.type) 
                    {
                        case SWT.Selection:                             
                        types.dispose(); 
                        break; 
                    }
            } 
        });
        
        types.setSize(300, 100);            
        types.open();
        
    }
    
    class ConnectionListener implements SelectionListener
    {
        public void widgetSelected(SelectionEvent event) 
        { CreateConnection();}
       
        public void widgetDefaultSelected(SelectionEvent event) 
        {CreateConnection();}
     } 
        
    class NewOneOffListener implements SelectionListener
    {
        public void widgetSelected(SelectionEvent event) 
        {
             OpenTest();
        }
       
        public void widgetDefaultSelected(SelectionEvent event) 
        {
             OpenTest();
        }
     }
        
    class NewFlowListener implements SelectionListener
    {
        public void widgetSelected(SelectionEvent event) 
        {
             //openDirectory();
        }
       
        public void widgetDefaultSelected(SelectionEvent event) 
        {
                          //openFile();
        }
     }
        
    class FileOpenListener implements SelectionListener
    {
       public void widgetSelected(SelectionEvent event) 
       {
             OpenTest();
       }
       
        public void widgetDefaultSelected(SelectionEvent event) 
        {
              OpenTest();
        }
     }    
    
    class FileSaveListener implements SelectionListener
    {
        public void widgetSelected(SelectionEvent event) 
        {
             SaveTest();
        }
       
        public void widgetDefaultSelected(SelectionEvent event) 
        {
            SaveTest();
        }
     }
    
    class FileExitListener implements SelectionListener
    {
        public void widgetSelected(SelectionEvent event) 
        {
            System.exit(0);
        }
       
        public void widgetDefaultSelected(SelectionEvent event) 
        {
            System.exit(0);
        }
     }    
    
    class CreateTemplateListener implements SelectionListener
    {
        public void widgetSelected(SelectionEvent event) 
        {
            if(null!=ppl)
            { 
                String message = ppl.CreateDataTemplte();
                MessageBox messageBox = new MessageBox(shell, SWT.OK);
                messageBox.setText("Data Template Creation");
                messageBox.setMessage(message);
                messageBox.open();            
            }
            
        }
       
        public void widgetDefaultSelected(SelectionEvent event) 
        {
            if(null!=ppl)
            { 
                String message = ppl.CreateDataTemplte();
                MessageBox messageBox = new MessageBox(shell, SWT.OK);
                messageBox.setText("Data Template Creation");
                messageBox.setMessage(message);
                messageBox.open();            
            }
        }
     }

    class FileClearListener implements SelectionListener
    {
            public void widgetSelected(SelectionEvent event) 
            {

                pro_tree.removeAll(); 
                widget.setText("");
                
                for(int index =0; index < standard_variables.size(); index++)   		standard_variables.remove(index);                       
                for(int index =0; index < declared_variables.size(); index++)   		declared_variables.remove(index);
                for(int index =0; index < procedure_parameters.size(); index++) 	procedure_parameters.remove(index);       
                for(int index =0; index < udt_variables.size(); index++)       			 udt_variables.remove(index);  

                connection_name             = "";    
                message_string             	= "";
                catalog_name               	 	= "";
                procedure_name              = "";  
                
                authentication.setProperty("Method","");
                authentication.setProperty("Policy Context","false");
                authentication.setProperty("Org Context","");
                authentication.setProperty("Application","");
                authentication.setProperty("Responsibility","");
                authentication.setProperty("Organization","");
                authentication.setProperty("User Name","");   

            }
       
            public void widgetDefaultSelected(SelectionEvent event) 
            {
                
                pro_tree.removeAll(); 
                widget.setText("");
                
                for(int index =0; index < standard_variables.size(); index++)   		standard_variables.remove(index);                       
                for(int index =0; index < declared_variables.size(); index++)   		declared_variables.remove(index);
                for(int index =0; index < procedure_parameters.size(); index++) 	procedure_parameters.remove(index);       
                for(int index =0; index < udt_variables.size(); index++)        			udt_variables.remove(index);  

                connection_name             = "";    
                message_string              	= "";
                catalog_name                	= "";
                procedure_name              = "";  
                
                authentication.setProperty("Method","");
                authentication.setProperty("Policy Context","false");
                authentication.setProperty("Org Context","");
                authentication.setProperty("Application","");
                authentication.setProperty("Responsibility","");
                authentication.setProperty("Organization","");
                authentication.setProperty("User Name","");   
                
            }
     }
    //Create Connection
    public void CreateConnection()
    {
        try 
        {     
            
            conn = new Shell(shell, SWT.TITLE|SWT.CLOSE);                     
            conn.setText("New DB Connection");            
            conn.setLocation(500, 200);
            GridLayout gridLayout = new GridLayout(4, false);
            gridLayout.verticalSpacing = 10;
            
            GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
            gridData.horizontalSpan     = 3;            
            gridData.heightHint         = 18;
            gridData.widthHint          = 150;

            conn.setLayout(gridLayout);
            
            
            Label host_name = new Label(conn, SWT.NULL);
            host_name.setText("Host Name ");
            
            
            host  = new Text(conn, SWT.SINGLE | SWT.BORDER);
            host.setLayoutData(gridData);
            
            Label port_number = new Label(conn, SWT.NULL);
            port_number.setText("Port Number ");
            
            port  = new Text(conn, SWT.SINGLE | SWT.BORDER);
            port.setLayoutData(gridData);
            
            Label service_id = new Label(conn, SWT.NULL);
            service_id.setText("Service ID ");
            
            sid  = new Text(conn, SWT.SINGLE | SWT.BORDER);
            sid.setLayoutData(gridData);
            
            Label user_name = new Label(conn, SWT.NULL);
            user_name.setText("User Name ");
            
            user  = new Text(conn, SWT.SINGLE | SWT.BORDER);
            user.setLayoutData(gridData);
            
            Label password = new Label(conn, SWT.NULL);
            password.setText("Password ");
            
            pwd  = new Text(conn, SWT.PASSWORD | SWT.BORDER);
            pwd.setLayoutData(gridData);
                
            Button create = new Button(conn, SWT.PUSH);
            create.setText("  Create  ");     
            
            create.addListener(SWT.Selection, new Listener()
            {   public void handleEvent(Event e) 
                {
                        switch (e.type) 
                        {
                            case SWT.Selection:                             
                            AppendConnectionXML(); 
                            break; 
                        }
                } 
            });
            
            Button cancel = new Button(conn, SWT.PUSH);
            cancel.setText("Cancel");
            cancel.addListener(SWT.Selection, new Listener()
            {   public void handleEvent(Event e) 
                {
                        switch (e.type) 
                        {
                            case SWT.Selection:                             
                            conn.dispose(); 
                            break; 
                        }
                } 
            });
             
            conn.setSize(300, 250);            
            conn.open();
                            
        }
        catch(Exception e) 
        {
            System.out.println("Exception : "+e);
            
        }   
    }
    
    private void AppendConnectionXML() 
    {
        try
        {

            host_name   		= host.getText().trim();
            service_id  		= sid.getText().trim();
            port_number 	= port.getText().trim();
            user_name   		= user.getText().trim();
            password    		= pwd.getText().trim();
            
           //NULL Check
           //if((host_name)            
            host.setText("");
            sid.setText("");
            port.setText("");
            user.setText("");
            pwd.setText("");
            
           String status =  ConnectionXML.CreateNewConnection(host_name,service_id,port_number,user_name,password);
            

            MessageBox messageBox = new MessageBox(conn, SWT.OK);
            messageBox.setText("Connection");
            messageBox.setMessage("New Connection : "+status);
            messageBox.open();                        
            conn.dispose();
            
            DisplayConnectionTab();
            
            
        }
        catch(Exception e) 
        {
            System.out.println("Exception : "+e);
            
        } 
    }

    public void GenerateCode(String conn_name)
    {
        try 
        {      
            connection_name = conn_name;
            
            conn = new Shell(shell, SWT.TITLE|SWT.CLOSE);

            conn.setText("Enter Procedute Details");            
            conn.setLocation(500, 200);
                        
            GridLayout gridLayout 		= new GridLayout();
            gridLayout.numColumns	= 2;
            
            GridData gridData 			 	= new GridData(GridData.HORIZONTAL_ALIGN_FILL);                   
            gridData.heightHint         	= 25;
            gridData.widthHint         	 	= 150;

            conn.setLayout(gridLayout);

            Label catalog_name = new Label(conn, SWT.NULL);
            catalog_name.setText("Catalog Name ");
            catalog_name.setLayoutData(gridData);
                        
            catalog  = new Text(conn, SWT.SINGLE | SWT.BORDER);
            catalog.setLayoutData(gridData);
            
            Label procedure_name = new Label(conn, SWT.NULL);
            procedure_name.setText("Procedure Name ");
            procedure_name.setLayoutData(gridData);
            
            procedure  = new Text(conn, SWT.SINGLE | SWT.BORDER);
            procedure.setLayoutData(gridData);
            /*--------------------------------------------------------------------------- */
            /*--------------------------------------------------------------------------- */
            
            Label env_name = new Label(conn, SWT.NULL);
            env_name.setText("Environment Name");
            env_name.setLayoutData(gridData);

            Text env = new Text(conn,SWT.SINGLE | SWT.BORDER);
            env.setText(connection_name);
            env.setEditable(false);
            env.setLayoutData(gridData);
            /*--------------------------------------------------------------------------- */
            /*--------------------------------------------------------------------------- */
            Label generate_action = new  Label(conn, SWT.NULL);
            generate_action.setText("Generate Action");
            generate_action.setLayoutData(gridData);
            
            GridData gridDatab 					= new GridData(GridData.HORIZONTAL_ALIGN_FILL);                   
            gridDatab.heightHint         		= 30;
            gridDatab.widthHint          		= 150;

            GridData gd_b      					= new GridData();
            gd_b.widthHint     					= 100;
            gd_b.heightHint    					= 25;
            gd_b.grabExcessHorizontalSpace 		= true;
            gd_b.grabExcessVerticalSpace    	= true;
            
            GridLayout button_gl               	= new GridLayout();
            button_gl.numColumns               	= 2;
            button_gl.makeColumnsEqualWidth		= true;	 
            
            Group bg = new Group(conn,SWT.SHADOW_ETCHED_IN);
            bg.setLayout(button_gl);            
            bg.setLayoutData(gridDatab);
            
            Button create = new Button(bg, SWT.PUSH);
            create.setText("Generate");   
            create.setLayoutData(gd_b);
            
            create.addListener(SWT.Selection, new Listener()
            {   public void handleEvent(Event e) 
                {
                        //String connect_name = "";
                        switch (e.type) 
                        {
                            case SWT.Selection:                             
                            Generate();
                              
                            
                            break; 
                        }
                } 
            });
            
            Button cancel = new Button(bg, SWT.PUSH);
            cancel.setText("Cancel");
            cancel.setLayoutData(gd_b);
            cancel.addListener(SWT.Selection, new Listener()
            {   public void handleEvent(Event e) 
                {
                        //String connect_name = "";
                        switch (e.type) 
                        {
                            case SWT.Selection:                             
                            conn.dispose();                            
                            break; 
                        }
                } 
            });    
                       
            conn.setSize(350,180);            
            conn.open();
   
        }
        catch(Exception e) 
        {
            System.out.println("Exception : "+e);
            
        }   
    }
      
    private void Generate() 
    {
        try
        {   
        	

            catalog_name    = catalog.getText().trim();
            procedure_name  = procedure.getText().trim();

            conn.dispose();
            

            MessageBox messageBox = new MessageBox(shell, SWT.OK);
            messageBox.setText("Warning Message");
            messageBox.setMessage("Test Object Configuration would take considerable amount of time depending upon the complexity, Please Stand by.");
            messageBox.open();
            
            
            ppl = new ProcessPLSQL(procedure_name,catalog_name,connection_name);
            
 

            DisplayProcedureTab();

        }
        catch(Exception e) 
        {
            System.out.println("Exception : "+e);
            
        } 
    }
    
    public void GetInterfaceTableNames(String conn_name) 
    {
        connection_name = conn_name;
        
        if_table            = new Shell(shell, SWT.TITLE|SWT.CLOSE);                     
        if_table.setText("Interface Tables");            
        if_table.setLocation(500, 200);
        GridLayout gridLayout = new GridLayout(4, false);
        gridLayout.verticalSpacing = 10;
        
        GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        gridData.horizontalSpan     = 3;            
        gridData.heightHint         = 18;
        gridData.widthHint          = 150;

        if_table.setLayout(gridLayout);
        
        Label entity_name = new Label(if_table, SWT.NULL);
        entity_name.setText("Enter Entity Name ");
        
        
        final Text entity  = new Text(if_table, SWT.SINGLE | SWT.BORDER);
        entity.setLayoutData(gridData);
        
        
        Label host_name = new Label(if_table, SWT.NULL);
        host_name.setText("Enter Table Names ");
        
        
        final Text tables  = new Text(if_table, SWT.SINGLE | SWT.BORDER);
        tables.setLayoutData(gridData);
        

            
        Button create = new Button(if_table, SWT.PUSH);
        create.setText("  Generate  ");     
        
        create.addListener(SWT.Selection, new Listener()
        {   public void handleEvent(Event e) 
            {
                    switch (e.type) 
                    {
                        case SWT.Selection:    
                        String entity_name = entity.getText();
                        String table_names = tables.getText();
                        if_table.dispose();
                        DisplayInterfaceTables(table_names, entity_name);
                        break; 
                    }
            } 
        });
        
        Button cancel = new Button(if_table, SWT.PUSH);
        cancel.setText("Cancel");
        cancel.addListener(SWT.Selection, new Listener()
        {   public void handleEvent(Event e) 
            {
                    switch (e.type) 
                    {
                        case SWT.Selection:                             
                        if_table.dispose(); 
                        break; 
                    }
            } 
        });
         
        if_table.setSize(350,150 );            
        if_table.open();

    }
        
    public void DisplayInterfaceTables(String table_names,String ent_name)
    {
        final  String entity_name = ent_name;
        String[] sv = {"Global Variables","CP Configuration","Generate Script",entity_name};
        final java.util.List<String> std_var = Arrays.asList(sv);
        
        String[] tables = table_names.split( ";" );
        pro_tab.setVisible(true);
        
        TreeItem item_dummy_1 = new TreeItem(pro_tree,SWT.NONE);
        item_dummy_1.setText("Global Variables");
                                                            
        
        TreeItem item_0 = new TreeItem(pro_tree,SWT.NONE);
        item_0.setText(entity_name);
        
        for(int i = 0 ; i < tables.length;i++) 
        {
            
            TreeItem item = new TreeItem(item_0,SWT.NONE);
            item.setText(tables[i]);
            
        }

        TreeItem item_1 = new TreeItem(item_0,SWT.NONE);
        item_1.setText("CP Configuration");
        
        TreeItem item_2 = new TreeItem(item_0,SWT.NONE);
        item_2.setText("Generate Script");
                
        //TreeItem item_dummy_2 = new TreeItem(pro_tree,SWT.NONE);
        //TreeItem item_dummy_3 = new TreeItem(pro_tree,SWT.NONE);
        
        //pro_name.pack();                             
        //pro_tree.pack();
        
        pro_tree.addListener(SWT.Selection, new Listener() 
        {
            public void handleEvent(Event event)
            {
                String data  = (event.item).toString();//.getData();               
                if(  (data.indexOf("TreeItem {")!= -1 ) && (data.indexOf("}") != -1 ))
                data = data.substring(data.indexOf("TreeItem {")+10,data.length()-1).trim();                
                if(!std_var.contains(data) )ConfigureTable(data);   
                
                if(data.equals("CP Configuration")) ConfigureConcurrentProgram();                            
                if(data.equals("Generate Script"))  GenerateOIScript();
                if(data.equals("Global Variables")) ConfigureGlobalVariables();
            }
        }); 
  
    }
    
    public void ConfigureTable(String tab_name) 
    {
        ppl                     = new ProcessPLSQL(connection_name);  
        boolean found_keys      = false;
        final String table_name = tab_name;
        table_details           = new Shell(shell, SWT.TITLE|SWT.CLOSE|SWT.RESIZE);        
        table_details.setText(table_name);
        
        GridLayout dsGridLayout = new GridLayout();
        table_details.setLayout(dsGridLayout);
        
        GridData tool_bar_grid_data                     = new GridData();
        tool_bar_grid_data.horizontalAlignment          = SWT.FILL;
        tool_bar_grid_data.grabExcessHorizontalSpace    = true;
                
        GridData table_grid_data                        = new GridData();
        table_grid_data.horizontalAlignment             = SWT.FILL;
        table_grid_data.grabExcessHorizontalSpace       = true;
        table_grid_data.verticalAlignment               = SWT.FILL;
        table_grid_data.grabExcessVerticalSpace         = true;
        

        ToolBar toolbar = new ToolBar(table_details, SWT.FLAT | SWT.WRAP | SWT.RIGHT);
        toolbar.setLayoutData(tool_bar_grid_data);
        
        ToolItem save_tool = new ToolItem(toolbar, SWT.PUSH);
        save_tool.setText("Save Data");
        save_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//sv.ico"));
        
        
        ToolItem add_tool = new ToolItem(toolbar, SWT.PUSH);
        add_tool.setText("Add Row");
        add_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//ad.ico"));
        
        
        ToolItem search_tool = new ToolItem(toolbar, SWT.PUSH);
        search_tool.setText("Search Field");
        search_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//sr.ico"));
        
        ToolItem copy_tool = new ToolItem(toolbar, SWT.PUSH);
        copy_tool.setText("Copy Row");
        copy_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//cp.ico"));
        
        ToolItem del_tool = null;
        

        final Table table =  new Table(table_details, SWT.BORDER|SWT.MULTI|SWT.V_SCROLL|SWT.H_SCROLL|SWT.CHECK);// 
                
        for(int index =0; index < intf_tables.size(); index++)
        {
            UDTVariableAssignment ud    = (UDTVariableAssignment) intf_tables.get(index);
            String variable             =  ud.getVariableName();    
            
            int i =0;
            
            if(variable.equals(table_name)) 
            {     
                if(!found_keys) 
                {
                    Hashtable<String,String>       ht                  = ud.getRecordData();        
                    Enumeration<String>     parameters          = ht.keys(); 

                    
                    if(i==0) 
                    {
                        TableColumn tc  = new TableColumn(table, SWT.NONE);
                        tc.setWidth(50); tc.setText("Row");     
                        i++;
                    }
                
                    while ( parameters.hasMoreElements() ) 
                    {   
                        String param_name   = (String) parameters.nextElement();
                        String data_type    = "" ;
                        
                        if( param_name.indexOf(";")!= -1) 
                        {
                            data_type =  param_name.substring(param_name.indexOf(";")+1,param_name.length());
                            param_name = param_name.substring(0,param_name.indexOf(";"));                            
                        }     
                        
                        TableColumn column  = new TableColumn(table, SWT.NONE);
                        column.setWidth(100);
                        column.setText(param_name);  
                        column.setToolTipText(data_type);
                    } 
                    
                    found_keys = true;   
                }
                
                Hashtable<String,String>    ht                  = ud.getRecordData();                   
                int             			k                   = 1;
                Enumeration<String>     	parameters          = ht.elements();                  
                
                TableItem       item   = new TableItem(table,SWT.NONE);
                while ( parameters.hasMoreElements() ) 
                {   
                    item.setText(k, (String) parameters.nextElement());                                  
                    k++;  
                }                                         
            }
        }
        

        
        if(!found_keys) 
        {            
            del_tool = new ToolItem(toolbar, SWT.PUSH);
            del_tool.setText("Delete Row");
            del_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//rm.ico"));            
            del_tool.addSelectionListener(new SelectionAdapter() 
            {            
                @Override
                public void widgetSelected(SelectionEvent e) 
                {
                    TableItem[] items = table.getItems();
                    for (TableItem item : items) 
                    {
                        if(item.getChecked()){table.remove(table.indexOf(item));}
                    }
                }
            });
            
            Hashtable<String,String> 	ht 				= ppl.GetTableDetails(table_name);                
            Enumeration<String>     	fields          = ht.keys();             
            Enumeration<String>     	d_type          = ht.elements();  

            TableColumn tc  = new TableColumn(table, SWT.NONE);
            tc.setWidth(50); tc.setText("Row");     
 
            while ( fields.hasMoreElements() ) 
            {   

                
                    String param_name   = (String) fields.nextElement();
                    String tool_tip     = (String) d_type.nextElement();                 
                    TableColumn column  = new TableColumn(table, SWT.NONE);
                    column.setWidth(100);
                    column.setText(param_name);   
                    column.setToolTipText(tool_tip);
            } 
        }

        save_tool.addSelectionListener(new SelectionAdapter()
        {           
           @Override
           public void widgetSelected(SelectionEvent e) 
           {               
               SaveTableData(table,table_name,"" );
           }
        });
        
        add_tool.addSelectionListener(new SelectionAdapter() 
        {            
            @Override
            public void widgetSelected(SelectionEvent e) 
            {                
                @SuppressWarnings("unused")
				TableItem item = new TableItem(table, SWT.NONE); 
            }
        });
        
        search_tool.addSelectionListener(new SelectionAdapter() 
        {            
            @Override
            public void widgetSelected(SelectionEvent e) 
            {                
                SearchField(table);
            }
        });
        
        copy_tool.addSelectionListener(new SelectionAdapter() 
        {            
            @Override
            public void widgetSelected(SelectionEvent e) 
            {
                TableItem[] items = table.getItems();
                for (TableItem item : items) 
                {
                    if(item.getChecked())
                    {                                                                  
                        TableItem new_item = new TableItem(table, SWT.NONE); 
                        for(int i = 1;i<table.getColumnCount();i++)
                        new_item.setText(i,item.getText(i));                    
                    }
                }
            }
        });
            
        table.setSize(400,400);    
        table.setHeaderVisible(true);
        table.setLinesVisible(true);
        table.setLayoutData(table_grid_data);
        EnableTableEditing(table);

        table_details.setSize(800,500);
        table_details.setLocation(280, 200);        
        table_details.open();
        
    }
        
    @SuppressWarnings("unused")
    public void SaveTableData(Table table,String variable_name,String data_type)
    {
        String                          col_name ;
        String                          col_data ;        
        String                          Message     = "";        
        String                          var_name    = "" ;
        String                          dt_type     = ""    ;
        int                             rec         = 0;
        
        try
        {           
                    
                    TableItem [] items = table.getItems ();
            
                    for(int i=0; i<items.length; i++) 
                    {
                            boolean     flag         = false;                                        
                            int         col_count    = table.getColumnCount();  
                            Hashtable<String,String>   rec_data     =  new Hashtable<String,String>();
                        
                            //Get Record from UI Table
                            for(int j=1; j<col_count; j++) 
                            {       
                                TableColumn column  = table.getColumn(j);    
                                col_name            = column.getText();                                
                                dt_type             = column.getToolTipText();
                                col_data            = items[i].getText(j);                                                                                                
                                rec_data.put(col_name+";"+dt_type, col_data);
                                    
                            }
                                                
                            //Check If Record Already Exists in the ArrayList
                            for(int index =0; index < intf_tables.size(); index++)
                            {
                                UDTVariableAssignment ud    = (UDTVariableAssignment) intf_tables.get(index);
                                var_name                    = ud.getVariableName(); 
                                rec                         = ud.getRecord();
                                        
                                if( var_name.equals(variable_name) && (i==rec ) )
                                {
                                        ud.setRecord(i);
                                        ud.setVariableName(variable_name);
                                        ud.setDataType(data_type);
                                        ud.setRecordData(rec_data);       
                                        Message = "Updated Existing Record";  
                                          
                                        flag = true; 
                                        break;
                                }
                            } 
                                
                            if(!flag) 
                            {
                                UDTVariableAssignment ud = new UDTVariableAssignment(i,variable_name,data_type,rec_data);   
                                intf_tables.add(ud);
                                Message = "Created New Record";                                    
                            }
                    }
    
        }
        catch(Exception e) 
        {
            System.out.println(e);        
        }
        
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public void ConfigureConcurrentProgram() 
    {                         
        cp_config = new Shell(shell, SWT.TITLE|SWT.CLOSE|SWT.RESIZE);
        cp_config.setSize(440, 550);
        cp_config.setLocation(500, 200);
        cp_config.setText("CP Configuration");
        
            
        GridLayout gridlayout = new GridLayout();
        cp_config.setLayout(gridlayout);
        
        GridData tool_bar_grid_data                     = new GridData();
        tool_bar_grid_data.horizontalAlignment          = SWT.FILL;
        tool_bar_grid_data.grabExcessHorizontalSpace    = true;
        
        
        GridData table_grid_data                        = new GridData();
        table_grid_data.horizontalAlignment             = SWT.FILL;
        table_grid_data.grabExcessHorizontalSpace       = true;
        table_grid_data.verticalAlignment               = SWT.FILL;
        table_grid_data.grabExcessVerticalSpace         = true;
        

        
        ToolBar toolbar = new ToolBar(cp_config, SWT.FLAT | SWT.WRAP | SWT.RIGHT);
        toolbar.setLayoutData(tool_bar_grid_data);
        
        final Table             table   =   new Table(cp_config, SWT.BORDER);
        TableEditor             editor;
        
        table.setLayoutData(table_grid_data);
        table.setHeaderVisible(true);
        table.setLinesVisible(true);
        
        

                    
        Listener selectionListener = new Listener()
        {
            public void handleEvent(Event event) 
            {                
                    TableItem [] items = table.getItems ();               
                    for(int i=0; i<items.length; i++) 
                    {
                        String prop_name    = items[i].getText(0);
                        String pro_val      = items[i].getText(1);
                        intf_property.setProperty(prop_name, pro_val);
                    }                 
            }            
         };
        
        ToolItem save_tool = new ToolItem(toolbar, SWT.PUSH);
        save_tool.setText("Save Data");
        save_tool.setImage( new Image(display,ConnectionXML.getImagePath() +"//sv.ico"));
        save_tool.addListener(SWT.Selection, selectionListener);
        

                
        TableColumn column_1 = new TableColumn(table, SWT.LEFT);
        TableColumn column_2 = new TableColumn(table, SWT.LEFT);
        column_1.setWidth(4000);
        column_2.setWidth(4000);
        column_1.setText("Property Name                                     ");
        column_2.setText("Property Value                                    ");

        //Set<String> prop_names = intf_property.stringPropertyNames();
        
        SortedMap<String,String> sorted_map = new TreeMap(intf_property);
        Set<String> keys                	= sorted_map.keySet();
        Iterator<String> iterator       	= keys.iterator();
        
        while (iterator.hasNext()) 
        {
            final String property_name    = (String) iterator.next();
            final TableItem item          = new TableItem(table,SWT.NONE);
            
            item.setText(new String[] {property_name,intf_property.getProperty(property_name)});
                                
            if(property_name.equals("Global Init") || property_name.equals("Org Policy Context") || property_name.equals("Sub Request")) 
            {                
                final Combo combo = new Combo(table, SWT.NONE);                
                combo.add("Yes");
                combo.add("No");   
                combo.computeSize(SWT.DEFAULT, table.getItemHeight());
                
                if(intf_property.getProperty(property_name).equals("Yes"))  combo.select(0);
                else                                                        combo.select(1);
                                                           
                editor  =   new TableEditor(table) ;
                editor.grabHorizontal = true;                    
                editor.setEditor(combo, item, 1);
                
                combo.addSelectionListener(new SelectionAdapter() 
                {
                        @Override
                        public void widgetSelected(SelectionEvent e) 
                        {
                                item.setText(new String[] {property_name,combo.getText()});
                                System.out.println("Selection: " + combo.getText()); //combo.getItem(combo.getSelectionIndex()));
                        }
                });
                                
            }   

        }
        
        column_1.pack();
        column_2.pack();
        EnableTableEditing(table);                
        cp_config.open();
        
     
    }
    
    @SuppressWarnings("unused")
    public void GenerateOIScript() 
    {
        test_entity = "Open Interface";
        StringBuffer buffer = new StringBuffer();

        buffer.append("CREATE OR REPLACE PROCEDURE TEST_OI AS\n\n");
        buffer.append("V_PHASE             VARCHAR2(240);\n");
        buffer.append("V_STATUS            VARCHAR2(240);\n");
        buffer.append("V_REQUEST_PHASE     VARCHAR2(240);\n");
        buffer.append("V_REQUEST_STATUS    VARCHAR2(240);\n");
        buffer.append("V_MESSAGE           VARCHAR2(240);\n");
        buffer.append("V_FINISHED          BOOLEAN;\n");
        buffer.append("V_SUB_STATUS        BOOLEAN          := FALSE;\n");
        buffer.append("V_ORGANIZATION_ID   NUMBER           := 0;\n");
        buffer.append("V_REQUEST_ID        NUMBER           := 0;\n\n");
        
        for(int index =0; index < global_variables.size(); index++)
        {
            GlobalVariables gv    = (GlobalVariables) global_variables.get(index);
            
            String          VariableName    =  gv.getVariableName().trim();  
            String          DataType        =  gv.getDataType().trim();    
            String          Size            =  gv.getSize().trim();
            String          DefaultValue    =  gv.getDefaultValue().trim();  
            
            
            if((DefaultValue.length() > 0 ) && (DataType.equals("VARCHAR") || DataType.equals("VARCHAR2") || DataType.equals("DATE") )) 
            {
                DefaultValue = "'"+DefaultValue+"'";
                
                if(!DataType.equals("DATE") && Size.length() > 0 )  DataType =   DataType+"("+Size+")";
            }

            String str;
            if( DefaultValue.length()>0)  str = String.format("%-35s %-50s %-50s\n" ,VariableName, DataType ,":= "+DefaultValue+";" );
            else                          str = String.format("%-35s %-50s\n" ,VariableName, DataType+";" );
                
            buffer.append(str);   
                                
        }    
        
        
        buffer.append("BEGIN\n\n");

        //========================================================================================================================//
            /* Insert Statements */
        //========================================================================================================================//
        for(int index =0; index < intf_tables.size(); index++)
        {
            UDTVariableAssignment ud    = (UDTVariableAssignment) intf_tables.get(index);
            String          variable        =  ud.getVariableName();  
                    
            buffer.append("INSERT INTO "+variable); 

            
            Hashtable<String,String> ht              =  ud.getRecordData();        
            Enumeration<String>      enum_1          =  ht.keys(); 
            Enumeration<String>      enum_2          =  ht.elements(); 
            
            StringBuffer column_buffer = new StringBuffer();
            StringBuffer value_buffer = new StringBuffer();
            column_buffer.append(" (");
            value_buffer.append(" (");
            int i = 0;
            
            while ( enum_1.hasMoreElements() ) 
            {   
                String param_name   = (String) enum_1.nextElement();
                String param_val    = (String) enum_2.nextElement();
                String data_type    = "" ;
                
                if( param_name.indexOf(";")!= -1) 
                {
                    data_type =  param_name.substring(param_name.indexOf(";")+1,param_name.length());
                    param_name = param_name.substring(0,param_name.indexOf(";"));                    
                }
                
                if (param_val.length()>0) 
                {
                    if(param_val.startsWith("'GV*'_")) 
                    {  
                        param_val = param_val.substring(param_val.indexOf("'GV*'_")+6,param_val.length());
                    }                           
                    else 
                    {
                        if(data_type.equals("VARCHAR")||data_type.equals("DATE")||data_type.equals("VARCHAR2")) param_val = "'"+param_val+"'";
                    }   
                    
                    if(i == 0 )
                    {
                        value_buffer.append(param_val);
                        column_buffer.append(param_name);
                    }    
                    else  
                    {    
                        value_buffer.append(","+param_val);   
                        column_buffer.append(","+param_name);
                    }   
                    i++;
                }
   
            }  
            
            column_buffer.append(") VALUES");
            value_buffer.append(");\n");            
            buffer.append(column_buffer.toString()+value_buffer.toString());
            

        }   
        buffer.append("COMMIT;\n\n");
        //========================================================================================================================//
            /* Get Concurrent Request Details */
        //========================================================================================================================//
        
        
		String error_table      =   intf_property.getProperty("Error Table");
        String req_id_param     =   intf_property.getProperty("Request ID Param");
        String proc_id_param    =   intf_property.getProperty("Process ID Param");
        String cp_name          =   intf_property.getProperty("CP Name").trim();
        String cp_desc          =   intf_property.getProperty("CP Description");
        String start_time       =   intf_property.getProperty("Start Time");
        String sub_req          =   intf_property.getProperty("Sub Request");
        String go_init          =   intf_property.getProperty("Global Init"); 
        String org_plc_ctx      =   intf_property.getProperty("Org Policy Context");
        
        int app_id              =   ppl.GetIEntityID("SELECT APPLICATION_ID  FROM FND_APPLICATION WHERE APPLICATION_SHORT_NAME = '"+intf_property.getProperty("Application Name")+"'");
        String cp_shrt_name     =   ppl.GetIEntityName("SELECT CONCURRENT_PROGRAM_NAME FROM FND_CONCURRENT_PROGRAMS_VL WHERE USER_CONCURRENT_PROGRAM_NAME ='"+cp_name+"' AND APPLICATION_ID ="+ new Integer(app_id).toString());            
        int user_id             =   ppl.GetIEntityID("SELECT USER_ID FROM FND_USER WHERE USER_NAME = '"+intf_property.getProperty("User Name")+"'");
        int resp_id             =   ppl.GetIEntityID("SELECT RESPONSIBILITY_ID  FROM FND_RESPONSIBILITY_TL WHERE RESPONSIBILITY_NAME = '"+intf_property.getProperty("Responsibility")+"' and LANGUAGE = 'US'");        
        int org_id              =   ppl.GetIEntityID("SELECT ORGANIZATION_ID FROM HR_OPERATING_UNITS WHERE NAME ='"+intf_property.getProperty("Operating Unit")+"'");        
        
        //========================================================================================================================//
            /* Submit Concurrent Request  */
        //========================================================================================================================//
        
        if( ! ( cp_desc.equals("NULL")) )                                                           cp_desc     = "'"+cp_desc+"'";  
        if( ! ( start_time.equals("NULL") ||  start_time.equals("SYSDATE")))                        start_time  = "'"+start_time+"'";
        //if( ! ( sub_req.equals("NULL"   ) ||  sub_req.equals("TRUE")  || sub_req.equals("FALSE")))  sub_req     = "'"+sub_req+"'";  
        
        if(sub_req.equals("Yes"))  sub_req = "TRUE"; else sub_req = "NULL";
        
        System.out.println(go_init+"  "+org_plc_ctx+"  "+sub_req);
        
        buffer.append("FND_GLOBAL.APPS_INITIALIZE("+user_id+","+resp_id+","+app_id+");\n"); 
        buffer.append("FND_GLOBAL.SET_NLS_CONTEXT('AMERICAN');\n\n"); 
        
        if(go_init.equals("Yes"))       buffer.append("MO_GLOBAL.INIT('"+intf_property.getProperty("Application Name")+"');\n\n");  
        
        if(org_plc_ctx.equals("Yes"))   buffer.append("MO_GLOBAL.SET_POLICY_CONTEXT('S','"+org_id+"');\n\n");

 
        buffer.append("V_REQUEST_ID := FND_REQUEST.SUBMIT_REQUEST\n\t(\n");
        buffer.append("\t\tAPPLICATION   => '"+intf_property.getProperty("Application Name")+"',\n");
        buffer.append("\t\tPROGRAM       => '"+cp_shrt_name+"',\n");
        buffer.append("\t\tDESCRIPTION   => "+cp_desc+" ,\n");
        buffer.append("\t\tSTART_TIME    => "+start_time+",\n");
        buffer.append("\t\tSUB_REQUEST   => "+sub_req+",\n");
        
        String arguments = "";
        for(int i =1 ;i<11; i++)
        {
            String arg = intf_property.getProperty("Argument "+i);
            if(arg.length() > 0)
            arguments = arguments+"\t\tARGUMENT"+i+"     => '"+arg+"',\n" ;
        }
        if (arguments.indexOf(",") != -1 ) arguments = arguments.substring(0, arguments.lastIndexOf(","))+"\n";
        buffer.append(arguments);
        buffer.append("\t);\n\n");
        buffer.append("COMMIT;\n\n");
                                
        //========================================================================================================================//
        /* Wait for Request Status */
        //========================================================================================================================//
        
        buffer.append("V_FINISHED := FND_CONCURRENT.WAIT_FOR_REQUEST\n\t( \n");
        buffer.append("\t\tREQUEST_ID => V_REQUEST_ID     ,\n");
        buffer.append("\t\tINTERVAL   => 0                ,\n");
        buffer.append("\t\tMAX_WAIT   => 0                ,\n");
        buffer.append("\t\tPHASE      => V_PHASE          ,\n");
        buffer.append("\t\tSTATUS     => V_STATUS         ,\n");
        buffer.append("\t\tDEV_PHASE  => V_REQUEST_PHASE  ,\n");
        buffer.append("\t\tDEV_STATUS => V_REQUEST_STATUS ,\n");
        buffer.append("\t\tMESSAGE    => V_MESSAGE\n");
        buffer.append("\t);\n\n");
        buffer.append("COMMIT;\n\n");
        buffer.append("API_DEBUG_MESSAGE('Request ID        : '||V_REQUEST_ID);\n");
        buffer.append("API_DEBUG_MESSAGE('Request Phase     : '||V_REQUEST_PHASE);\n");
        buffer.append("API_DEBUG_MESSAGE('Request Status    : '||V_REQUEST_STATUS);\n");
        buffer.append("API_DEBUG_MESSAGE('Request Message   : '||V_MESSAGE);\n");
        
        //========================================================================================================================//
        //========================================================================================================================//
        

        buffer.append("COMMIT;\n");
        buffer.append("END TEST_OI;");
        widget.setText(buffer.toString());
        widget.setVisible(true);
        //DisplayScriptToolbar() ;
        

            
    }
    
    @SuppressWarnings("unused")
    private void DisplayProcedureTab()
    {
        String Variable_Name    =   "";
        String Data_Type        =   "";
        String Size             =   "";        
		String Default_Value    =   "";
        String IO_Type          =   "";
        String[] array = {"Generate Script","Exception Handling","Message Configuration","In Out Parameters","Output Parameters","Input Parameters","Varible Declaration","API Authentication",catalog_name+"."+procedure_name,"Data Template" };
        final java.util.List<String> al = Arrays.asList(array);  
        
        try        
        {
                            

            if(! pro_tab.getVisible())pro_tab.setVisible(true);
            

            
            TreeItem item_pro  = new TreeItem(pro_tree, 0);
            item_pro.setText(catalog_name+"."+procedure_name);
            
            TreeItem data_template  = new TreeItem(item_pro, 1);                
            data_template.setText("Data Template");
            
            TreeItem item_var  = new TreeItem(item_pro, 1);                
            item_var.setText("Varible Declaration");
            
            TreeItem api_auth  = new TreeItem(item_pro, 0);                
            api_auth.setText("API Authentication");
            
            TreeItem item_in  = new TreeItem(item_pro, 0);                
            item_in.setText("Input Parameters");
            
            TreeItem item_out  = new TreeItem(item_pro, 0);                
            item_out.setText("Output Parameters");
            
            TreeItem item_inout  = new TreeItem(item_pro, 0);                
            item_inout.setText("In Out Parameters");
            
            TreeItem item_msgt  = new TreeItem(item_pro, 0);                
            item_msgt.setText("Message Configuration ");
            
            TreeItem item_except  = new TreeItem(item_pro, 0);                
            item_except.setText("Exception Handling ");
            
            TreeItem item_generate  = new TreeItem(item_pro, 0);                
            item_generate.setText("Generate Script");
            
            if(!file) procedure_parameters = ppl.GetProcedureParameters();
            
            
            for(int index =0; index < procedure_parameters.size(); index++)
            {
                VariableDeclaration vd = (VariableDeclaration) procedure_parameters.get(index);
                Variable_Name          = vd.getVariable_Name();
                Data_Type              = vd.getData_Type();                        
                Size                   = vd.getSize();
                Default_Value          = vd.getDefault_Value();
                IO_Type                = vd.getIO_Type();     
                
                if(IO_Type.equals("IN"))
                {    
                    TreeItem item  = new TreeItem(item_in, 0);
                    item.setText(Variable_Name);            
                } 
                
                if(IO_Type.equals("OUT"))
                {    
                    TreeItem item  = new TreeItem(item_out, 0);
                    item.setText(Variable_Name);                    
                } 
                
                if(IO_Type.equals("INOUT"))
                {    
                    TreeItem item  = new TreeItem(item_inout, 0);
                    item.setText(Variable_Name);                    
                } 
                
            }  


            pro_tree.addListener(SWT.Selection, new Listener() 
            {
                public void handleEvent(Event event)
                {
                    String data  = (event.item).toString();//.getData();               
                    if(  (data.indexOf("TreeItem {")!= -1 ) && (data.indexOf("}") != -1 ))
                    data = data.substring(data.indexOf("TreeItem {")+10,data.length()-1).trim();

                    if  (data.equals("Generate Script"))
                    {
                        GenerateScript();
                    } 
                                   
                    if  (data.equals("Varible Declaration"))
                    {
                        DeclareVariables();
                    }  
                    
                    if  (data.equals("API Authentication"))
                    {
                        AuthenticateAPI();
                    }
                    if  (data.equals("Message Configuration"))
                    {
                        MessageConfiguration();
                    }
                    
                    if  (data.equals("Data Template"))
                    {
                        AssignDataFromTemplate();
                    }

                    if(! al.contains(data))
                    {
                        ConfigureRecordType(data);
                    } 
                    
                    
                    
                
                }
            });                                                                                                          
        }
        catch(Exception e)
        {
            System.out.println("Exception While Loading Tree "+e);
                 
        }
        
    }
    
    private void AssignDataFromTemplate() 
    {
        @SuppressWarnings("unused")
		final ArrayList<VariableDeclaration> proc_parms = procedure_parameters;
        final StringBuffer final_buff   = new StringBuffer();
        final StringBuffer buffer       = new StringBuffer();
        
        final StringBuffer proc_call    = new StringBuffer();
        
        String Variable_Name    =   "";
        String Data_Type        =   "";
        String Size             =   "";
        String Default_Value    =   "";
        String IO_Type          =   "";
        
        
        /* -------------------------------------------------------------------------------------------------------------------------------------------- */
        /* -------------------------------------------------------------------------------------------------------------------------------------------- */
        final StringBuffer declaration  = new StringBuffer();
        declaration.append("AS \n\n");        
        for(int index =0; index < declared_variables.size(); index++)
        {
            VariableDeclaration vd  = (VariableDeclaration) declared_variables.get(index);
            Variable_Name           = vd.getVariable_Name();
            Data_Type               = vd.getData_Type();
            Size                    = vd.getSize();
            Default_Value           = vd.getDefault_Value();
            IO_Type                 = vd.getIO_Type();
            
            if ( (Data_Type.equals("VARCHAR")||Data_Type.equals("VARCHAR2")) && ( Size.length()> 0 )) Data_Type = Data_Type+"("+Size+")";     
            
            if (Default_Value.length()> 0){Default_Value = ":= "+Default_Value+";" ; } else{ Data_Type = Data_Type+";"; }
            
            String str = String.format("%-35s %-50s %-50s %-10s \n" , "L_"+Variable_Name,  Data_Type , Default_Value , "--"+IO_Type );                
            declaration.append(str);            
        }
        declaration.append("\nBEGIN \n \n");
        /* -------------------------------------------------------------------------------------------------------------------------------------------- */
        /* -------------------------------------------------------------------------------------------------------------------------------------------- */
        
        proc_call.append("\n\n"+catalog_name+"."+procedure_name+"\n(\n");            
        for(int index =0; index < procedure_parameters.size(); index++)
        {
            VariableDeclaration vd  = (VariableDeclaration) procedure_parameters.get(index);        
            Variable_Name           = vd.getVariable_Name();
            
            String str ="";
            
            if(index != 0)  str = String.format("%-35s %-50s \n" ,"\t,"+Variable_Name, " =>\t L_"+Variable_Name);
            else            str = String.format("%-35s %-50s \n" ,"\t "+Variable_Name, " =>\t L_"+Variable_Name);

            proc_call.append(str); 

        }
        proc_call.append("\n);\n"); 
        /* -------------------------------------------------------------------------------------------------------------------------------------------- */
        /* -------------------------------------------------------------------------------------------------------------------------------------------- */
        
        //  Get     Excel Template -> Create Excel Object
        //  Shell   Path + Browse Button. File Open
        
        d_temp = new Shell(shell, SWT.TITLE|SWT.CLOSE|SWT.RESIZE);
        d_temp.setSize(800, 500);
        d_temp.setLocation(250, 150);
        d_temp.setText("Data Template");
        
        
        
        
        GridLayout gridlayout = new GridLayout();
        d_temp.setLayout(gridlayout);
        
        GridData tool_bar_grid_data                     = new GridData();
        tool_bar_grid_data.horizontalAlignment          = SWT.FILL;
        tool_bar_grid_data.grabExcessHorizontalSpace    = true;
        
        
        GridData table_grid_data                        = new GridData();
        table_grid_data.horizontalAlignment             = SWT.FILL;
        table_grid_data.grabExcessHorizontalSpace       = true;
        table_grid_data.verticalAlignment               = SWT.FILL;
        table_grid_data.grabExcessVerticalSpace         = true;
        
        
        ToolBar toolbar = new ToolBar(d_temp, SWT.FLAT | SWT.WRAP | SWT.RIGHT);
        toolbar.setLayoutData(tool_bar_grid_data);
        
        final Table table =  new Table(d_temp, SWT.BORDER|SWT.CHECK);
        table.setLayoutData(table_grid_data);
        

        
        ToolItem select_tool = new ToolItem(toolbar, SWT.PUSH);
        select_tool.setText("Select Template");
        select_tool.addSelectionListener(new SelectionAdapter()
        {           
            @Override
            public void widgetSelected(SelectionEvent e) 
            {                 
                FileDialog fd   = new FileDialog(d_temp, SWT.OPEN);
                fd.setText("Open");
                fd.setFilterPath(ConnectionXML.getTemplatesPath());
                String[] filterExt       = { "*.xls" };
                fd.setFilterExtensions(filterExt);
                String file_name = fd.open();             
                SetExcelPath(file_name);                                
                Excel excel = new Excel(excel_path);
                for(int tc = 0; tc < excel.getRows("Main")-1 ; tc++)
                {
                    String tc_key     = excel.getvalue("Main", tc+1 , "TC_KEY");
                    String test_case  = excel.getvalue("Main", tc+1 , "TEST_CASE");
                    TableItem item    = new TableItem(table, SWT.NONE);
                    item.setText(new String[]{"", tc_key,test_case});
                }                
                excel.closeStream();
                
            }
        });
        
        
        ToolItem execute_tool = new ToolItem(toolbar, SWT.PUSH);
        execute_tool.setText("Generate Script");
        execute_tool.addSelectionListener(new SelectionAdapter()
        {  
            
            ArrayList<String> al = new ArrayList<String>();
            String cell_value  = "";
            String record_type = "";
            
            @Override
            public void widgetSelected(SelectionEvent e) 
            {  
                TableItem[] items = table.getItems();
                for (TableItem item : items)  if(item.getChecked()) al.add(item.getText(1)) ;       
                
                Excel excel = new Excel(excel_path);
                
                for(int i = 0 ; i < al.size() ; i ++) //  Selected TC Keys from the UI Table
                {
                    
                    String tc_key            = al.get(i); // TC Key
                    String[] excel_sheets    = excel.getSheetNames(); //Excel Sheets
                    
                    
                    for (int j = 0 ;j <excel_sheets.length;j++ )  // Iterate through Excel Sheets 
                    {
                        
                        String[] rows  = excel.get_child_row_numbers(excel_sheets[j], "TC_KEY", tc_key);      
                        
                        for(int tc = 0; tc <rows.length;tc++)
                        {
                            

                            int           row_identifier    = Integer.parseInt(rows[tc]); 
                            ArrayList<String>     columns           = (ArrayList<String>) excel.getColumnlist(excel_sheets[j]);   
                            
                            if(excel_sheets[j].equals("Main"))
                            {
                                for(int k = 0 ; k < columns.size() ; k ++) 
                                {
                                    String column = (String) columns.get(k);
                                    
                                    if(column.equals("TC_KEY") || column.equals("TEST_CASE") )
                                    {
                                         cell_value = excel.getvalue(excel_sheets[j],row_identifier,column).trim();
                                        //buffer.append("/*" +column+ " : "+cell_value +"*/");
                                        buffer.append("\n");
                                    }    
                                    else
                                    {
                                        cell_value   = excel.getvalue(excel_sheets[j],row_identifier,column).trim();
                                        if(cell_value.length() >0)
                                        {
                                            String str = String.format("%-40s %-55s \n" ,"L_" +column, ":=\t'"+cell_value+"';");
                                            buffer.append(str);     
                                        }
                                    }
                                    
                                }
                                
                            }
                            else
                            {
                                
                                record_type  = excel.getcomment(excel_sheets[j],0,"TC_KEY").trim();
                                for(int k = 0 ; k < columns.size() ; k ++) 
                                {
                                    String column = (String) columns.get(k);
                                    column = column.trim();
                                    
                                    if( column.equals("TC_KEY") )
                                    {
                                         cell_value   = excel.getvalue(excel_sheets[j],row_identifier,column).trim();
   
                                        buffer.append("\n");
                                    }    
                                    else 
                                    {                                        
                                        cell_value   = excel.getvalue(excel_sheets[j],row_identifier,column).trim();
                                        
                                        if(cell_value.length() >0 )
                                        {
                                            if (record_type.equals("Table Type")) 
                                            {
                                                String  str = String.format("%-60s %-60s \n" ,"L_"+excel_sheets[j]+"("+(tc+1)+")."+column, ":=\t '"+cell_value+"';");                                        
                                                buffer.append(str);  
                                                
                                            }
                                            else 
                                            {
                                                String  str = String.format("%-60s %-60s \n" ,"L_"+excel_sheets[j]+"."+column, ":=\t '"+cell_value+"';");                                        
                                                buffer.append(str);  
                                                
                                            }

                                        }  

                                        
                                    }
                                } 
                                
                                                          
                            }
                             
                        }
                    }
                    
                    String procedure_call = "\nPROCEDURE TEST_"+procedure_name+"00"+ (i+1)+" "+declaration.toString()+buffer.toString()+proc_call.toString()+"\n\nEND TEST_"+procedure_name+"00"+ (i+1)+" ;\n";
                    buffer.setLength(0);
                    final_buff.append(procedure_call);
                    
                }
                
                d_temp.dispose();
                widget.setText(final_buff.toString());
                widget.setVisible(true);
                //DisplayScriptToolbar() ;

            }
               
        });
        
        TableColumn column_0 = new TableColumn(table, SWT.LEFT); 
        column_0.setText("Select");
        column_0.setWidth(50);
        
        TableColumn column_1 = new TableColumn(table, SWT.LEFT);
        column_1.setText("TC Key");
        column_1.setWidth(150);
        
        TableColumn column_2 = new TableColumn(table, SWT.LEFT);
        column_2.setText("Test Case");                
        column_2.setWidth(350);
        
        table.setHeaderVisible(true);
        EnableTableEditing(table);                
        d_temp.open();  

    }
    
    @SuppressWarnings("unused")
    private void ConfigureRecordType(String param_name) 
    {
        
        try
        {
            String[] sv = {"VARCHAR","VARCHAR2","NUMBER","DATE","TIMESTAMP","BOOLEAN"};
            final java.util.List<String> std_var = Arrays.asList(sv);  
            
            String Variable_Name    =   "";
            String Data_Type        =   "";
            String Size             =   "";
            String Default_Value    =   "";
            String IO_Type          =   "";
            


            for(int index =0; index < procedure_parameters.size(); index++)
            {                        
                    VariableDeclaration vd = (VariableDeclaration) procedure_parameters.get(index);
                
                    if( param_name.equals(  vd.getVariable_Name()   )    )
                    {
                        Variable_Name          = "L_"+vd.getVariable_Name();
                        Data_Type              = vd.getData_Type();                        
                        Size                   = vd.getSize();
                        Default_Value          = vd.getDefault_Value();
                        IO_Type                = vd.getIO_Type();                     
                    }
            }    
                                                
            if(std_var.contains(Data_Type))
            {
                                                    
                    for(int i =0; i < standard_variables.size(); i++)
                    {
                        SDTVariableAssginment sva   = (SDTVariableAssginment)standard_variables.get(i);  
                        Variable_Name               = sva.getVariableName();                     
                        if(Variable_Name.equals("L_"+param_name))  Default_Value   = sva.getAssginedValue();                                                                                                             
                    }
                    
                    rec_type = new Shell(shell, SWT.TITLE|SWT.CLOSE);
                    rec_type.setText("Data Assignment");            
                    rec_type.setLocation(500, 200);
                    rec_type.setSize(700,500);                           
                    rec_type.setText("Assign Data");            
                    rec_type.setLocation(500, 200);
                    GridLayout gridLayout = new GridLayout(4, false);
                    gridLayout.verticalSpacing = 10;
                    
                    GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
                    gridData.horizontalSpan     = 3;            
                    gridData.heightHint         = 18;
                    gridData.widthHint          = 150;

                    rec_type.setLayout(gridLayout);
                    
                    
                    Label var_name = new Label(rec_type, SWT.NULL);
                    var_name.setText("Variable Name ");
                    
                    
                    variable  = new Text(rec_type, SWT.SINGLE | SWT.BORDER);
                    variable.setLayoutData(gridData);
                    variable.setText("L_"+param_name);
                    variable.setEditable(false);
                    
                    
                    Label dt_type = new Label(rec_type, SWT.NULL);
                    dt_type.setText("Data Type ");
                    
                    dttype  = new Text(rec_type, SWT.SINGLE | SWT.BORDER);
                    dttype.setLayoutData(gridData);
                    dttype.setText(Data_Type);
                    dttype.setEditable(false);
                
                    
                    Label assignment = new Label(rec_type, SWT.NULL);
                    assignment.setText("Assign Value ");
                    
                    assign  = new Text(rec_type, SWT.SINGLE | SWT.BORDER);
                    assign.setLayoutData(gridData);
                    assign.setText(Default_Value);
                    

                        
                    Button assg = new Button(rec_type, SWT.PUSH);
                    assg.setText("  Assign  ");     
                    
                    assg.addListener(SWT.Selection, new Listener()
                    {   public void handleEvent(Event e) 
                        {
                                switch (e.type) 
                                {                                
                                    case SWT.Selection: AssignStandardVariables(); break; 
                                }
                        } 
                    });
                   
                    Button cancel = new Button(rec_type, SWT.PUSH);
                    cancel.setText("  Cancel  ");
                    cancel.addListener(SWT.Selection, new Listener()
                    {   
                            public void handleEvent(Event e) 
                            {
                                switch (e.type) 
                                {                                
                                    case SWT.Selection: 
                                    rec_type.dispose(); 
                                    break; 
                                }
                            } 
                    });
                     
                    rec_type.setSize(300, 190);            
                    rec_type.open();                                                
            }
            else
            {
                ViewRecordTypeTable(Data_Type,param_name);
    
            }        
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
    }
    
    void AssignStandardVariables()
    {
        
        String Variable_Name    = variable.getText();
        String Data_Type        = dttype.getText();
        String Assign_Value     = assign.getText();
        boolean flag  = true;
        
        for(int index =0; index < standard_variables.size(); index++)
        {
                SDTVariableAssginment sva   = (SDTVariableAssginment)standard_variables.get(index);                  
                if(sva.getVariableName().equals(Variable_Name))
                {
                    flag= false;
                    sva.setAssginedValue(Assign_Value);
                    
                } 
        }
         
        if(flag) 
        {
            standard_variables.add(new SDTVariableAssginment(Variable_Name,Data_Type,Assign_Value));                
        }
        
        rec_type.dispose();
        
                
    }
    
    private void DeclareVariables() 
    { 
                
        var = new Shell(shell, SWT.TITLE|SWT.CLOSE|SWT.RESIZE);
        var.setSize(800, 500);
        var.setLocation(250, 150);
        var.setText("Variable Declaration");
        
        
        
        GridLayout gridlayout = new GridLayout();
        var.setLayout(gridlayout);
        
        GridData tool_bar_grid_data                     = new GridData();
        tool_bar_grid_data.horizontalAlignment          = SWT.FILL;
        tool_bar_grid_data.grabExcessHorizontalSpace    = true;
        
        
        GridData table_grid_data                        = new GridData();
        table_grid_data.horizontalAlignment             = SWT.FILL;
        table_grid_data.grabExcessHorizontalSpace       = true;
        table_grid_data.verticalAlignment               = SWT.FILL;
        table_grid_data.grabExcessVerticalSpace         = true;
        

        
        ToolBar toolbar = new ToolBar(var, SWT.FLAT | SWT.WRAP | SWT.RIGHT);
        toolbar.setLayoutData(tool_bar_grid_data);
        
        final Table table =  new Table(var, SWT.BORDER);
        table.setLayoutData(table_grid_data);
        

                    
        Listener selectionListener = new Listener()
        {
            public void handleEvent(Event event) 
            {
                SaveVariableDeclaration(table);                
           }
         };
        
        ToolItem save_tool = new ToolItem(toolbar, SWT.PUSH);
        save_tool.setText("Save Data");
        save_tool.addListener(SWT.Selection, selectionListener);

                
        TableColumn column_1 = new TableColumn(table, SWT.LEFT);
        TableColumn column_2 = new TableColumn(table, SWT.LEFT);
        TableColumn column_3 = new TableColumn(table, SWT.LEFT);
        TableColumn column_4 = new TableColumn(table, SWT.LEFT);
        TableColumn column_5 = new TableColumn(table, SWT.LEFT);
        
        column_1.setText("Variable Name");
        column_2.setText("Data Type");
        column_3.setText("Size");
        column_4.setText("Default Value");
        column_5.setText("IO Type");
            
        column_1.setWidth(150);
        column_2.setWidth(200);
        column_3.setWidth(150);
        column_4.setWidth(150);
        column_5.setWidth(150);
        
        table.setHeaderVisible(true);
        
        
        String Variable_Name    =   "";
        String Data_Type        =   "";
        String Size             =   "";
        String Default_Value    =   "";
        String IO_Type          =   "";
        
        if(declared_variables.isEmpty()) 
        {                            
            for(int index =0; index < procedure_parameters.size(); index++)
            {
                VariableDeclaration vd = (VariableDeclaration) procedure_parameters.get(index);
                Variable_Name          = vd.getVariable_Name();
                Data_Type              = vd.getData_Type();                        
                Size                   = vd.getSize();
                Default_Value          = vd.getDefault_Value();
                IO_Type                = vd.getIO_Type(); 
                
                if(Data_Type.equals("VARCHAR2")||Data_Type.equals("VARCHAR")) Size = "40";
                
                TableItem item         = new TableItem(table, SWT.NONE);   
                item.setText(new String[] { Variable_Name, Data_Type,Size,Default_Value,IO_Type }); 
                
                Variable_Name    =   "";
                Data_Type        =   "";
                Size             =   "";
                Default_Value    =   "";
                IO_Type          =   "";
            }            
        }
        else
        {
            
            for(int index =0; index < declared_variables.size(); index++)
            {
                VariableDeclaration vd = (VariableDeclaration) declared_variables.get(index);
                Variable_Name          = vd.getVariable_Name();
                Data_Type              = vd.getData_Type();                        
                Size                   = vd.getSize();
                Default_Value          = vd.getDefault_Value();
                IO_Type                = vd.getIO_Type();
                
                TableItem item = new TableItem(table, SWT.NONE);   
                item.setText(new String[] { Variable_Name, Data_Type,Size,Default_Value,IO_Type }); 
                
                Variable_Name    =   "";
                Data_Type        =   "";
                Size             =   "";
                Default_Value    =   "";
                IO_Type          =   "";
            }
        }   
                    
        EnableTableEditing(table);                
        var.open();      
    }
    
    void EnableTableEditing(Table table1) 
    {
        final Table tab = table1;
        final TableEditor editor    = new TableEditor(tab);
        editor.horizontalAlignment  = SWT.LEFT;
        editor.grabHorizontal       = true;
            
        tab.addListener(SWT.MouseDown, new Listener()
        {
                    public void handleEvent(Event event)
                    {
                        Rectangle clientArea = tab.getClientArea();
                        Point pt = new Point(event.x, event.y);
                        int index = tab.getTopIndex();
                        while (index < tab.getItemCount())
                        {
                            boolean visible = false;
                            final TableItem item = tab.getItem(index);
                            for (int i = 0; i < tab.getColumnCount(); i++) 
                            {
                                Rectangle rect = item.getBounds(i);
                                if (rect.contains(pt))
                                {
                                    final int column = i;
                                    item.setBackground(i, display.getSystemColor (SWT.COLOR_WHITE));
                                    final Text text = new Text(tab, SWT.NONE);
                                    Listener textListener = new Listener() 
                                    {
                                         public void handleEvent(final Event e) 
                                         {
                                             
                                            switch (e.type) 
                                            {
                                                case SWT.FocusOut:
                                                
                                                    
                                                    item.setText(column, text.getText());
                                                    text.dispose();
                                                    break;
                                            
                                                case SWT.Traverse:
                                                
                                                    switch (e.detail)
                                                    {
                                                        case SWT.TRAVERSE_RETURN:
                                                        
                                                                
                                                                item.setText(column, text.getText());
                                                                 // FALL THROUGH
                                                        case SWT.TRAVERSE_ESCAPE: 
                                                        
                                                                
                                                                text.dispose();
                                                                e.doit = false;
                                                    }
                                                    break;
                                                }
                                            }
                                        };
                                        text.addListener(SWT.FocusOut, textListener);
                                        text.addListener(SWT.Traverse, textListener);
                                        editor.setEditor(text, item, i);
                                        text.setText(item.getText(i));
                                        text.selectAll();
                                        text.setFocus();
                                        return;
                        }
                        if (!visible && rect.intersects(clientArea)) { visible = true; }
              }
              if (!visible)return;
              index++;
            }
            }
            });
        
    }
    
    @SuppressWarnings("unused")
    private void SaveVariableDeclaration(Table table)
    {
        String Variable_Name    =   "";
        String Data_Type        =   "";
        String Size             =   "";
        String Default_Value    =   "";
        String IO_Type          =   "";
        String Message          =   "";
        
        try 
        {
            
            if(declared_variables.isEmpty()) 
            {
                TableItem [] items = table.getItems ();
                for(int i=0; i<items.length; i++) 
                {
                    
					TableItem item = items[i];                
                    int col_count = table.getColumnCount();                    
                    for(int j=0; j<col_count; j++) 
                    {       
                        TableColumn column = table.getColumn(j);                                        
                        if(column.getText().equals("Variable Name"))    Variable_Name   = items[i].getText(j);                        
                        if(column.getText().equals("Data Type"))        	Data_Type       = items[i].getText(j);                        
                        if(column.getText().equals("Size"))             			Size            = items[i].getText(j);                        
                        if(column.getText().equals("Default Value"))    Default_Value   = items[i].getText(j);                        
                        if(column.getText().equals("IO Type"))          	IO_Type         = items[i].getText(j);                         
                    }     
                                        
                    VariableDeclaration vd = new VariableDeclaration(Variable_Name,Data_Type,Size,Default_Value,IO_Type);                                            
                    declared_variables.add(vd);
                    Message = "Created New Record";                    
                }                                                              
            }
            else
            {
                TableItem [] items = table.getItems ();
                for(int i=0; i<items.length; i++) 
                {
                    TableItem item = items[i];                
                    int col_count = table.getColumnCount();                    
                    for(int j=0; j<col_count; j++) 
                    {       
                        TableColumn column = table.getColumn(j);                                        
                        if(column.getText().equals("Variable Name"))    Variable_Name   = items[i].getText(j);
                        if(column.getText().equals("Data Type"))        Data_Type       = items[i].getText(j);
                        if(column.getText().equals("Size"))             Size            = items[i].getText(j);
                        if(column.getText().equals("Default Value"))    Default_Value   = items[i].getText(j);
                        if(column.getText().equals("IO Type"))          IO_Type         = items[i].getText(j);                          
                    } 
                    
                    for(int index =0; index < declared_variables.size(); index++)
                    {
                            VariableDeclaration vd  = (VariableDeclaration) declared_variables.get(index);
                            String variable          = vd.getVariable_Name();
                        
                            if(Variable_Name.equals(variable)) 
                            {
                                vd.setData_Type(Data_Type);
                                vd.setSize(Size);
                                vd.setDefault_Value(Default_Value);
                                vd.setIO_Type(IO_Type);   
                                Message = "Updated Existing Record";                                
                            }
                    } 
                                        
                }                            
            }
            
            MessageBox messageBox = new MessageBox(var, SWT.OK);
            messageBox.setText("Save Data");
            messageBox.setMessage(Message);
            messageBox.open();
            var.dispose();

        }
        catch(Exception e) 
        {
            System.out.println(e);
            
        }
    }
    
    private void ViewRecordTypeTable(String type_name,String parameter_name) 
    { 

        final       String param    = parameter_name;
        final       String dtype    = type_name;
        boolean     found_keys      = false;
        rec_type = new Shell(shell, SWT.TITLE|SWT.CLOSE|SWT.RESIZE);
        rec_type.setSize(800, 500);
        rec_type.setLocation(250, 150);
        rec_type.setText(type_name);
        rec_type.setLayout(new FillLayout());
        
        
        GridLayout dsGridLayout = new GridLayout();
        rec_type.setLayout(dsGridLayout);
        
        GridData tool_bar_grid_data                     = new GridData();
        tool_bar_grid_data.horizontalAlignment          = SWT.FILL;
        tool_bar_grid_data.grabExcessHorizontalSpace    = true;
                
        GridData table_grid_data                        = new GridData();
        table_grid_data.horizontalAlignment             = SWT.FILL;
        table_grid_data.grabExcessHorizontalSpace       = true;
        table_grid_data.verticalAlignment               = SWT.FILL;
        table_grid_data.grabExcessVerticalSpace         = true;
        

        ToolBar toolbar = new ToolBar(rec_type, SWT.FLAT | SWT.WRAP | SWT.RIGHT);
        toolbar.setLayoutData(tool_bar_grid_data);
        
        Label lbl_var_name = new Label(rec_type,SWT.NONE);
        lbl_var_name.setText("Variable Name : "+parameter_name+"\t Data Type Name : "+type_name);
        
        final Table table =  new Table(rec_type, SWT.BORDER|SWT.MULTI|SWT.V_SCROLL|SWT.H_SCROLL|SWT.CHECK);// 
        table.setLayoutData(table_grid_data);
        
    
        Listener selectionListener = new Listener()
        {
            public void handleEvent(Event event) 
            {
                    ToolItem item = (ToolItem)event.widget;
                    
                    if(item.getText().equals("Add Row")) 
                    {
                        TableItem tb_item = new TableItem(table, SWT.NONE); 
                        tb_item.setText("");                                
                    }   
                    
                    if(item.getText().equals("Save Data")) 
                    {
                          
                        SaveRecordTypeData(table,param,dtype);
                    } 
                    
                    if(item.getText().equals("Search Field")) 
                    {

                            SearchField(table);

                    } 
            }
         };
        
        ToolItem save_tool = new ToolItem(toolbar, SWT.PUSH);
        save_tool.setText("Save Data");
        save_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//sv.ico"));
        save_tool.addListener(SWT.Selection, selectionListener);
        
        ToolItem add_tool = new ToolItem(toolbar, SWT.PUSH);
        add_tool.setText("Add Row");
        add_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//ad.ico"));
        add_tool.addListener(SWT.Selection, selectionListener);
        
        ToolItem search_tool = new ToolItem(toolbar, SWT.PUSH);
        search_tool.setText("Search Field");
        search_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//sr.ico"));
        search_tool.addListener(SWT.Selection, selectionListener);
        
        ToolItem copy_tool = new ToolItem(toolbar, SWT.PUSH);
        copy_tool.setText("Copy Row");
        copy_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//cp.ico"));
        
        copy_tool.addSelectionListener(new SelectionAdapter() 
        {
        @Override
        public void widgetSelected(SelectionEvent e)
        {
        TableItem[] items = table.getItems();
        for (TableItem item : items) 
        {
            if(item.getChecked())
            {                                                                  
                TableItem new_item = new TableItem(table, SWT.NONE); 
                for(int i = 1;i<table.getColumnCount();i++)
                new_item.setText(i,item.getText(i));                    
            }
        }
        }
        });
        
        ToolItem del_tool = null;
        
        
            
        for(int index =0; index < udt_variables.size(); index++)
        {
            int i =0;
            UDTVariableAssignment ud    = (UDTVariableAssignment) udt_variables.get(index);
            String variable             =  ud.getVariableName();    
                        
            if(variable.equals(parameter_name)) 
            {               
                if(!found_keys) 
                {
                    Hashtable<String,String>       ht                  = ud.getRecordData();        
                    Enumeration<String>     parameters          = ht.keys(); 
                    
                    if(i==0) 
                    {
                        TableColumn tc  = new TableColumn(table, SWT.NONE);
                        tc.setWidth(50); tc.setText("Row");     
                        i++;
                    }
                    
                    while ( parameters.hasMoreElements() ) 
                    {   
                        String param_name   = (String) parameters.nextElement();
                        TableColumn column  = new TableColumn(table, SWT.NONE);
                        column.setWidth(100);
                        column.setText(param_name);   
                    } 
                    
                    found_keys = true;   
                }
                
                Hashtable<String,String>       ht                  = ud.getRecordData();   
                
                int             k                   = 1;
                Enumeration<String>     parameters          = ht.elements();                  
                TableItem       item   = new TableItem(table,SWT.NONE);                
                while ( parameters.hasMoreElements() ) 
                {                     
                    item.setText(k, (String) parameters.nextElement());                                  
                    k++;  
                }     

            
            }
        }
        
        if(!found_keys) 
        {
            
            del_tool = new ToolItem(toolbar, SWT.PUSH);
            del_tool.setText("Delete Row");
            del_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//rm.ico"));
            del_tool.addSelectionListener(new SelectionAdapter()
            {
            @Override
            public void widgetSelected(SelectionEvent e)
            {
            TableItem[] items = table.getItems();
            for (TableItem item : items)
            {
            if(item.getChecked()){table.remove(table.indexOf(item));}
            }
            }
            });
            
            
            Hashtable<String,String>    ht                  = ppl.GetTypeData(type_name);        
            Enumeration<String>     	parameters          = ht.keys();      
            
            TableColumn tc  = new TableColumn(table, SWT.NONE);
            tc.setWidth(50); tc.setText("Row"); 
            
            while ( parameters.hasMoreElements() ) 
            {   
                String param_name   = (String) parameters.nextElement();
                TableColumn column  = new TableColumn(table, SWT.NONE);
                column.setWidth(100);
                column.setText(param_name);                
            }  
            
        }

        table.setHeaderVisible(true);        
        EnableTableEditing(table);     
        rec_type.open();      
    }   
        
    @SuppressWarnings("unused")   
    void SearchField(Table table) 
    {
        final Table tab = table;
        
		final String search_filed;
        final boolean[]     result = new boolean[1];
        final Shell         dialog = new Shell(shell, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
        dialog.setSize(200, 260);
        dialog.setLocation(500, 300);
        dialog.setText("Search & Enter Value");   
        
        GridLayout gridLayout = new GridLayout(4, false);
        gridLayout.verticalSpacing = 10;
        dialog.setLayout(gridLayout);
        
        
        GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        gridData.horizontalSpan     = 3;            
        gridData.heightHint         = 18;
        gridData.widthHint          = 150;
                
        //dialog.setLayout(new RowLayout());
        
        Label label1 = new Label(dialog,SWT.NONE) ;
        label1.setText("Enter Search Field");
        
        final Text search = new Text(dialog,SWT.BORDER);                        
        search.setText(" ");
        search.setLayoutData(gridData);
        
        Label label2 = new Label(dialog,SWT.NONE) ;
        label2.setText("Enter Value");
        
        final Text value = new Text(dialog,SWT.BORDER);                        
        value.setText(" ");
        value.setLayoutData(gridData);
        
        Label label3 = new Label(dialog,SWT.NONE) ;
        label3.setText("Select Row");
        
        final Combo row = new Combo(dialog,SWT.BORDER);   
        TableItem[] items = tab.getItems();
        for(int i =0 ;i<items.length;i++ )
        row.add(new Integer(i).toString());        
        row.select(0);
        row.setLayoutData(gridData);
        
        Label label4 = new Label(dialog,SWT.NONE) ;
        label4.setText("Global Variable");
        
        final Combo gl_var = new Combo(dialog,SWT.BORDER);   
        gl_var.setLayoutData(gridData);
        
        gl_var.add("");
        gl_var.select(0);
        
        for(int index =0; index < global_variables.size(); index++)
        {
               GlobalVariables gv    = (GlobalVariables) global_variables.get(index);
               String var_name       = gv.getVariableName(); 
               gl_var.add(var_name);
        }   
                
        final Button ok = new Button(dialog, SWT.PUSH);
        ok.setText("OK");
        
        Button cancel = new Button(dialog, SWT.PUSH);
        cancel.setText("Cancel");
        Listener listener = new Listener()
        {
          public void handleEvent(Event event) 
          {        
                TableItem[] items = tab.getItems();
                if(event.widget == ok)  
                {
                    String search_text   =  search.getText().trim();
                    String value_entry   =  value.getText().trim();                    
                    String glob_var      =  gl_var.getText();
                    int row_no           =  Integer.parseInt(row.getText()) ;
                    
                    if(glob_var.length() > 0 ) value_entry = "'GV*'_"+glob_var;
                        
                            
                    for (int i = 0; i < tab.getColumnCount(); i++) 
                    {
                         TableColumn column = tab.getColumn(i);                                            
                         if( search_text.equals( column.getText().trim())) 
                         {                                                        
                            if(items.length > 0)
                            {
                                TableItem   item = items[row_no];
                                //String coulmn_data = item.getText(i);                                
                                tab.select(row_no, i);  
                                if(value_entry.length() > 0) item.setText(i,value_entry);
                                item.setBackground(i,display.getSystemColor(SWT.COLOR_YELLOW));  
                                
                                
                            }
                            else
                            {               
                                TableItem   item = new TableItem(tab,SWT.NONE|SWT.SINGLE);
                                tab.select(0, i);   
                                if(value_entry.length() > 0) item.setText(i,value_entry);
                                item.setBackground(i,display.getSystemColor(SWT.COLOR_YELLOW));   
                                
                            }
                            break;                                
                         }  
                    }
                    
                }
                 
                dialog.close();
            }
        };
        ok.addListener(SWT.Selection, listener);
        cancel.addListener(SWT.Selection, listener);
        dialog.pack();
        dialog.open();
  
    }
    
    @SuppressWarnings("unused")
    public void SaveRecordTypeData(Table table,String variable_name,String data_type)
    {
        String                          col_name ;
        String                          col_data ;        
        String                          Message     = null;        
        String                          var_name    = "" ;
        int                             rec         = 0;
        
        try
        {           
                    
                    TableItem [] items = table.getItems ();
            
                    for(int i=0; i<items.length; i++) 
                    {
                            boolean     flag         = false;
                            
							TableItem   item         = items[i];                
                            int         col_count    = table.getColumnCount();  
                            Hashtable<String,String>   rec_data     =  new Hashtable<String,String>();
                        
                            //Get Record from UI Table

                            for(int j=1; j<col_count; j++) 
                            {       
                                TableColumn column = table.getColumn(j);    
                                col_name = column.getText();
                                col_data = items[i].getText(j);
                                
                                rec_data.put(col_name, col_data);
                            } 
                            
                           

                            //Check If Record Already Exists in the ArrayList
                            for(int index =0; index < udt_variables.size(); index++)
                            {
                                UDTVariableAssignment ud    = (UDTVariableAssignment) udt_variables.get(index);
                                var_name                    = ud.getVariableName(); 
                                rec                         = ud.getRecord();
                                        
                                if( var_name.equals(variable_name) && (i==rec ) )
                                {
                                        ud.setRecord(i);
                                        ud.setVariableName(variable_name);
                                        ud.setDataType(data_type);
                                        ud.setRecordData(rec_data);       
                                        Message = "Updated Existing Record";  
                                          
                                        flag = true; 
                                        break;
                                }
                            } 
                                
                            if(!flag) 
                            {
                                UDTVariableAssignment ud = new UDTVariableAssignment(i,variable_name,data_type,rec_data);   
                                udt_variables.add(ud);
                                Message = "Created New Record";                                    
                            }

                    }
    
        }
        catch(Exception e) 
        {
            System.out.println(e);        
        }
        
    }
    
    void AuthenticateAPI()
    {
        
        String auth_method = "";
        boolean context     	= false;
        String org_ctx      		= "";
        String app_name     	= "";
        String resp_name    	= "";
        String org_name     	= "";
        String user_name    	= "";
        
        auth = new Shell(shell, SWT.TITLE|SWT.CLOSE);        
        auth.setLocation(500, 200);
        GridLayout gridLayout 			= new GridLayout(4, false);
        gridLayout.verticalSpacing 	= 10;
        
        GridData gridData 					= new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        gridData.horizontalSpan     	= 3;            
        gridData.heightHint         		= 18;
        gridData.widthHint          		= 150;
        
        
        if(authentication.size()> 0) 
        {
            auth_method  	=  authentication.getProperty("Method");
            context     			=   Boolean.parseBoolean(authentication.getProperty("Policy Context"));
            org_ctx    		 	=   authentication.getProperty("Org Context");
            app_name    		=   authentication.getProperty("Application");
            resp_name   		=   authentication.getProperty("Responsibility");
            org_name    		=   authentication.getProperty("Organization");
            user_name  	 	=   authentication.getProperty("User Name");
            
        }

        auth.setLayout(gridLayout);
        String[] methods = {"MO Global Init","FND Apps Initialize" , "FND Profile Put", ""};
        
        Label auth_meth = new Label(auth, SWT.NULL);
        auth_meth.setText("Method ");
        
        
        method = new Combo(auth, SWT.DROP_DOWN | SWT.BORDER);
        for(int i=0; i< methods.length ; i++)  method.add(methods[i]);
        method.setLayoutData(gridData);
        
        if(auth_method.equals("MO Global Init"))        		method.select(0);
        if(auth_method.equals("FND Apps Initialize"))   	method.select(1);
        if(auth_method.equals("FND Profile Put"))       		method.select(2);
        if(auth_method.equals(""))                      					method.select(3);

        
        
        Label plc_context = new Label(auth, SWT.NULL);
        plc_context.setText("Policy Context");
        
        policy =  new Button(auth, SWT.CHECK);
        policy.setText("Set Policy Context");
        policy.setLayoutData(gridData);
        
        if (context) policy.setSelection(true);
                       
        Label apps_name = new Label(auth, SWT.NULL);
        apps_name.setText("Application Name ");
        
        
        app  = new Text(auth, SWT.SINGLE | SWT.BORDER);
        app.setText(app_name);
        app.setLayoutData(gridData);
        
        
        Label rsp_name = new Label(auth, SWT.NULL);
        rsp_name.setText("Responsibility");
        
        resp  = new Text(auth, SWT.SINGLE | SWT.BORDER);
        resp.setText(resp_name);
        resp.setLayoutData(gridData);
        
        
        Label og_name = new Label(auth, SWT.NULL);
        og_name.setText("Organization ");
        
        org  = new Text(auth, SWT.SINGLE | SWT.BORDER);
        org.setText(org_name);
        org.setLayoutData(gridData);
        
        
        Label usr_name = new Label(auth, SWT.NULL);
        usr_name.setText("User Name ");
        
        user  = new Text(auth, SWT.SINGLE | SWT.BORDER);
        user.setText(user_name);
        user.setLayoutData(gridData);
        

        radios = new Button[2];

        radios[0] = new Button(auth, SWT.RADIO);        
        radios[0].setText("Single Org");
                 
        radios[1] = new Button(auth, SWT.RADIO);
        radios[1].setText("Multi Organization");
        radios[1].setLayoutData(gridData);
        
        if(org_ctx.equals("S")) radios[0].setSelection(true);
        if(org_ctx.equals("M")) radios[1].setSelection(true);
        

        Button create = new Button(auth, SWT.PUSH);
        create.setText(" Create ");                   
        create.addListener(SWT.Selection, new Listener()
        {   
        		public void handleEvent(Event e) 
        		{
	                    switch (e.type) 
	                    {
	                        case SWT.Selection: 
	                        SaveAuthenticationProperties();                                           
	                        break; 
	                        
	                    }
        		} 
        });
                
        Button cancel = new Button(auth, SWT.PUSH);
        cancel.setText("  Cancel  ");
        cancel.addListener(SWT.Selection, new Listener()
        {   
        		public void handleEvent(Event e) 
        		{
        				switch (e.type) 
                    	{
                        		case SWT.Selection: 
                        		auth.dispose();                                        
                        		break;                         
                    	}
            } 
        });

        auth.setSize(400, 350);            
        auth.open();
        
    }
    
    void SaveAuthenticationProperties() 
    {
	        String auth_method  	= 	method.getText();
	        boolean context     		= 	policy.getSelection();
	        String app_name     		= 	app.getText();
	        String resp_name    		= 	resp.getText();
	        String org_name     		= 	org.getText();
	        String user_name    		= 	user.getText();
	        
	        authentication.setProperty("Method",auth_method );
	        authentication.setProperty("Policy Context",Boolean.valueOf(context).toString() );    
	        authentication.setProperty("Application",app_name );
	        authentication.setProperty("Responsibility",resp_name );
	        authentication.setProperty("Organization",org_name );
	        authentication.setProperty("User Name",user_name );
	        
	        if(radios[0].getSelection())    
	        authentication.setProperty("Org Context","S" );
	        
	        if(radios[1].getSelection())
	        authentication.setProperty("Org Context","M" );   
	        
	        MessageBox messageBox = new MessageBox(shell, SWT.OK);
	        messageBox.setText("API Authentication");
	        messageBox.setMessage("Saved Credentials");
	        messageBox.open(); 
	         
	        auth.dispose();
        
    }
    
    void MessageConfiguration()
    {       
        msg = new Shell(shell, SWT.TITLE|SWT.CLOSE);
          
        msg.setText("Out Message Configuration");            
        msg.setLocation(500, 200);
        GridLayout gridLayout 			= new GridLayout(4, false);
        gridLayout.verticalSpacing 	= 10;
        
        GridData gridData 					= new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        gridData.horizontalSpan     	= 3;            
        gridData.heightHint         		= 18;
        gridData.widthHint         	 		= 150;


        msg.setLayout(gridLayout);
        String[] types = {"Get Message Pub","Get Message List" ,"Get Message Data",};
        
        Label auth_meth = new Label(msg, SWT.NULL);
        auth_meth.setText("Message Type ");
        
        
        
        method = new Combo(msg, SWT.DROP_DOWN | SWT.BORDER);
        for(int i=0; i< types.length ; i++)  method.add(types[i]);
        method.setLayoutData(gridData);
        
        Label rs_variable_name = new Label(msg, SWT.NULL);
        rs_variable_name.setText("Return Status [Variable Name]");
        
        rs_var_name =  new Text(msg,SWT.SINGLE | SWT.BORDER);
        rs_var_name.setText("L_X_RETURN_STATUS");
        rs_var_name.setLayoutData(gridData);
        
        Label mc_variable_name = new Label(msg, SWT.NULL);
        mc_variable_name.setText("Message Count [Variable Name]");
        
        mc_var_name =  new Text(msg,SWT.SINGLE | SWT.BORDER);
        mc_var_name.setText("L_X_MESSAGE_COUNT");
        mc_var_name.setLayoutData(gridData);
        
        Label ml_variable_name = new Label(msg, SWT.NULL);
        ml_variable_name.setText("Message List [Variable Name]");
        
        ml_var_name =  new Text(msg,SWT.SINGLE | SWT.BORDER);
        ml_var_name.setText("L_X_MESSAGE_LIST");
        ml_var_name.setLayoutData(gridData);
        
        Label md_variable_name = new Label(msg, SWT.NULL);
        md_variable_name.setText("Message Data [Variable Name]");
        
        md_var_name =  new Text(msg,SWT.SINGLE | SWT.BORDER);
        md_var_name.setText("L_X_MESSAGE_DATA");
        md_var_name.setLayoutData(gridData);




        Button create = new Button(msg, SWT.PUSH);
        create.setText("Create");     

        create.addListener(SWT.Selection, new Listener()
        {   public void handleEvent(Event e) 
            {
                    switch (e.type) 
                    {
                        case SWT.Selection: 
                        CreateMessageContent();                                            
                        break; 
                        
                    }
            } 
        });
                
        Button cancel = new Button(msg, SWT.PUSH);
        cancel.setText("  Cancel  ");
        cancel.addListener(SWT.Selection, new Listener()
        {  
        		public void handleEvent(Event e) 
        		{
	                    switch (e.type) 
	                    {
	                        case SWT.Selection: 
	                        msg.dispose();
	                        break; 	                        
	                    }
        		} 
        });

        msg.setSize(400, 300);            
        msg.open();
        
    }
    
    void CreateMessageContent() 
    {
        
        String msg_type        	=    method.getText();
        String ml_varname      	=    ml_var_name.getText();
        String md_varname     =    md_var_name.getText();
        String mc_varname     =    mc_var_name.getText();
        String rs_varname       =    rs_var_name.getText();
        
        if(msg_type.equals("Get Message Pub")) 
        {
             message_string = 
            "\nDBMS_OUTPUT.PUT_LINE ('Return Stauts '||"+rs_varname+");\n\n" +
            "SHOW_MESSAGE("+mc_varname+");";            
        }
           
        if(msg_type.equals("Get Message List")) 
        {
            message_string = 
            "\n DBMS_OUTPUT.PUT_LINE ('Return Stauts '||"+rs_varname+");\n\n" + //API_DEBUG_MESSAGE
            "ERROR_HANDLER.GET_MESSAGE_LIST("+ml_varname+");\n" + 
            "DISPLAY_MESSAGE(l_message_list);";            
        }
        
        if(msg_type.equals("Message Data")) 
        {
            message_string = 
            "\n DBMS_OUTPUT.PUT_LINE ('Return Stauts '||"+rs_varname+");\n" +
             "DBMS_OUTPUT.PUT_LINE('Message : '||"+md_varname+");";
        }          
        msg.dispose();
       
    }
    
	public void GenerateScript()
    {
        String Variable_Name  =   "";
        String Data_Type        	=   "";
        String Size             		=   "";
        String Default_Value    =   "";
        String IO_Type          	=   "";
        String AssginedValue   =   "";
        
        String auth_method     =   "";
        boolean context         	=   false;
        String org_ctx          		=   "";
        String app_name         	=   "";
        String resp_name       	=   "";
        String org_name         	=   "";
        String user_name        	=   "";
        
        
        //String Text_Initialize  =   "\n\nCREATE OR REPLACE PROCEDURE TEST_"+procedure_name+" AS\n\n";
        
        String Text_Initialize  =   "DECLARE\n\n";
        StringBuffer GeneratedScript = new StringBuffer();

        GeneratedScript.append(Text_Initialize);
        
        /* ----------------------------------------------------------------------------------------------------------- */
                                                //  Variable Initialization //
        /* ----------------------------------------------------------------------------------------------------------- */
        
        for(int index =0; index < declared_variables.size(); index++)
        {
	            VariableDeclaration vd   = (VariableDeclaration) declared_variables.get(index);
	            Variable_Name           		= vd.getVariable_Name();
	            Data_Type               			= vd.getData_Type();
	            Size                    					= vd.getSize();
	            Default_Value            		= vd.getDefault_Value();
	            IO_Type                 				= vd.getIO_Type();
	            
	            if ( (Data_Type.equals("VARCHAR")||Data_Type.equals("VARCHAR2")) && ( Size.length()> 0 )) Data_Type = Data_Type+"("+Size+")";     
	            
	            if (Default_Value.length()> 0){Default_Value = ":= "+Default_Value+";" ; } else{ Data_Type = Data_Type+";"; }
	            
	            String str = String.format("%-35s %-50s %-50s %-10s \n" , "L_"+Variable_Name,  Data_Type , Default_Value , "--"+IO_Type );
	                       
	            GeneratedScript.append(str);            
        }
        
        
        /* ----------------------------------------------------------------------------------------------------------- */
                                                // BEGIN Block //
        /* ----------------------------------------------------------------------------------------------------------- */
        
        GeneratedScript.append("\n\nBEGIN\n\n");
        
        /* ----------------------------------------------------------------------------------------------------------- */
                                                // API Authentication //
        /* ----------------------------------------------------------------------------------------------------------- */
        
        
            if(authentication.size()> 0) 
            {
	                auth_method  	=  	authentication.getProperty("Method");
	                context     			=   	Boolean.parseBoolean(authentication.getProperty("Policy Context"));
	                org_ctx     			=   	authentication.getProperty("Org Context");
	                app_name    		=   	authentication.getProperty("Application");
	                resp_name   		=   	authentication.getProperty("Responsibility");
	                org_name    		=  	authentication.getProperty("Organization");
	                user_name   		=   	authentication.getProperty("User Name");            
            }
            
            int user_id  = ppl.GetIEntityID("SELECT USER_ID FROM FND_USER WHERE USER_NAME = '"+user_name+"'");
            int resp_id  = ppl.GetIEntityID("SELECT RESPONSIBILITY_ID  FROM FND_RESPONSIBILITY_TL WHERE RESPONSIBILITY_NAME = '"+resp_name+"'");
            int app_id   = ppl.GetIEntityID("SELECT APPLICATION_ID  FROM FND_APPLICATION WHERE APPLICATION_SHORT_NAME = '"+app_name+"'");
            int org_id   = ppl.GetIEntityID("SELECT ORGANIZATION_ID FROM HR_OPERATING_UNITS WHERE NAME ='"+org_name+"'");
            
            
                if(auth_method.equals("MO Global Init")) 
                GeneratedScript.append("MO_GLOBAL.INIT('"+app_name+"');\n "); 

                if(auth_method.equals("FND Apps Initialize")) 
                GeneratedScript.append("\nFND_GLOBAL.APPS_INITIALIZE("+user_id+" , "+resp_id + " , " +app_id+ ");\n"); 
                   
                if(auth_method.equals("FND Profile Put"))   
                {
                    	GeneratedScript.append("\nFND_PROFILE.PUT ('USER_ID',"+user_id+");\n"); 
                    	GeneratedScript.append("FND_PROFILE.PUT ('RESP_ID',"+resp_id+");\n"); 
                }
                
                if(context) 
                {
                    	GeneratedScript.append("\nMO_GLOBAL.INIT('"+app_name+"');\n"); 
                    	GeneratedScript.append("MO_GLOBAL.SET_POLICY_CONTEXT("+org_ctx+",'"+org_id+"');\n");                    
                }
                          
        /* ----------------------------------------------------------------------------------------------------------- */
                                                // Override Standard Variable Values //
        /* ----------------------------------------------------------------------------------------------------------- */
        
        
        
        //Standard Variable Assignment
        for(int index =0; index < standard_variables.size(); index++)
        {
            SDTVariableAssginment sv  = (SDTVariableAssginment) standard_variables.get(index);
            
            Variable_Name           = sv.getVariableName();
            Data_Type               = sv.getData_Type();
            AssginedValue           = sv.getAssginedValue();            
            
            String str = String.format("%-40s %-55s \n" ,Variable_Name, ":=\t"+AssginedValue+";");
            GeneratedScript.append(str);        
        }
        
        GeneratedScript.append("\n"); 
        
        /* ----------------------------------------------------------------------------------------------------------- */
                                                // UDT Assignments //
        /* ----------------------------------------------------------------------------------------------------------- */
        
        
        for(int index =0; index < udt_variables.size(); index++)
        {
            UDTVariableAssignment uv  = (UDTVariableAssignment) udt_variables.get(index);
            GeneratedScript.append("\n");
            int         		record            							=   uv.getRecord()+1;
            String      	variable_name    	 					=   uv.getVariableName();
            String      	data_type         							=   uv.getDataType();
            Hashtable<String,String>   rec_data         =   uv.getRecordData();           
            
            Enumeration<String>     keys          			=	 rec_data.keys();        
            Enumeration<String>     elements      		= 	 rec_data.elements();
            String      str               =    "";

                  
                while ( keys.hasMoreElements() && elements.hasMoreElements() ) 
                {   
                    String var_name   = (String) keys.nextElement();
                    String var_val    	= (String) elements.nextElement();  
                    var_name 	= var_name.trim();
                    var_val 		= var_val.trim();   
                    
                    if( data_type.endsWith("_TBL_TYPE") && (var_val.length()> 0) ) 
                    {
                        	str = String.format("%-60s %-60s \n" ,"L_"+variable_name+"("+record+")."+var_name, ":=\t '"+var_val+"';");
                        	GeneratedScript.append(str);                        
                    }
                    
                    if( data_type.endsWith("_REC_TYPE") && (var_val.length()> 0) ) 
                    {
                        	str = String.format("%-60s %-60s \n" ,"L_"+variable_name+"."+var_name, ":=\t '"+var_val+"';");
                        	GeneratedScript.append(str);                       
                    }                       
                    //else //str = String.format("%-50s %-60s \n" ,"L_"+variable_name+"("+record+")."+var_name, ":=\t NULL ;");    
                    
                } 
            }
      

        GeneratedScript.append("\n");
        
        /* ----------------------------------------------------------------------------------------------------------- */
                                                 //Procedure Call //
        /* ----------------------------------------------------------------------------------------------------------- */
        
       
        GeneratedScript.append("\n\n"+catalog_name+"."+procedure_name+"\n(\n");            
        for(int index =0; index < procedure_parameters.size(); index++)
        {
	            VariableDeclaration vd   = (VariableDeclaration) procedure_parameters.get(index);        
	            Variable_Name           		= vd.getVariable_Name();
	            
	            String str ="";
	            
	            if(index != 0)  	str = String.format("%-35s %-50s \n" ,"\t,"+Variable_Name, " =>\t L_"+Variable_Name);
	            else            			str = String.format("%-35s %-50s \n" ,"\t "+Variable_Name, " =>\t L_"+Variable_Name);
	
	            GeneratedScript.append(str); 

        }
        GeneratedScript.append("\n);\n"); 
        /* ----------------------------------------------------------------------------------------------------------- */
                                                 // Output Configuration //
        /* ----------------------------------------------------------------------------------------------------------- */
        
        
        /* ----------------------------------------------------------------------------------------------------------- */
                                                 // Message Configuration //
        /* ----------------------------------------------------------------------------------------------------------- */    
        
        GeneratedScript.append(message_string); 
        
        /* ----------------------------------------------------------------------------------------------------------- */
                                                 // Exception Handling //
        /* ----------------------------------------------------------------------------------------------------------- */
                       
        /* ----------------------------------------------------------------------------------------------------------- */
                                                 // END Block //
        /* ----------------------------------------------------------------------------------------------------------- */
        //GeneratedScript.append("\n\nEND TEST_"+procedure_name+";"); 
        GeneratedScript.append("\n\n\nEND;\n\n");
        
        
        widget.setText(GeneratedScript.toString());
        widget.setVisible(true);

        

    }
    
    void DisplayScriptToolbar() 
    {
        String img_path = ConnectionXML.getImagePath();
        
        Listener selectionListener = new Listener()
        {
            public void handleEvent(Event event)// throws Exception 
            {
                    ToolItem item = (ToolItem)event.widget;
                    
                    if(item.getText().equals("Compile")) 
                    {
                        String code =     widget.getText();
                        boolean status = ppl.CompileProcedure(code);
                        if(status) 
                        {
                            MessageBox messageBox = new MessageBox(shell, SWT.OK);
                            messageBox.setText("Compile Procedure");
                            messageBox.setMessage("Procedure Compilation Failed");
                            messageBox.open();
                                    
                        }
                        else 
                        {
                            MessageBox messageBox = new MessageBox(shell, SWT.OK);
                            messageBox.setText("Compile Procedure");
                            messageBox.setMessage("Succesfully Compiled the Procedure");
                            messageBox.open();                
                        }
                    }   
                    
                    if(item.getText().equals("Execute")) 
                    {
                        boolean status;
                        if(test_entity.equals("Open Interface")) status  = ppl.CompileProcedure("BEGIN TEST_OI; END;");
                        else  status  = ppl.CompileProcedure("BEGIN TEST_"+procedure_name+"; END;");
                        
                       
                        if(status) 
                        {
        
                            MessageBox messageBox = new MessageBox(shell, SWT.OK);
                            messageBox.setText("Compile Procedure");
                            messageBox.setMessage("Procedure Execution Failed");
                            messageBox.open();     
                        }
                        else 
                        {
                            
                            MessageBox messageBox = new MessageBox(shell, SWT.OK);
                            messageBox.setText("Compile Procedure");
                            messageBox.setMessage("Succesfully Executed the Procedure");
                            messageBox.open();  
           
                        }

                    } 
                    
                    if(item.getText().equals("View")) 
                    {
                        
                        StringBuffer sb = new StringBuffer();
                        widget.setText("");
                        
                        ArrayList<String> al = ppl.ViewResults();
                        for(int index =0; index < al.size(); index++)
                        {
                            sb.append((String) al.get(index) +"\n" );     
                        } 
                        widget.setText(sb.toString()); 

                    } 
                    
                    if(item.getText().equals("Crear")) 
                    {
                        widget.setText(""); 
                    }
                    
                    if(item.getText().equals("Save")) 
                    {
                        SaveFile();
                    }
            }
            
            
         };

        ToolItem item_save = new ToolItem(script_toolbar, SWT.PUSH);
        item_save.setText("Save");
        item_save.setImage( new Image(display, img_path+"//sv.ico"));
        item_save.addListener(SWT.Selection, selectionListener);
        
        ToolItem item_compile = new ToolItem(script_toolbar, SWT.PUSH);
        item_compile.setText("Compile");
        item_compile.setImage( new Image(display, img_path+"//cmp.ico"));
        item_compile.addListener(SWT.Selection, selectionListener);
        
        ToolItem item_invoke = new ToolItem(script_toolbar, SWT.PUSH);
        item_invoke.setText("Execute");
        item_invoke.setImage( new Image(display, img_path+"//ex.ico"));
        item_invoke.addListener(SWT.Selection, selectionListener);
        
        ToolItem item_view = new ToolItem(script_toolbar, SWT.PUSH);        
        item_view.setText("View");
        item_view.setImage( new Image(display, img_path+"//rs.ico"));
        item_view.addListener(SWT.Selection, selectionListener);
        
        ToolItem item_clear = new ToolItem(script_toolbar, SWT.PUSH);
        item_clear.setText("Crear");
        item_clear.setImage( new Image(display, img_path+"//cl.ico"));
        item_clear.addListener(SWT.Selection, selectionListener);
        
    }
    
    void SaveFile()
    {
        
        FileDialog fileDialog = new FileDialog(shell, SWT.SAVE);
        fileDialog.setText("Save");
        fileDialog.setFileName(procedure_name+".SQL");
        fileDialog.setFilterPath("D:/");
        String[] filterExt = { "*.txt", "*.sql" };
        fileDialog.setFilterExtensions(filterExt);
        String selected = fileDialog.open();
        if (selected == null) return;
        
        File file = new File(selected);
        try 
        {
               FileWriter fileWriter = new FileWriter(file);
               fileWriter.write(widget.getText());
               fileWriter.close();
        } 
        catch (IOException e)
        {
            MessageBox messageBox = new MessageBox(shell, SWT.ICON_ERROR| SWT.OK);
            messageBox.setMessage("File I/O Error.");
            messageBox.setText("Error");
            messageBox.open();
        }
    }  
        
    void SaveTest()
    {

            try 
            {
                ProcedureObject     po = new ProcedureObject();
                
                po.setProcedureName(procedure_name);
                po.setCatalogName(catalog_name);
                po.setMessageString(message_string);                
                po.setAuthentication(authentication);  
                po.setProceduredParameters(procedure_parameters);
                po.setDeclaredVariables(declared_variables);
                po.setStandardVariables(standard_variables);
                po.setUDTVariables(udt_variables);
                

                
                FileDialog fileDialog   = new FileDialog(shell, SWT.SAVE);
                fileDialog.setText("Save");
                fileDialog.setFileName("Test_"+procedure_name+".tst");
                fileDialog.setFilterPath("D:/");
                String[] filterExt = { "*.tst" };
                fileDialog.setFilterExtensions(filterExt);
                String selected = fileDialog.open();
                if (selected == null) return;
                
                File file = new File(selected);
                ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
                out.writeObject(po);
                out.close();

            } 

            catch(Exception e) 
            {
                System.out.println(e);            
            }
        
    }
        
	void OpenTest()
    {
        try
        {
               file = true;
               FileDialog fd = new FileDialog(shell, SWT.OPEN);
               fd.setText("Open");
               fd.setFilterPath("D:/");
               String[] filterExt       			= { "*.tst" };
               fd.setFilterExtensions(filterExt);
               String file_name         		= fd.open();
               FileInputStream      fin 	= new FileInputStream(file_name);
               ObjectInputStream    ois = new ObjectInputStream(fin);
               ProcedureObject      po  	= (ProcedureObject) ois.readObject();
               procedure_name           		= po.getProcedureName();
               catalog_name             		= po.getCatalogName();
               message_string           		= po.getMessageString();
               authentication           		= po.getAuthentication();
               procedure_parameters     = po.getProceduredParameters();
               declared_variables       		= po.getDeclaredVariables();
               declared_variables       		= po.getDeclaredVariables();
               standard_variables     	  	= po.getStandardVariables();
               udt_variables            			= po.getUDTVariables();
            
               Thread.sleep(100000);
            
               /*=====================================================================================================================*/
               /*=====================================================================================================================*/
            
               final Shell         dialog = new Shell(shell, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
               dialog.setSize(200, 200);
               dialog.setLocation(500, 300);
               dialog.setText("Connection Name");   
               
               GridLayout gridLayout = new GridLayout(4, false);
               gridLayout.verticalSpacing = 10;
               dialog.setLayout(gridLayout);        
               
               GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
               gridData.horizontalSpan     = 3;            
               gridData.heightHint         = 18;
               gridData.widthHint          = 150;
                       
                   
               Label label = new Label(dialog,SWT.NONE) ;
               label.setText("Enter Connection Name");
               
               
               
               final Combo search = new Combo(dialog,SWT.READ_ONLY);                            
               search.setLayoutData(gridData);
                           
               for(int index =0; index < connections.size(); index++)
               {
                   search.add((String) connections.get(index));
               } 
               
               final Button ok = new Button(dialog, SWT.PUSH);
               ok.setText("OK");
               
               Button cancel = new Button(dialog, SWT.PUSH);
               cancel.setText("Cancel");
               
               Listener listener = new Listener() 
               {
                       public void handleEvent(Event event)  
                       {  
                           if(event.widget == ok)   
                           {   
                               SetConnectioName(search.getText());
                               dialog.dispose();
                           }
                           dialog.dispose();
                       }   
               };
               ok.addListener(SWT.Selection, listener);
               cancel.addListener(SWT.Selection, listener);
               dialog.pack();
               dialog.open();
               ois.close();
               /*=====================================================================================================================*/
            
              /*=====================================================================================================================*/
            
                              

            
               Thread.sleep(10000);
               DisplayProcedureTab();
     
        }
        catch(Exception e) 
        {
            System.out.println(e);
        }
        
    }
    
    void  SetConnectioName(String name) 
    { 
            connection_name = name;        
            System.out.println("Connection Name : "+connection_name);            
            ppl = new ProcessPLSQL(procedure_name,catalog_name,connection_name);
    }
        
    void ConfigureGlobalVariables() 
    {
        gv_config = new Shell(shell, SWT.TITLE|SWT.CLOSE|SWT.RESIZE);
        gv_config.setSize(600, 300);
        gv_config.setLocation(350, 200);
        gv_config.setText("Global Variables");
        
            
        GridLayout gridlayout = new GridLayout();
        gv_config.setLayout(gridlayout);
        
        GridData tool_bar_grid_data                     					= new GridData();
        tool_bar_grid_data.horizontalAlignment          		= SWT.FILL;
        tool_bar_grid_data.grabExcessHorizontalSpace    = true;
        
        
        GridData table_grid_data                        				= new GridData();
        table_grid_data.horizontalAlignment             		= SWT.FILL;
        table_grid_data.grabExcessHorizontalSpace       = true;
        table_grid_data.verticalAlignment               			= SWT.FILL;
        table_grid_data.grabExcessVerticalSpace         	= true;
        

        
        ToolBar toolbar 					= new ToolBar(gv_config, SWT.FLAT | SWT.WRAP | SWT.RIGHT);
        toolbar.setLayoutData(tool_bar_grid_data);
        
        final Table table 					=  new Table(gv_config, SWT.BORDER|SWT.MULTI|SWT.V_SCROLL|SWT.H_SCROLL|SWT.CHECK);// 
        //final Table             table   =   new Table(, SWT.BORDER);        
        table.setLayoutData(table_grid_data);
        table.setHeaderVisible(true);
        table.setLinesVisible(true);
        
        ToolItem save_tool = new ToolItem(toolbar, SWT.PUSH);
        save_tool.setText("Save");
        save_tool.setImage( new Image(display,ConnectionXML.getImagePath() +"//sv.ico"));
        
        save_tool.addSelectionListener(new SelectionAdapter()
        {           
           @Override
           public void widgetSelected(SelectionEvent e) 
           {               
               SaveGlobalVariables(table);
           }
        });
        
        ToolItem add_tool = new ToolItem(toolbar, SWT.PUSH);
        add_tool.setText("Add");
        add_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//ad.ico"));
        add_tool.addSelectionListener(new SelectionAdapter() 
        {            
            @Override
            public void widgetSelected(SelectionEvent e) 
            {                
                @SuppressWarnings("unused")
				TableItem item = new TableItem(table, SWT.NONE); 
            }
        });

        ToolItem copy_tool = new ToolItem(toolbar, SWT.PUSH);
        copy_tool.setText("Copy");
        copy_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//cp.ico"));        
        copy_tool.addSelectionListener(new SelectionAdapter() 
        {            
            @Override
            public void widgetSelected(SelectionEvent e) 
            {
	                TableItem[] items = table.getItems();
	                for (TableItem item : items) 
	                {
		                    if(item.getChecked())
		                    {                                                                  
		                        TableItem new_item = new TableItem(table, SWT.NONE); 
		                        for(int i = 1;i<table.getColumnCount();i++)
		                        new_item.setText(i,item.getText(i));                    
		                    }
	                }
            }
        });
        
        
        ToolItem del_tool =  new ToolItem(toolbar, SWT.PUSH);        
        del_tool.setText("Delete");
        del_tool.setImage( new Image(display,ConnectionXML.getImagePath()+"//rm.ico"));            
        del_tool.addSelectionListener(new SelectionAdapter() 
        {            
            @Override
            public void widgetSelected(SelectionEvent e) 
            {
                TableItem[] items = table.getItems();
                for (TableItem item : items) 
                {
                    if(item.getChecked()){table.remove(table.indexOf(item));}
                }
            }
        });
        
        TableColumn column_0 = new TableColumn(table, SWT.LEFT);                
        TableColumn column_1 = new TableColumn(table, SWT.LEFT);
        TableColumn column_2 = new TableColumn(table, SWT.LEFT);
        TableColumn column_3 = new TableColumn(table, SWT.LEFT);
        TableColumn column_4 = new TableColumn(table, SWT.LEFT);
        TableColumn column_5 = new TableColumn(table, SWT.LEFT);
        TableColumn column_6 = new TableColumn(table, SWT.LEFT);
        
        column_0.setText("Select Row");
        column_1.setText("Variable Name");
        column_2.setText("Data Type");
        column_3.setText("Size");
        column_4.setText("Default Value");
        column_5.setText("ID Param Query");
        column_6.setText("Value Param Query");
        
        for(int index =0; index < global_variables.size(); index++)
        {
	            GlobalVariables gv      			=   (GlobalVariables) global_variables.get(index);            
	            String VariableName     		=   gv.getVariableName();
	            String DataType         			=   gv.getDataType();
	            String Size             				=   gv.getSize();
	            String DefaultValue     			=   gv.getDefaultValue();
	            String IDParamQuery     		=   gv.getIDParamQuery();
	            String ValueParamQuery  	=   gv.getValueParamQuery();
	            TableItem item          			=   new TableItem(table,SWT.NONE);
	            item.setText(new String[] {"",VariableName,DataType,Size,DefaultValue,IDParamQuery,ValueParamQuery});            
        }

        column_0.pack();
        column_1.pack();
        column_2.pack();
        column_3.pack();
        column_4.pack();
        column_5.pack();
        column_6.pack();
        
        EnableTableEditing(table);                
        gv_config.open();

        
    }
    
    public void SaveGlobalVariables(Table table)   
    {
	        String VariableName     		=   "";
	        String DataType         			=   "";
	        String Size             				=   "";
	        String DefaultValue     			=   "";
	        String IDParamQuery     		=   "";
	        String ValueParamQuery  	=   "";
	        
	        TableItem [] items = table.getItems ();        
	        
	        for(int i=0; i<items.length; i++) 
	        {        
			            boolean flag     		=  false;
			            VariableName     		=  items[i].getText(1); 
			            DataType         			=  items[i].getText(2);
			            Size             				=  items[i].getText(3);
			            DefaultValue     			=  items[i].getText(4); 
			            IDParamQuery     	=  items[i].getText(5); 
			            ValueParamQuery  	=  items[i].getText(6); 
			                    
			                                    
			            //Check If Record Already Exists in the ArrayList
			             for(int index =0; index < global_variables.size(); index++)
			             {
				                    GlobalVariables 	gv    				= (GlobalVariables) global_variables.get(index);
				                    String 						var_name       = gv.getVariableName(); 
				                                                
				                    if( VariableName.equals(var_name))
				                    {
					                        gv.setDataType(DataType);
					                        gv.setSize(Size);
					                        gv.setDefault_Value(DefaultValue);
					                        gv.setValueParamQuery(ValueParamQuery);
					                        gv.setIDParamQuery(IDParamQuery);
					                        flag = true;
					                        break;
				                    }
			             }
			            
			             if(!flag) 
			             {
			                GlobalVariables gv = new GlobalVariables(VariableName,DataType,Size, DefaultValue,IDParamQuery,ValueParamQuery);   
			                global_variables.add(gv);            
			             }                                                                    
		        } 
	        
    } 
    
    public static void main(String[] arg)
    { new Main();}

}

